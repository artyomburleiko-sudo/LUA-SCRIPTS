--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
local gui = Instance.new("ScreenGui")
gui.Name = "StigmaV3"
gui.ResetOnSpawn = false
gui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Name = "MainFrame"
frame.Size = UDim2.new(0, 425, 0, 292)
frame.Position = UDim2.new(0.5, -225, 0.5, -150)
frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
frame.BorderSizePixel = 1
frame.BorderColor3 = Color3.fromRGB(200, 200, 200)
frame.Active = true
frame.Parent = gui

local title = Instance.new("TextLabel")
title.Name = "Title"
title.Parent = frame
title.Size = UDim2.new(1, 0, 0, 20)
title.BackgroundColor3 = Color3.fromRGB(240, 240, 240)
title.BorderSizePixel = 0
title.Text = "  Stigma V3"
title.Font = Enum.Font.SourceSans
title.TextColor3 = Color3.fromRGB(150, 150, 150)
title.TextSize = 16
title.TextXAlignment = Enum.TextXAlignment.Left

local menubar = Instance.new("Frame")
menubar.Name = "Menubar"
menubar.Parent = frame
menubar.Position = UDim2.new(0, 0, 0, 20)
menubar.Size = UDim2.new(1, 0, 0, 18)
menubar.BackgroundColor3 = Color3.fromRGB(245, 245, 245)
menubar.BorderSizePixel = 0

local minimized = Instance.new("TextButton")
minimized.Text = "Open Stigma v3"
minimized.Size = UDim2.new(0, 120, 0, 30)
minimized.Position = UDim2.new(0, 10, 1, -40)
minimized.BackgroundColor3 = Color3.fromRGB(230, 230, 230)
minimized.TextColor3 = Color3.fromRGB(0, 0, 0)
minimized.Visible = false
minimized.Parent = gui

local topGrayBar = Instance.new("Frame")
topGrayBar.Name = "TopGrayBar"
topGrayBar.Parent = frame
topGrayBar.Position = UDim2.new(0, 0, 0, 38)
topGrayBar.Size = UDim2.new(0, 345, 0, 19)
topGrayBar.BackgroundColor3 = Color3.fromRGB(200, 200, 200)
topGrayBar.BorderSizePixel = 0

local topGrayBar2 = Instance.new("Frame")
topGrayBar2.Name = "topGrayBar2"
topGrayBar2.Parent = frame
topGrayBar2.Position = UDim2.new(0, 0, 0, 55)
topGrayBar2.Size = UDim2.new(0, 343, 0, 3)
topGrayBar2.BackgroundColor3 = Color3.fromRGB(93, 93, 93)
topGrayBar2.BorderSizePixel = 0

local verticalBar = Instance.new("Frame")
verticalBar.Name = "RightTextboxBar"
verticalBar.Parent = frame
verticalBar.Position = UDim2.new(0, 325, 0, 57)
verticalBar.Size = UDim2.new(0, 23, 0, 236)
verticalBar.BackgroundColor3 = Color3.fromRGB(220, 220, 220)
verticalBar.BorderSizePixel = 0

local upArrow = Instance.new("TextButton")
upArrow.Name = "UpArrow"
upArrow.Parent = verticalBar
upArrow.Size = UDim2.new(1, 0, 0, 18)
upArrow.Position = UDim2.new(0, 0, 0, 0)
upArrow.BackgroundColor3 = Color3.fromRGB(200, 200, 200)
upArrow.BorderSizePixel = 0
upArrow.Text = "^"
upArrow.Font = Enum.Font.SourceSansBold
upArrow.TextColor3 = Color3.fromRGB(150, 150, 150)
upArrow.BackgroundTransparency = 1
upArrow.TextSize = 16

local downArrow = Instance.new("TextButton")
downArrow.Name = "DownArrow"
downArrow.Parent = verticalBar
downArrow.Size = UDim2.new(1, 0, 0, 18)
downArrow.Position = UDim2.new(0, 0, 1, 0)
downArrow.AnchorPoint = Vector2.new(0, 1)
downArrow.BackgroundColor3 = Color3.fromRGB(200, 200, 200)
downArrow.BorderSizePixel = 0
downArrow.Text = "v"
downArrow.Font = Enum.Font.SourceSansBold
downArrow.TextColor3 = Color3.fromRGB(150, 150, 150)
downArrow.BackgroundTransparency = 1
downArrow.TextSize = 16

local textbox = Instance.new("TextBox")
textbox.Parent = frame
textbox.Position = UDim2.new(0, 5, 0, 58)
textbox.Size = UDim2.new(0, 319, 0, 232)
textbox.BackgroundColor3 = Color3.fromRGB(245, 245, 245)
textbox.TextColor3 = Color3.fromRGB(0, 0, 0)
textbox.Font = Enum.Font.Arcade
textbox.TextSize = 13
textbox.BorderSizePixel = 0
textbox.TextXAlignment = Enum.TextXAlignment.Left
textbox.TextYAlignment = Enum.TextYAlignment.Top
textbox.ClearTextOnFocus = false
textbox.TextWrapped = true
textbox.MultiLine = true
textbox.Text = ""

local verticalBar2 = Instance.new("Frame")
verticalBar2.Name = "RightTextboxBar2"
verticalBar2.Parent = frame
verticalBar2.Position = UDim2.new(0, -1, 0, 57)
verticalBar2.Size = UDim2.new(0, 5, 0, 236)
verticalBar2.BackgroundColor3 = Color3.fromRGB(200, 200, 200)
verticalBar2.BorderSizePixel = 0

local verticalBar3 = Instance.new("Frame")
verticalBar3.Name = "RightTextboxBar2"
verticalBar3.Parent = frame
verticalBar3.Position = UDim2.new(0, 2, 0, 57)
verticalBar3.Size = UDim2.new(0, 3, 0, 236)
verticalBar3.BackgroundColor3 = Color3.fromRGB(93, 93, 93)
verticalBar3.BorderSizePixel = 0

local execute = Instance.new("TextButton")
execute.Parent = frame
execute.Size = UDim2.new(0, 80, 0, 127)
execute.Position = UDim2.new(0, 345, 0, 39)
execute.BackgroundColor3 = Color3.fromRGB(230, 230, 230)
execute.BorderColor3 = Color3.fromRGB(180, 180, 180)
execute.Font = Enum.Font.ArimoBold
execute.Text = "EXE"
execute.TextSize = 15
execute.TextColor3 = Color3.fromRGB(0, 0, 0)
execute.MouseButton1Click:Connect(function()
	if textbox.Text ~= "" then
		local success, err = pcall(function()
			loadstring(textbox.Text)()
		end)
		if not success then
			print("Error: " .. err)
		end
	end
end)

local clear = Instance.new("TextButton")
clear.Parent = frame
clear.Size = UDim2.new(0, 80, 0, 125)
clear.Position = UDim2.new(0, 345, 0, 167)
clear.BackgroundColor3 = Color3.fromRGB(230, 230, 230)
clear.BorderColor3 = Color3.fromRGB(180, 180, 180)
clear.Font = Enum.Font.ArimoBold
clear.Text = "CLEAR"
clear.TextSize = 15
clear.TextColor3 = Color3.fromRGB(0, 0, 0)
clear.MouseButton1Click:Connect(function()
	textbox.Text = ""
end)

local fileButton = Instance.new("TextButton")
fileButton.Name = "FileButton"
fileButton.Parent = menubar
fileButton.Size = UDim2.new(0, 40, 1, 0)
fileButton.Position = UDim2.new(0, 5, 0, 0)
fileButton.BackgroundTransparency = 1
fileButton.Text = " File"
fileButton.Font = Enum.Font.SourceSans
fileButton.TextColor3 = Color3.fromRGB(0, 0, 0)
fileButton.TextSize = 15
fileButton.TextXAlignment = Enum.TextXAlignment.Left

local helpButton = fileButton:Clone()
helpButton.Text = "Help"
helpButton.TextSize = 15
helpButton.Position = UDim2.new(0, 50, 0, 0)
helpButton.Parent = menubar

local fileframe = Instance.new("Frame")
fileframe.Name = "FileMenu"
fileframe.Parent = frame
fileframe.Position = UDim2.new(0, 0, 0, 38)
fileframe.Size = UDim2.new(0, 130, 0, 36)
fileframe.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
fileframe.BorderColor3 = Color3.fromRGB(170, 170, 170)
fileframe.Visible = false

fileButton.MouseButton1Click:Connect(function()
	fileframe.Visible = not fileframe.Visible
end)

local minimize = Instance.new("TextButton")
minimize.Parent = fileframe
minimize.Size = UDim2.new(1, 0, 0.5, 0)
minimize.Position = UDim2.new(0, 0, 0, 0)
minimize.BackgroundTransparency = 1
minimize.Text = "Minimize"
minimize.TextXAlignment = Enum.TextXAlignment.Left
minimize.Font = Enum.Font.SourceSans
minimize.TextColor3 = Color3.fromRGB(0, 0, 0)
minimize.TextSize = 14
minimize.MouseButton1Down:Connect(function()
	frame.Visible = false
	minimized.Visible = true
end)

local exit = minimize:Clone()
exit.Text = "Exit"
exit.Position = UDim2.new(0, 0, 0.5, 0)
exit.Parent = fileframe
exit.MouseButton1Down:Connect(function()
	gui:Destroy()
end)

local minimized = Instance.new("TextButton")
minimized.Name = "minimized"
minimized.Parent = frame
minimized.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
minimized.BorderColor3 = Color3.fromRGB(0, 0, 0)
minimized.BorderSizePixel = 0
minimized.Position = UDim2.new(-0.000545215677, 0, 0.945157588, 0)
minimized.Size = UDim2.new(0, 93, 0, 31)
minimized.Visible = false
minimized.Font = Enum.Font.SourceSans
minimized.Text = "STIGMA"
minimized.TextColor3 = Color3.fromRGB(0, 0, 0)
minimized.TextSize = 17.000
minimized.MouseButton1Click:Connect(function()
	frame.Visible = true
	fileframe.Visible = false
	minimized.Visible = false
end)

local UIS = game:GetService("UserInputService")
local dragging, dragInput, dragStart, startPos

title.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		dragging = true
		dragStart = input.Position
		startPos = frame.Position

		input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragging = false
			end
		end)
	end
end)

title.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseMovement then
		dragInput = input
	end
end)

topGrayBar.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		dragging = true
		dragStart = input.Position
		startPos = frame.Position

		input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragging = false
			end
		end)
	end
end)

topGrayBar.InputChanged:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseMovement then
		dragInput = input
	end
end)

UIS.InputChanged:Connect(function(input)
	if dragging and input == dragInput then
		local delta = input.Position - dragStart
		frame.Position = UDim2.new(
			startPos.X.Scale, startPos.X.Offset + delta.X,
			startPos.Y.Scale, startPos.Y.Offset + delta.Y
		)
	end
end)