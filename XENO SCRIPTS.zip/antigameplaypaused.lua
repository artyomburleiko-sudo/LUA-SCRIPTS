--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
game:GetService("CoreGui").RobloxGui["CoreScripts/NetworkPause"]:Destroy()
-- yup a single line all it takes