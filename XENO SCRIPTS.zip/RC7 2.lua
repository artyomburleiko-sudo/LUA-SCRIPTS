--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local ImageButton = Instance.new("ImageButton")
local ImageButton_2 = Instance.new("ImageButton")
local ImageButton_3 = Instance.new("ImageButton")
local ImageButton_4 = Instance.new("ImageButton")
local ImageButton_5 = Instance.new("ImageButton")
local ImageButton_6 = Instance.new("ImageButton")
local ImageButton_7 = Instance.new("ImageButton")
local ImageLabel = Instance.new("ImageLabel")
local ImageLabel_2 = Instance.new("ImageLabel")
local Source = Instance.new("TextBox")
local ImageButton_8 = Instance.new("ImageButton")
local ImageButton_9 = Instance.new("ImageButton")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(0, 85, 255)
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.683526993, 0, 0.125334218, 0)
Frame.Size = UDim2.new(0, 370, 0, 431)

ImageButton.Parent = Frame
ImageButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton.BorderSizePixel = 0
ImageButton.Position = UDim2.new(0.310850412, 0, 0.695280492, 0)
ImageButton.Size = UDim2.new(0, 95, 0, 33)
ImageButton.Image = "rbxassetid://118914115299472"

ImageButton_2.Parent = Frame
ImageButton_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_2.BorderSizePixel = 0
ImageButton_2.Position = UDim2.new(-0.000977546908, 0, 0.695280492, 0)
ImageButton_2.Size = UDim2.new(0, 116, 0, 33)
ImageButton_2.Image = "rbxassetid://73330772999130"

ImageButton_3.Parent = Frame
ImageButton_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_3.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_3.BorderSizePixel = 0
ImageButton_3.Position = UDim2.new(0.841720939, 0, 0.711223781, 0)
ImageButton_3.Size = UDim2.new(0, 51, 0, 41)
ImageButton_3.Image = "rbxassetid://107443227239146"

ImageButton_4.Parent = Frame
ImageButton_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_4.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_4.BorderSizePixel = 0
ImageButton_4.Position = UDim2.new(0.56622678, 0, 0.695280492, 0)
ImageButton_4.Size = UDim2.new(0, 95, 0, 33)
ImageButton_4.Image = "rbxassetid://110708174656617"

ImageButton_5.Parent = Frame
ImageButton_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_5.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_5.BorderSizePixel = 0
ImageButton_5.Position = UDim2.new(0.841721058, 0, 0.805912018, 0)
ImageButton_5.Size = UDim2.new(0, 51, 0, 41)
ImageButton_5.Image = "rbxassetid://100241255229032"

ImageButton_6.Parent = Frame
ImageButton_6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_6.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_6.BorderSizePixel = 0
ImageButton_6.Position = UDim2.new(0.841720939, 0, 0.905219257, 0)
ImageButton_6.Size = UDim2.new(0, 51, 0, 41)
ImageButton_6.Image = "rbxassetid://104613804119261"

ImageButton_7.Parent = Frame
ImageButton_7.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_7.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_7.BorderSizePixel = 0
ImageButton_7.Position = UDim2.new(0.852150679, 0, 0.00461893762, 0)
ImageButton_7.Size = UDim2.new(0, 54, 0, 39)
ImageButton_7.Image = "rbxassetid://83553832329525"

ImageLabel.Parent = Frame
ImageLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageLabel.BorderSizePixel = 0
ImageLabel.Position = UDim2.new(-0.0018026816, 0, 0.00304658897, 0)
ImageLabel.Size = UDim2.new(0, 373, 0, 45)
ImageLabel.Image = "rbxassetid://125774209494242"

ImageLabel_2.Parent = Frame
ImageLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageLabel_2.BorderSizePixel = 0
ImageLabel_2.Position = UDim2.new(0.822819531, 0, 0.105716839, 0)
ImageLabel_2.Size = UDim2.new(0, 66, 0, 387)
ImageLabel_2.Image = "rbxassetid://75411348209482"

Source.Name = "Source"
Source.Parent = Frame
Source.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Source.BorderColor3 = Color3.fromRGB(0, 0, 0)
Source.BorderSizePixel = 0
Source.Position = UDim2.new(0.0224314053, 0, 0.126159385, 0)
Source.Size = UDim2.new(0, 289, 0, 240)
Source.Font = Enum.Font.SourceSans
Source.Text = ""
Source.TextColor3 = Color3.fromRGB(0, 0, 0)
Source.TextSize = 14.000

ImageButton_8.Parent = Frame
ImageButton_8.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_8.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_8.BorderSizePixel = 0
ImageButton_8.Position = UDim2.new(0.615591586, 0, 0.00230946881, 0)
ImageButton_8.Size = UDim2.new(0, 34, 0, 41)
ImageButton_8.Image = "rbxassetid://93665526400328"

ImageButton_9.Parent = Frame
ImageButton_9.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButton_9.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButton_9.BorderSizePixel = 0
ImageButton_9.Position = UDim2.new(0.841720939, 0, 0.600369275, 0)
ImageButton_9.Size = UDim2.new(0, 51, 0, 41)
ImageButton_9.Image = "rbxassetid://140214893196328"

-- Scripts:

local function AIOZD_fake_script() -- ImageButton.LocalScript 
	local script = Instance.new('LocalScript', ImageButton)

	script.Parent.MouseButton1Click:Connect(function()
		loadstring(script.Parent.Parent.Source.Text)()
	end)
end
coroutine.wrap(AIOZD_fake_script)()
local function SLVRHHJ_fake_script() -- ImageButton_2.Script 
	local script = Instance.new('Script', ImageButton_2)

	print("look at this dude")
	
end
coroutine.wrap(SLVRHHJ_fake_script)()
local function CXVETWL_fake_script() -- ImageButton_3.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_3)

	script.Parent.MouseButton1Click:Connect(function()
		local UserInputService = game:GetService("UserInputService")
		local Mouse = game:GetService("Players").LocalPlayer:GetMouse()
		local Folder = Instance.new("Folder", game:GetService("Workspace"))
		local Part = Instance.new("Part", Folder)
		local Attachment1 = Instance.new("Attachment", Part)
		Part.Anchored = true
		Part.CanCollide = false
		Part.Transparency = 1
		local Updated = Mouse.Hit + Vector3.new(0, 5, 0)
		local NetworkAccess = coroutine.create(function()
			settings().Physics.AllowSleep = false
			while game:GetService("RunService").RenderStepped:Wait() do
				for _, Players in next, game:GetService("Players"):GetPlayers() do
					if Players ~= game:GetService("Players").LocalPlayer then
						Players.MaximumSimulationRadius = 0 
						sethiddenproperty(Players, "SimulationRadius", 0) 
					end 
				end
				game:GetService("Players").LocalPlayer.MaximumSimulationRadius = math.pow(math.huge,math.huge)
				setsimulationradius(math.huge) 
			end 
		end) 
		coroutine.resume(NetworkAccess)
		local function ForcePart(v)
			if v:IsA("Part") and v.Anchored == false and v.Parent:FindFirstChild("Humanoid") == nil and v.Parent:FindFirstChild("Head") == nil and v.Name ~= "Handle" then
				Mouse.TargetFilter = v
				for _, x in next, v:GetChildren() do
					if x:IsA("BodyAngularVelocity") or x:IsA("BodyForce") or x:IsA("BodyGyro") or x:IsA("BodyPosition") or x:IsA("BodyThrust") or x:IsA("BodyVelocity") or x:IsA("RocketPropulsion") then
						x:Destroy()
					end
				end
				if v:FindFirstChild("Attachment") then
					v:FindFirstChild("Attachment"):Destroy()
				end
				if v:FindFirstChild("AlignPosition") then
					v:FindFirstChild("AlignPosition"):Destroy()
				end
				if v:FindFirstChild("Torque") then
					v:FindFirstChild("Torque"):Destroy()
				end
				v.CanCollide = false
				local Torque = Instance.new("Torque", v)
				Torque.Torque = Vector3.new(100000, 100000, 100000)
				local AlignPosition = Instance.new("AlignPosition", v)
				local Attachment2 = Instance.new("Attachment", v)
				Torque.Attachment0 = Attachment2
				AlignPosition.MaxForce = 9999999999999999
				AlignPosition.MaxVelocity = math.huge
				AlignPosition.Responsiveness = 200
				AlignPosition.Attachment0 = Attachment2 
				AlignPosition.Attachment1 = Attachment1
			end
		end
		for _, v in next, game:GetService("Workspace"):GetDescendants() do
			ForcePart(v)
		end
		game:GetService("Workspace").DescendantAdded:Connect(function(v)
			ForcePart(v)
		end)
		UserInputService.InputBegan:Connect(function(Key, Chat)
			if Key.KeyCode == Enum.KeyCode.E and not Chat then
				Updated = Mouse.Hit + Vector3.new(0, 5, 0)
			end
		end)
		spawn(function()
			while game:GetService("RunService").RenderStepped:Wait() do
				Attachment1.WorldCFrame = Updated
			end
		end)
	end)
end
coroutine.wrap(CXVETWL_fake_script)()
local function PNQOR_fake_script() -- ImageButton_4.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_4)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Source.Text = ''
	end)
end
coroutine.wrap(PNQOR_fake_script)()
local function UTANJMW_fake_script() -- ImageButton_5.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_5)

	local function DXFTXQ_fake_script() -- button_10.LocalScript 
		local script = Instance.new('LocalScript', button_10)
	
		local button = script.Parent
	
		button.MouseButton1Down:connect(function()
			loadstring(game:GetObjects("rbxassetid://288646117")[1].Source)()
		end)
	end
	
end
coroutine.wrap(UTANJMW_fake_script)()
local function FQDTFFR_fake_script() -- ImageButton_6.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_6)

	script.Parent.MouseButton1Click:Connect(function()
		loadstring(game:HttpGet('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'))()
	end)
end
coroutine.wrap(FQDTFFR_fake_script)()
local function CDJPOD_fake_script() -- ImageButton_7.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_7)

	print("Hello world!")
	
end
coroutine.wrap(CDJPOD_fake_script)()
local function LIQARAQ_fake_script() -- ImageButton_8.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_8)

	print("Hello world!")
	
end
coroutine.wrap(LIQARAQ_fake_script)()
local function MSDOX_fake_script() -- ImageButton_9.LocalScript 
	local script = Instance.new('LocalScript', ImageButton_9)

	script.Parent.MouseButton1Click:Connect(function()
		local Targets = {"All"} -- "All", "Target Name", "arian_was_here"
	
		local Players = game:GetService("Players")
		local Player = Players.LocalPlayer
	
		local AllBool = false
	
		local GetPlayer = function(Name)
			Name = Name:lower()
			if Name == "all" or Name == "others" then
				AllBool = true
				return
			elseif Name == "random" then
				local GetPlayers = Players:GetPlayers()
				if table.find(GetPlayers,Player) then table.remove(GetPlayers,table.find(GetPlayers,Player)) end
				return GetPlayers[math.random(#GetPlayers)]
			elseif Name ~= "random" and Name ~= "all" and Name ~= "others" then
				for _,x in next, Players:GetPlayers() do
					if x ~= Player then
						if x.Name:lower():match("^"..Name) then
							return x;
						elseif x.DisplayName:lower():match("^"..Name) then
							return x;
						end
					end
				end
			else
				return
			end
		end
	
		local Message = function(_Title, _Text, Time)
			game:GetService("StarterGui"):SetCore("SendNotification", {Title = _Title, Text = _Text, Duration = Time})
		end
	
		local SkidFling = function(TargetPlayer)
			local Character = Player.Character
			local Humanoid = Character and Character:FindFirstChildOfClass("Humanoid")
			local RootPart = Humanoid and Humanoid.RootPart
	
			local TCharacter = TargetPlayer.Character
			local THumanoid
			local TRootPart
			local THead
			local Accessory
			local Handle
	
			if TCharacter:FindFirstChildOfClass("Humanoid") then
				THumanoid = TCharacter:FindFirstChildOfClass("Humanoid")
			end
			if THumanoid and THumanoid.RootPart then
				TRootPart = THumanoid.RootPart
			end
			if TCharacter:FindFirstChild("Head") then
				THead = TCharacter.Head
			end
			if TCharacter:FindFirstChildOfClass("Accessory") then
				Accessory = TCharacter:FindFirstChildOfClass("Accessory")
			end
			if Accessoy and Accessory:FindFirstChild("Handle") then
				Handle = Accessory.Handle
			end
	
			if Character and Humanoid and RootPart then
				if RootPart.Velocity.Magnitude < 50 then
					getgenv().OldPos = RootPart.CFrame
				end
				if THumanoid and THumanoid.Sit and not AllBool then
					return Message("Error Occurred", "Targeting is sitting", 5) -- u can remove dis part if u want lol
				end
				if THead then
					workspace.CurrentCamera.CameraSubject = THead
				elseif not THead and Handle then
					workspace.CurrentCamera.CameraSubject = Handle
				elseif THumanoid and TRootPart then
					workspace.CurrentCamera.CameraSubject = THumanoid
				end
				if not TCharacter:FindFirstChildWhichIsA("BasePart") then
					return
				end
	
				local FPos = function(BasePart, Pos, Ang)
					RootPart.CFrame = CFrame.new(BasePart.Position) * Pos * Ang
					Character:SetPrimaryPartCFrame(CFrame.new(BasePart.Position) * Pos * Ang)
					RootPart.Velocity = Vector3.new(9e7, 9e7 * 10, 9e7)
					RootPart.RotVelocity = Vector3.new(9e8, 9e8, 9e8)
				end
	
				local SFBasePart = function(BasePart)
					local TimeToWait = 2
					local Time = tick()
					local Angle = 0
	
					repeat
						if RootPart and THumanoid then
							if BasePart.Velocity.Magnitude < 50 then
								Angle = Angle + 100
	
								FPos(BasePart, CFrame.new(0, 1.5, 0) + THumanoid.MoveDirection * BasePart.Velocity.Magnitude / 1.25, CFrame.Angles(math.rad(Angle),0 ,0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, 0) + THumanoid.MoveDirection * BasePart.Velocity.Magnitude / 1.25, CFrame.Angles(math.rad(Angle), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(2.25, 1.5, -2.25) + THumanoid.MoveDirection * BasePart.Velocity.Magnitude / 1.25, CFrame.Angles(math.rad(Angle), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(-2.25, -1.5, 2.25) + THumanoid.MoveDirection * BasePart.Velocity.Magnitude / 1.25, CFrame.Angles(math.rad(Angle), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, 1.5, 0) + THumanoid.MoveDirection,CFrame.Angles(math.rad(Angle), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, 0) + THumanoid.MoveDirection,CFrame.Angles(math.rad(Angle), 0, 0))
								task.wait()
							else
								FPos(BasePart, CFrame.new(0, 1.5, THumanoid.WalkSpeed), CFrame.Angles(math.rad(90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, -THumanoid.WalkSpeed), CFrame.Angles(0, 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, 1.5, THumanoid.WalkSpeed), CFrame.Angles(math.rad(90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, 1.5, TRootPart.Velocity.Magnitude / 1.25), CFrame.Angles(math.rad(90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, -TRootPart.Velocity.Magnitude / 1.25), CFrame.Angles(0, 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, 1.5, TRootPart.Velocity.Magnitude / 1.25), CFrame.Angles(math.rad(90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, 0), CFrame.Angles(math.rad(90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, 0), CFrame.Angles(0, 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5 ,0), CFrame.Angles(math.rad(-90), 0, 0))
								task.wait()
	
								FPos(BasePart, CFrame.new(0, -1.5, 0), CFrame.Angles(0, 0, 0))
								task.wait()
							end
						else
							break
						end
					until BasePart.Velocity.Magnitude > 500 or BasePart.Parent ~= TargetPlayer.Character or TargetPlayer.Parent ~= Players or not TargetPlayer.Character == TCharacter or THumanoid.Sit or Humanoid.Health <= 0 or tick() > Time + TimeToWait
				end
	
				workspace.FallenPartsDestroyHeight = 0/0
	
				local BV = Instance.new("BodyVelocity")
				BV.Name = "EpixVel"
				BV.Parent = RootPart
				BV.Velocity = Vector3.new(9e8, 9e8, 9e8)
				BV.MaxForce = Vector3.new(1/0, 1/0, 1/0)
	
				Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, false)
	
				if TRootPart and THead then
					if (TRootPart.CFrame.p - THead.CFrame.p).Magnitude > 5 then
						SFBasePart(THead)
					else
						SFBasePart(TRootPart)
					end
				elseif TRootPart and not THead then
					SFBasePart(TRootPart)
				elseif not TRootPart and THead then
					SFBasePart(THead)
				elseif not TRootPart and not THead and Accessory and Handle then
					SFBasePart(Handle)
				else
					return Message("Error Occurred", "Target is missing everything", 5)
				end
	
				BV:Destroy()
				Humanoid:SetStateEnabled(Enum.HumanoidStateType.Seated, true)
				workspace.CurrentCamera.CameraSubject = Humanoid
	
				repeat
					RootPart.CFrame = getgenv().OldPos * CFrame.new(0, .5, 0)
					Character:SetPrimaryPartCFrame(getgenv().OldPos * CFrame.new(0, .5, 0))
					Humanoid:ChangeState("GettingUp")
					table.foreach(Character:GetChildren(), function(_, x)
						if x:IsA("BasePart") then
							x.Velocity, x.RotVelocity = Vector3.new(), Vector3.new()
						end
					end)
					task.wait()
				until (RootPart.Position - getgenv().OldPos.p).Magnitude < 25
				workspace.FallenPartsDestroyHeight = getgenv().FPDH
			else
				return Message("Error Occurred", "Random error", 5)
			end
		end
	
		if not Welcome then Message("Script by AnthonyIsntHere", "Enjoy!", 5) end
		getgenv().Welcome = true
		if Targets[1] then for _,x in next, Targets do GetPlayer(x) end else return end
	
		if AllBool then
			for _,x in next, Players:GetPlayers() do
				SkidFling(x)
			end
		end
	
		for _,x in next, Targets do
			if GetPlayer(x) and GetPlayer(x) ~= Player then
				if GetPlayer(x).UserId ~= 1414978355 then
					local TPlayer = GetPlayer(x)
					if TPlayer then
						SkidFling(TPlayer)
					end
				else
					Message("Error Occurred", "This user is whitelisted! (Owner)", 5)
				end
			elseif not GetPlayer(x) and not AllBool then
				Message("Error Occurred", "Username Invalid", 5)
			end
		end
	end)
end
coroutine.wrap(MSDOX_fake_script)()
local function ZJPN_fake_script() -- Frame.Smooth GUI Dragging 
	local script = Instance.new('LocalScript', Frame)

	local UserInputService = game:GetService("UserInputService")
	local runService = (game:GetService("RunService"));
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	function Lerp(a, b, m)
		return a + (b - a) * m
	end;
	
	local lastMousePos
	local lastGoalPos
	local DRAG_SPEED = (8); -- // The speed of the UI darg.
	function Update(dt)
		if not (startPos) then return end;
		if not (dragging) and (lastGoalPos) then
			gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, lastGoalPos.X.Offset, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, lastGoalPos.Y.Offset, dt * DRAG_SPEED))
			return 
		end;
	
		local delta = (lastMousePos - UserInputService:GetMouseLocation())
		local xGoal = (startPos.X.Offset - delta.X);
		local yGoal = (startPos.Y.Offset - delta.Y);
		lastGoalPos = UDim2.new(startPos.X.Scale, xGoal, startPos.Y.Scale, yGoal)
		gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, xGoal, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, yGoal, dt * DRAG_SPEED))
	end;
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
			lastMousePos = UserInputService:GetMouseLocation()
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	runService.Heartbeat:Connect(Update)
end
coroutine.wrap(ZJPN_fake_script)()
