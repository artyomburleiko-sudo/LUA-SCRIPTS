local targetName = "введи_ник_здесь"

local Players = game:GetService("Players")

local function getPlayerByName(name)
    for _, player in pairs(Players:GetPlayers()) do
        if string.lower(player.Name) == string.lower(name) or string.lower(player.DisplayName) == string.lower(name) then
            return player
        end
    end
    return nil
end

local function setJumpPower(playerName, jumpPower)
    local target = getPlayerByName(playerName)
    if target and target.Character and target.Character:FindFirstChild("Humanoid") then
        target.Character.Humanoid.JumpPower = jumpPower
    end
end

setJumpPower(targetName, 100)