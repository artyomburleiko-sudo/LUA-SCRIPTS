-- Script made by PlaicGotHacked. If you wanna be a butthurt and remove this do it. --

local Player = game.Players.LocalPlayer
local Character = Player.Character
local Humanoid = Character.Humanoid

print('Godmode working.')

Humanoid.MaxHealth = 999999
Humanoid.Health = Humanoid.MaxHealth / 1

Humanoid.HealthChanged:connect(function()
	if Humanoid.Health < 10 then
		Humanoid.Health = Humanoid.MaxHealth
	end
end)