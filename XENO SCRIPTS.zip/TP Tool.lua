-- Создание основного GUI
local player = game.Players.LocalPlayer
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "TPToolGUI"
screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.ResetOnSpawn = false -- GUI не исчезает при смерти персонажа

-- Создание главного фрейма
local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 250, 0, 130) -- Увеличил размер для дополнительного текста
mainFrame.Position = UDim2.new(0.5, -125, 0.5, -65)
mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
mainFrame.BackgroundTransparency = 0.2
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

-- Делаем фрейм круглым
local uiCorner = Instance.new("UICorner")
uiCorner.CornerRadius = UDim.new(0, 10)
uiCorner.Parent = mainFrame

-- Заголовок
local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, 0, 0, 30)
titleLabel.Position = UDim2.new(0, 0, 0, 0)
titleLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
titleLabel.BackgroundTransparency = 0.3
titleLabel.Text = "TP Tool"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.TextScaled = true
titleLabel.Font = Enum.Font.GothamBold
titleLabel.Parent = mainFrame

-- Скругление для заголовка
local titleCorner = Instance.new("UICorner")
titleCorner.CornerRadius = UDim.new(0, 10)
titleCorner.Parent = titleLabel

-- Информация о горячих клавишах
local hotkeyLabel = Instance.new("TextLabel")
hotkeyLabel.Size = UDim2.new(1, 0, 0, 15)
hotkeyLabel.Position = UDim2.new(0, 0, 0.25, 0)
hotkeyLabel.BackgroundTransparency = 1
hotkeyLabel.Text = "H: ON | R: OFF"
hotkeyLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
hotkeyLabel.TextScaled = true
hotkeyLabel.Font = Enum.Font.Gotham
hotkeyLabel.Parent = mainFrame

-- Кнопка Start
local startButton = Instance.new("TextButton")
startButton.Size = UDim2.new(0.8, 0, 0, 25)
startButton.Position = UDim2.new(0.1, 0, 0.45, 0)
startButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
startButton.Text = "Start TP Tool (H)"
startButton.TextColor3 = Color3.fromRGB(255, 255, 255)
startButton.TextScaled = true
startButton.Font = Enum.Font.Gotham
startButton.Parent = mainFrame

-- Скругление для кнопки Start
local startCorner = Instance.new("UICorner")
startCorner.CornerRadius = UDim.new(0, 5)
startCorner.Parent = startButton

-- Кнопка Stop
local stopButton = Instance.new("TextButton")
stopButton.Size = UDim2.new(0.8, 0, 0, 25)
stopButton.Position = UDim2.new(0.1, 0, 0.75, 0)
stopButton.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
stopButton.Text = "Stop TP Tool (R)"
stopButton.TextColor3 = Color3.fromRGB(255, 255, 255)
stopButton.TextScaled = true
stopButton.Font = Enum.Font.Gotham
stopButton.Parent = mainFrame

-- Скругление для кнопки Stop
local stopCorner = Instance.new("UICorner")
stopCorner.CornerRadius = UDim.new(0, 5)
stopCorner.Parent = stopButton

-- Переменная для отслеживания состояния
local teleportEnabled = false

-- Функция обновления внешнего вида кнопок
local function updateButtons()
    if teleportEnabled then
        startButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
        stopButton.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
        startButton.Text = "TP Tool ACTIVE (H)"
    else
        startButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
        stopButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
        startButton.Text = "Start TP Tool (H)"
    end
end

-- Функция включения телепорта
local function enableTeleport()
    teleportEnabled = true
    updateButtons()
    -- Визуальный эффект для всего окна
    mainFrame.BackgroundColor3 = Color3.fromRGB(30, 50, 30)
    wait(0.2)
    mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
end

-- Функция выключения телепорта
local function disableTeleport()
    teleportEnabled = false
    updateButtons()
    -- Визуальный эффект для всего окна
    mainFrame.BackgroundColor3 = Color3.fromRGB(50, 30, 30)
    wait(0.2)
    mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
end

-- Функция телепортации
local function teleportToMouse()
    if teleportEnabled then
        local character = player.Character
        if character and character:FindFirstChild("HumanoidRootPart") then
            local mouse = player:GetMouse()
            local targetPosition = mouse.Hit.p
            character.HumanoidRootPart.CFrame = CFrame.new(targetPosition)
            
            -- Визуальный эффект при телепортации
            local humanoid = character:FindFirstChild("Humanoid")
            if humanoid then
                humanoid.WalkSpeed = 0
                wait(0.1)
                humanoid.WalkSpeed = 16
            end
        end
    end
end

-- Обработчик кликов мыши
game:GetService("UserInputService").InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        teleportToMouse()
    end
end)

-- Обработчик горячих клавиш
game:GetService("UserInputService").InputBegan:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.H then
        enableTeleport()
    elseif input.KeyCode == Enum.KeyCode.R then
        disableTeleport()
    end
end)

-- Обработчики кнопок
startButton.MouseButton1Click:Connect(enableTeleport)
stopButton.MouseButton1Click:Connect(disableTeleport)

-- Эффекты наведения на кнопки
startButton.MouseEnter:Connect(function()
    startButton.BackgroundColor3 = Color3.fromRGB(0, 200, 0)
end)

startButton.MouseLeave:Connect(function()
    if teleportEnabled then
        startButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
    else
        startButton.BackgroundColor3 = Color3.fromRGB(0, 170, 0)
    end
end)

stopButton.MouseEnter:Connect(function()
    stopButton.BackgroundColor3 = Color3.fromRGB(200, 0, 0)
end)

stopButton.MouseLeave:Connect(function()
    if not teleportEnabled then
        stopButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
    else
        stopButton.BackgroundColor3 = Color3.fromRGB(170, 0, 0)
    end
end)

-- Добавляем возможность сворачивать/разворачивать окно по двойному клику на заголовок
titleLabel.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        input:Wait() -- Ждем отпускания кнопки
        local timeBetween = input.Time - input.Time
        if timeBetween < 0.3 then -- Если прошло меньше 0.3 секунды (двойной клик)
            mainFrame.Visible = not mainFrame.Visible
        end
    end
end)

-- Создаем маленькую кнопку для показа окна, если оно скрыто
local toggleButton = Instance.new("TextButton")
toggleButton.Size = UDim2.new(0, 50, 0, 25)
toggleButton.Position = UDim2.new(0, 10, 0, 10)
toggleButton.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
toggleButton.BackgroundTransparency = 0.3
toggleButton.Text = "TP"
toggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
toggleButton.TextScaled = true
toggleButton.Font = Enum.Font.GothamBold
toggleButton.Visible = false
toggleButton.Parent = screenGui

local toggleCorner = Instance.new("UICorner")
toggleCorner.CornerRadius = UDim.new(0, 5)
toggleCorner.Parent = toggleButton

-- Функция для показа/скрытия окна
local function toggleMainFrame()
    mainFrame.Visible = not mainFrame.Visible
    toggleButton.Visible = not mainFrame.Visible
end

-- Обработчик для маленькой кнопки
toggleButton.MouseButton1Click:Connect(toggleMainFrame)

-- Обновляем обработчик двойного клика
titleLabel.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        local startTime = tick()
        input:Wait() -- Ждем отпускания кнопки
        if tick() - startTime < 0.3 then -- Если прошло меньше 0.3 секунды
            toggleMainFrame()
        end
    end
end)

-- Уведомление о загрузке
print("TP Tool GUI loaded! Press H to enable, R to disable teleport.")