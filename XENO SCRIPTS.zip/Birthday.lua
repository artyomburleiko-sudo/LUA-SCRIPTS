-- 🎂 BIRTHDAY CELEBRATION SCRIPT 🎂
-- Создано специально для твоего Дня Рождения!
-- Вставь в LocalScript в StarterGui

local Players = game:GetService("Players")
local Lighting = game:GetService("Lighting")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Debris = game:GetService("Debris")
local player = Players.LocalPlayer

-- 🔧 НАСТРОЙКИ ПРАЗДНИКА 🔧
local BIRTHDAY_MODE = true
local CONFETTI_COUNT = 100
local FIREWORK_COUNT = 20
local CAKE_RAIN_DURATION = 30 -- секунд

print("🎉🎂 С ДНЕМ РОЖДЕНИЯ! 🎂🎉")
print("Запускаем праздничный режим...")

-- 🎵 ПРАЗДНИЧНАЯ МУЗЫКА 🎵
local function playBirthdayMusic()
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://9116398378" -- Happy Birthday музыка
    sound.Volume = 0.5
    sound.Looped = true
    sound.Parent = workspace
    sound:Play()
    return sound
end

-- 🎆 СИСТЕМА САЛЮТОВ 🎆
local function createFirework(position)
    local firework = Instance.new("Part")
    firework.Size = Vector3.new(0.5, 0.5, 0.5)
    firework.Position = position + Vector3.new(0, 10, 0)
    firework.Anchored = true
    firework.CanCollide = false
    firework.Material = Enum.Material.Neon
    firework.Color = Color3.fromHSV(math.random(), 1, 1)
    firework.Parent = workspace
    
    spawn(function()
        wait(math.random(1, 3))
        -- Взрыв салюта
        for i = 1, 20 do
            local spark = Instance.new("Part")
            spark.Size = Vector3.new(0.2, 0.2, 0.2)
            spark.Position = firework.Position
            spark.Anchored = true
            spark.CanCollide = false
            spark.Material = Enum.Material.Neon
            spark.Color = Color3.fromHSV(math.random(), 1, 1)
            spark.Parent = workspace
            
            local direction = Vector3.new(
                math.random(-10, 10),
                math.random(-10, 10),
                math.random(-10, 10)
            ).Unit
            
            local tween = TweenService:Create(
                spark,
                TweenInfo.new(1),
                {Position = firework.Position + direction * 10}
            )
            tween:Play()
            Debris:AddItem(spark, 1.5)
        end
        firework:Destroy()
    end)
end

-- 🎊 КОНФЕТТИ ДОЖДЬ 🎊
local function createConfettiRain()
    for i = 1, CONFETTI_COUNT do
        spawn(function()
            local confetti = Instance.new("Part")
            confetti.Size = Vector3.new(0.3, 0.3, 0.3)
            confetti.Position = player.Character.HumanoidRootPart.Position + 
                               Vector3.new(math.random(-20, 20), 30, math.random(-20, 20))
            confetti.Anchored = false
            confetti.CanCollide = false
            confetti.Material = Enum.Material.Neon
            confetti.Color = Color3.fromHSV(i/CONFETTI_COUNT, 1, 1)
            confetti.Shape = Enum.PartType.Ball
            confetti.Parent = workspace
            
            local bodyForce = Instance.new("BodyForce")
            bodyForce.Force = Vector3.new(0, confetti:GetMass() * 196.2, 0)
            bodyForce.Parent = confetti
            
            Debris:AddItem(confetti, 5)
        end)
        wait(0.1)
    end
end

-- 🍰 ТОРТИКИ С НЕБА 🍰
local function cakeRain()
    print("🍰 Начинается дождь из тортиков! 🍰")
    for i = 1, CAKE_RAIN_DURATION do
        spawn(function()
            local cake = Instance.new("Part")
            cake.Size = Vector3.new(2, 1, 2)
            cake.Position = player.Character.HumanoidRootPart.Position + 
                           Vector3.new(math.random(-50, 50), 100, math.random(-50, 50))
            cake.Anchored = false
            cake.CanCollide = true
            cake.Material = Enum.Material.SmoothPlastic
            cake.Color = Color3.fromRGB(255, 200, 150)
            cake.Name = "BirthdayCake"
            cake.Parent = workspace
            
            -- Декорация торта
            local top = Instance.new("Part")
            top.Size = Vector3.new(1.8, 0.3, 1.8)
            top.Position = cake.Position + Vector3.new(0, 0.7, 0)
            top.Anchored = true
            top.CanCollide = false
            top.Color = Color3.fromRGB(255, 100, 150)
            top.Material = Enum.Material.Neon
            top.Parent = cake
            
            -- Свечка
            local candle = Instance.new("Part")
            candle.Size = Vector3.new(0.1, 0.5, 0.1)
            candle.Position = top.Position + Vector3.new(0, 0.3, 0)
            candle.Anchored = true
            candle.CanCollide = false
            candle.Color = Color3.fromRGB(255, 255, 0)
            candle.Material = Enum.Material.Neon
            candle.Parent = cake
            
            -- Огонек
            local fire = Instance.new("PointLight")
            fire.Parent = candle
            fire.Color = Color3.fromRGB(255, 200, 0)
            fire.Range = 5
            fire.Brightness = 2
            
            Debris:AddItem(cake, 10)
        end)
        wait(0.5)
    end
end

-- 🌈 ПРАЗДНИЧНАЯ ГИРЛЯНДА 🌈
local function createLightGarland()
    local garland = Instance.new("Model")
    garland.Name = "BirthdayGarland"
    for i = 1, 20 do
        local angle = (i / 20) * math.pi * 2
        local radius = 15
        local lightPart = Instance.new("Part")
        lightPart.Size = Vector3.new(0.5, 0.5, 0.5)
        lightPart.Position = player.Character.HumanoidRootPart.Position + 
            Vector3.new(
                math.cos(angle) * radius,
                5 + math.sin(i * 0.5) * 3,
                math.sin(angle) * radius
            )
        lightPart.Anchored = true
        lightPart.CanCollide = false
        lightPart.Material = Enum.Material.Neon
        lightPart.Color = Color3.fromHSV((i/20), 1, 1)
        lightPart.Shape = Enum.PartType.Ball
        lightPart.Parent = garland
        
        local pointLight = Instance.new("PointLight")
        pointLight.Parent = lightPart
        pointLight.Color = lightPart.Color
        pointLight.Range = 10
        pointLight.Brightness = 3
        
        -- Мигающая анимация
        spawn(function()
            while lightPart.Parent do
                pointLight.Brightness = 2 + math.sin(tick() * 5 + i) * 2
                wait()
            end
        end)
    end
    garland.Parent = workspace
    return garland
end

-- 🎭 ПРАЗДНИЧНЫЙ ГУЙ 🎭
local function createBirthdayGUI()
    local gui = Instance.new("ScreenGui")
    gui.Name = "BirthdayGUI"
    gui.Parent = player:WaitForChild("PlayerGui")
    
    -- Фон
    local background = Instance.new("Frame")
    background.Size = UDim2.new(1, 0, 1, 0)
    background.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    background.BackgroundTransparency = 0.7
    background.Parent = gui
    
    -- Поздравление
    local congrats = Instance.new("TextLabel")
    congrats.Size = UDim2.new(1, 0, 0.3, 0)
    congrats.Position = UDim2.new(0, 0, 0.35, 0)
    congrats.BackgroundTransparency = 1
    congrats.Text = "🎂 С ДНЕМ РОЖДЕНИЯ! 🎂"
    congrats.TextColor3 = Color3.fromRGB(255, 215, 0)
    congrats.TextScaled = true
    congrats.Font = Enum.Font.Fantasy
    congrats.TextStrokeTransparency = 0
    congrats.TextStrokeColor3 = Color3.fromRGB(255, 50, 150)
    congrats.Parent = gui
    
    -- Анимация текста
    spawn(function()
        local colors = {
            Color3.fromRGB(255, 50, 150),
            Color3.fromRGB(50, 200, 255),
            Color3.fromRGB(150, 255, 50),
            Color3.fromRGB(255, 255, 50)
        }
        local i = 1
        while true do
            congrats.TextColor3 = colors[i]
            i = i % #colors + 1
            wait(1)
        end
    end)
    
    -- Кнопки
    local buttonFrame = Instance.new("Frame")
    buttonFrame.Size = UDim2.new(0.4, 0, 0.3, 0)
    buttonFrame.Position = UDim2.new(0.3, 0, 0.65, 0)
    buttonFrame.BackgroundTransparency = 1
    buttonFrame.Parent = gui
    
    local buttons = {
        {"🎆 Запустить салют", function() 
            for i=1,10 do 
                createFirework(player.Character.HumanoidRootPart.Position)
                wait(0.5)
            end 
        end},
        {"🎊 Конфетти дождь", createConfettiRain},
        {"🍰 Тортиковый дождь", cakeRain},
        {"✨ Волшебный режим", function() 
            BIRTHDAY_MODE = not BIRTHDAY_MODE 
            print("Волшебный режим: " .. (BIRTHDAY_MODE and "ВКЛ" or "ВЫКЛ")) 
        end},
        {"❌ Закрыть", function() 
            gui:Destroy() 
        end}
    }
    
    for i, buttonData in ipairs(buttons) do
        local button = Instance.new("TextButton")
        button.Size = UDim2.new(1, 0, 0, 40)
        button.Position = UDim2.new(0, 0, (i-1) * 0.25, 0)
        button.BackgroundColor3 = Color3.fromHSV(i/#buttons, 0.8, 0.8)
        button.Text = buttonData[1]
        button.TextColor3 = Color3.fromRGB(255, 255, 255)
        button.Font = Enum.Font.GothamBold
        button.TextSize = 14
        local corner = Instance.new("UICorner")
        corner.CornerRadius = UDim.new(0.2, 0)
        corner.Parent = button
        button.MouseButton1Click:Connect(buttonData[2])
        button.Parent = buttonFrame
    end
    return gui
end

-- 🌟 ВОЛШЕБНЫЙ РЕЖИМ ОКРУЖЕНИЯ 🌟
local function setBirthdayEnvironment()
    Lighting.Brightness = 2
    Lighting.OutdoorAmbient = Color3.fromRGB(150, 150, 255)
    Lighting.ColorShift_Top = Color3.fromRGB(255, 200, 200)
    Lighting.FogColor = Color3.fromRGB(200, 150, 255)
    Lighting.FogEnd = 500
    if Lighting:FindFirstChild("SunRays") then
        Lighting.SunRays.Intensity = 0.1
        Lighting.SunRays.Spread = 1
    end
end

-- 🎮 УПРАВЛЕНИЕ С КЛАВИАТУРЫ 🎮
local function setupControls()
    UserInputService.InputBegan:Connect(function(input, gameProcessed)
        if gameProcessed then return end
        if input.KeyCode == Enum.KeyCode.B then
            -- B - запуск салюта и конфетти
            for i=1,10 do
                createFirework(player.Character.HumanoidRootPart.Position)
                wait(0.3)
            end
        elseif input.KeyCode == Enum.KeyCode.C then
            -- C - дождь из тортиков
            cakeRain()
        elseif input.KeyCode == Enum.KeyCode.G then
            -- G - гирлянда
            createLightGarland()
        elseif input.KeyCode == Enum.KeyCode.P then
            -- P - праздничный танец
            local humanoid = player.Character:FindFirstChild("Humanoid")
            if humanoid then
                local animator = humanoid:FindFirstChild("Animator")
                if animator then
                    local animation = Instance.new("Animation")
                    animation.AnimationId = "rbxassetid://5918726674"
                    local dance = animator:LoadAnimation(animation)
                    dance:Play()
                    dance.Looped = true
                end
            end
        elseif input.KeyCode == Enum.KeyCode.H then
            -- H - суперсила
            local character = player.Character
            if character then
                local humanoid = character:FindFirstChild("Humanoid")
                if humanoid then
                    humanoid.WalkSpeed = 50
                    humanoid.JumpPower = 100
                    local glow = Instance.new("PointLight")
                    glow.Parent = character.HumanoidRootPart
                    glow.Color = Color3.fromRGB(255, 255, 0)
                    glow.Range = 20
                    glow.Brightness = 5
                    -- Возврат к норме через 30 сек
                    delay(30, function()
                        humanoid.WalkSpeed = 16
                        humanoid.JumpPower = 50
                        glow:Destroy()
                    end)
                end
            end
        end
    end)
end

-- ИНФОРМАЦИОННОЕ СООбЩЕНИЕ
local function showInstructions()
    print("\n" .. string.rep("=", 50))
    print("🎉🎂 СИСТЕМА ПОЗДРАВЛЕНИЙ АКТИВИРОВАНА! 🎂🎉")
    print("Управление:")
    print("  B - Запустить конфетти и салют")
    print("  C - Дождь из тортиков")
    print("  G - Волшебная гирлянда")
    print("  P - Праздничный танец")
    print("  H - Получить суперсилу")
    print("  GUI - Используй кнопки на экране")
    print("  ❌ - закрыть окно")
    print(string.rep("=", 50))
end

-- 🚀 ЗАПУСК ВСЕХ СИСТЕМ 🚀
wait(2)
local birthdayGUI = createBirthdayGUI()
local music = playBirthdayMusic()
setBirthdayEnvironment()
local garland = createLightGarland()
setupControls()
showInstructions()

-- Автозапуск эффектов
spawn(function()
    wait(3)
    createConfettiRain()
    while true do
        wait(10)
        if BIRTHDAY_MODE then
            createFirework(player.Character.HumanoidRootPart.Position + Vector3.new(math.random(-30, 30), 0, math.random(-30, 30)))
        end
    end
end)