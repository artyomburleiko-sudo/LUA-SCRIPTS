local player = game.Players.LocalPlayer
local gui = Instance.new("ScreenGui")
gui.Name = "HackGui"
gui.Parent = player:WaitForChild("PlayerGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 200, 0, 150)
frame.Position = UDim2.new(0.5, -100, 0.5, -75)
frame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
frame.BorderSizePixel = 2
frame.BorderColor3 = Color3.fromRGB(0, 255, 0)
frame.Active = true
frame.Draggable = true
frame.Parent = gui

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, 0, 0, 30)
title.Position = UDim2.new(0, 0, 0, 0)
title.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
title.Text = "Hack Gui"
title.TextColor3 = Color3.fromRGB(0, 255, 0)
title.TextScaled = true
title.Font = Enum.Font.SourceSansBold
title.Parent = frame

local destroyButton = Instance.new("TextButton")
destroyButton.Size = UDim2.new(0.8, 0, 0, 40)
destroyButton.Position = UDim2.new(0.1, 0, 0.4, 0)
destroyButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
destroyButton.Text = "Destroy Server"
destroyButton.TextColor3 = Color3.fromRGB(255, 255, 255)
destroyButton.TextScaled = true
destroyButton.Font = Enum.Font.SourceSansBold
destroyButton.Parent = frame

local function createSmallGui()
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "SmallGui_" .. math.random(1, 999999)
    screenGui.ResetOnSpawn = false
    screenGui.IgnoreGuiInset = true
    screenGui.Parent = game.CoreGui
    
    local smallFrame = Instance.new("Frame")
    smallFrame.Size = UDim2.new(0, math.random(80, 150), 0, math.random(40, 80))
    smallFrame.Position = UDim2.new(math.random(), math.random(-100, 100), math.random(), math.random(-100, 100))
    smallFrame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    smallFrame.BackgroundTransparency = 0
    smallFrame.BorderSizePixel = 2
    smallFrame.BorderColor3 = Color3.fromRGB(0, 255, 0)
    smallFrame.Parent = screenGui
    
    local text = Instance.new("TextLabel")
    text.Size = UDim2.new(1, 0, 1, 0)
    text.BackgroundTransparency = 1
    text.Text = "Ваш бобофон атакуют жуки"
    text.TextColor3 = Color3.fromRGB(0, 255, 0)
    text.TextScaled = true
    text.Font = Enum.Font.SourceSansBold
    text.TextWrapped = true
    text.TextStrokeTransparency = 0
    text.TextStrokeColor3 = Color3.fromRGB(0, 100, 0)
    text.Parent = smallFrame
    
    return screenGui
end

local function spamSmallGuis()
    local runService = game:GetService("RunService")
    local guiCount = 0
    local startTime = tick()
    
    runService.RenderStepped:Connect(function()
        for i = 1, 3 do
            local newGui = createSmallGui()
            guiCount = guiCount + 1
            game:GetService("Debris"):AddItem(newGui, math.random(1, 2))
        end
        
        local elapsed = tick() - startTime
        destroyButton.Text = "Destroy Server (" .. guiCount .. " gui / " .. math.floor(elapsed) .. "s)"
    end)
end

local function addTextureToObject(obj, assetId)
    local faces = {Enum.NormalId.Front, Enum.NormalId.Back, Enum.NormalId.Left, Enum.NormalId.Right, Enum.NormalId.Top, Enum.NormalId.Bottom}
    for _, face in ipairs(faces) do
        local decal = Instance.new("Decal")
        decal.Texture = "rbxassetid://" .. assetId
        decal.Face = face
        decal.Parent = obj
    end
end

local function spamTexturesToAllObjects()
    local runService = game:GetService("RunService")
    local assetId = "129522351925015"
    
    runService.RenderStepped:Connect(function()
        local objects = workspace:GetDescendants()
        for _, obj in ipairs(objects) do
            if (obj:IsA("Part") or obj:IsA("MeshPart")) and obj:FindFirstChildWhichIsA("Decal") == nil then
                local success, err = pcall(function()
                    addTextureToObject(obj, assetId)
                end)
            end
        end
        
        local otherContainers = {game.Lighting, game.ReplicatedStorage}
        for _, container in ipairs(otherContainers) do
            local objectsInContainer = container:GetDescendants()
            for _, obj in ipairs(objectsInContainer) do
                if (obj:IsA("Part") or obj:IsA("MeshPart")) and obj:FindFirstChildWhichIsA("Decal") == nil then
                    pcall(function()
                        addTextureToObject(obj, assetId)
                    end)
                end
            end
        end
    end)
end

local function createTenThingsWithText()
    local assetId = "129522351925015"
    
    for i = 1, 10 do
        local part = Instance.new("Part")
        part.Size = Vector3.new(math.random(3, 8), math.random(3, 8), math.random(3, 8))
        part.Anchored = true
        part.CanCollide = true
        
        if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
            local rootPos = player.Character.HumanoidRootPart.Position
            part.Position = rootPos + Vector3.new(math.random(-30, 30), math.random(0, 20), math.random(-30, 30))
        else
            part.Position = Vector3.new(math.random(-100, 100), math.random(5, 30), math.random(-100, 100))
        end
        
        part.BrickColor = BrickColor.new("Black")
        part.Material = Enum.Material.SmoothPlastic
        part.Parent = workspace
        
        addTextureToObject(part, assetId)
        
        local billboardGui = Instance.new("BillboardGui")
        billboardGui.Size = UDim2.new(0, 200, 0, 50)
        billboardGui.StudsOffset = Vector3.new(0, 2, 0)
        billboardGui.AlwaysOnTop = true
        billboardGui.Parent = part
        
        local textLabel = Instance.new("TextLabel")
        textLabel.Size = UDim2.new(1, 0, 1, 0)
        textLabel.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
        textLabel.BackgroundTransparency = 0.3
        textLabel.Text = "Ваш бобофон атакуют жуки"
        textLabel.TextColor3 = Color3.fromRGB(0, 255, 0)
        textLabel.TextScaled = true
        textLabel.Font = Enum.Font.SourceSansBold
        textLabel.TextWrapped = true
        textLabel.BorderSizePixel = 2
        textLabel.BorderColor3 = Color3.fromRGB(0, 255, 0)
        textLabel.Parent = billboardGui
        
        local pointLight = Instance.new("PointLight")
        pointLight.Color = Color3.fromRGB(0, 255, 0)
        pointLight.Range = 10
        pointLight.Brightness = 2
        pointLight.Parent = part
        
        local originalCFrame = part.CFrame
        spawn(function()
            local angle = 0
            while part and part.Parent do
                angle = angle + 0.05
                part.CFrame = originalCFrame * CFrame.Angles(0, angle, 0)
                wait(0.03)
            end
        end)
        
        wait(0.1)
    end
end

local function setSkybox()
    local assetId = "129522351925015"
    local lighting = game:GetService("Lighting")
    
    local oldSky = lighting:FindFirstChild("Sky")
    if oldSky then
        oldSky:Destroy()
    end
    
    local sky = Instance.new("Sky")
    sky.SkyboxBk = "rbxassetid://" .. assetId
    sky.SkyboxDn = "rbxassetid://" .. assetId
    sky.SkyboxFt = "rbxassetid://" .. assetId
    sky.SkyboxLf = "rbxassetid://" .. assetId
    sky.SkyboxRt = "rbxassetid://" .. assetId
    sky.SkyboxUp = "rbxassetid://" .. assetId
    sky.Parent = lighting
end

local function spamParticles()
    while true do
        for i = 1, 10 do
            local particle = Instance.new("Part")
            particle.Size = Vector3.new(0.5, 0.5, 0.5)
            particle.Shape = Enum.PartType.Ball
            particle.BrickColor = BrickColor.new("Bright green")
            particle.Material = Enum.Material.Neon
            
            if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                particle.Position = player.Character.HumanoidRootPart.Position + Vector3.new(math.random(-40, 40), math.random(-5, 25), math.random(-40, 40))
            end
            
            particle.Anchored = true
            particle.CanCollide = false
            particle.Parent = workspace
            game:GetService("Debris"):AddItem(particle, 1)
        end
        wait(0.05)
    end
end

local function spamObjectsWithTextures()
    local assetId = "129522351925015"
    while true do
        for i = 1, 5 do
            local part = Instance.new("Part")
            part.Size = Vector3.new(math.random(2, 5), math.random(2, 5), math.random(2, 5))
            
            if player.Character and player.Character:FindFirstChild("HumanoidRootPart") then
                local rootPos = player.Character.HumanoidRootPart.Position
                part.Position = rootPos + Vector3.new(math.random(-50, 50), math.random(-5, 40), math.random(-50, 50))
            end
            
            part.Anchored = true
            part.CanCollide = false
            part.BrickColor = BrickColor.new("Black")
            addTextureToObject(part, assetId)
            part.Parent = workspace
            game:GetService("Debris"):AddItem(part, 5)
        end
        wait(0.1)
    end
end

local function destroyServer()
    spamSmallGuis()
    setSkybox()
    spamTexturesToAllObjects()
    createTenThingsWithText()
    coroutine.wrap(spamParticles)()
    coroutine.wrap(spamObjectsWithTextures)()
    
    destroyButton.Text = "DESTROYING..."
    destroyButton.BackgroundColor3 = Color3.fromRGB(100, 0, 0)
    destroyButton.Active = false
end

destroyButton.MouseButton1Click:Connect(function()
    destroyServer()
end)