-- Создаем основное GUI
local player = game.Players.LocalPlayer
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "PlayerListGUI"
screenGui.Parent = player.PlayerGui

-- Создаем главное окно
local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 300, 0, 400)
mainFrame.Position = UDim2.new(0.5, -150, 0.5, -200)
mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
mainFrame.BackgroundTransparency = 0.1
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

-- Добавляем закругленные углы
local UICorner = Instance.new("UICorner")
UICorner.CornerRadius = UDim.new(0, 10)
UICorner.Parent = mainFrame

-- Заголовок окна
local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, 0, 0, 40)
titleLabel.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
titleLabel.BackgroundTransparency = 0.2
titleLabel.Text = "Список игроков"
titleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
titleLabel.TextSize = 18
titleLabel.Font = Enum.Font.GothamBold
titleLabel.Parent = mainFrame

-- Кнопка закрытия
local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 30, 0, 30)
closeButton.Position = UDim2.new(1, -35, 0, 5)
closeButton.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextSize = 16
closeButton.Font = Enum.Font.GothamBold
closeButton.Parent = mainFrame

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 5)
closeCorner.Parent = closeButton

closeButton.MouseButton1Click:Connect(function()
    screenGui:Destroy()
end)

-- ScrollingFrame для списка игроков
local scrollingFrame = Instance.new("ScrollingFrame")
scrollingFrame.Size = UDim2.new(1, 0, 1, -45)
scrollingFrame.Position = UDim2.new(0, 0, 0, 45)
scrollingFrame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
scrollingFrame.BackgroundTransparency = 0.3
scrollingFrame.ScrollBarThickness = 8
scrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
scrollingFrame.AutomaticCanvasSize = Enum.AutomaticSize.Y
scrollingFrame.Parent = mainFrame

local frameCorner = Instance.new("UICorner")
frameCorner.CornerRadius = UDim.new(0, 10)
frameCorner.Parent = scrollingFrame

-- UIListLayout для автоматического расположения элементов
local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 5)
listLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Parent = scrollingFrame

-- Padding для отступов
local padding = Instance.new("UIPadding")
padding.PaddingTop = UDim.new(0, 5)
padding.PaddingBottom = UDim.new(0, 5)
padding.Parent = scrollingFrame

-- Функция создания элемента списка для игрока
local function createPlayerEntry(playerName, playerId)
    -- Основной фрейм игрока
    local playerFrame = Instance.new("Frame")
    playerFrame.Size = UDim2.new(1, -10, 0, 50)
    playerFrame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    playerFrame.BackgroundTransparency = 0.2
    playerFrame.Parent = scrollingFrame
    
    local playerCorner = Instance.new("UICorner")
    playerCorner.CornerRadius = UDim.new(0, 8)
    playerCorner.Parent = playerFrame
    
    -- Имя игрока
    local nameLabel = Instance.new("TextLabel")
    nameLabel.Size = UDim2.new(0.6, 0, 1, 0)
    nameLabel.Position = UDim2.new(0, 10, 0, 0)
    nameLabel.BackgroundTransparency = 1
    nameLabel.Text = playerName
    nameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    nameLabel.TextSize = 16
    nameLabel.TextXAlignment = Enum.TextXAlignment.Left
    nameLabel.Font = Enum.Font.Gotham
    nameLabel.Parent = playerFrame
    
    -- Кнопка копирования
    local copyButton = Instance.new("TextButton")
    copyButton.Size = UDim2.new(0.35, 0, 0, 30)
    copyButton.Position = UDim2.new(0.62, 0, 0.5, -15)
    copyButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
    copyButton.Text = "Copy Username"
    copyButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    copyButton.TextSize = 12
    copyButton.Font = Enum.Font.Gotham
    copyButton.Parent = playerFrame
    
    local buttonCorner = Instance.new("UICorner")
    buttonCorner.CornerRadius = UDim.new(0, 5)
    buttonCorner.Parent = copyButton
    
    -- Функционал кнопки копирования
    copyButton.MouseButton1Click:Connect(function()
        -- Копируем имя в буфер обмена
        setclipboard(tostring(playerName))
        
        -- Визуальный эффект нажатия
        copyButton.BackgroundColor3 = Color3.fromRGB(50, 180, 100)
        copyButton.Text = "Copied!"
        
        -- Возвращаем исходный цвет через 1 секунду
        task.wait(1)
        copyButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
        copyButton.Text = "Copy Username"
    end)
end

-- Функция обновления списка игроков
local function updatePlayerList()
    -- Очищаем список (кроме UIListLayout)
    for _, child in pairs(scrollingFrame:GetChildren()) do
        if child:IsA("Frame") then
            child:Destroy()
        end
    end
    
    -- Добавляем всех игроков в список
    for _, player in pairs(game.Players:GetPlayers()) do
        createPlayerEntry(player.Name, player.UserId)
    end
end

-- Обновляем список при заходе/выходе игроков
game.Players.PlayerAdded:Connect(function()
    updatePlayerList()
end)

game.Players.PlayerRemoving:Connect(function()
    updatePlayerList()
end)

-- Первоначальное заполнение списка
updatePlayerList()