local player = game.Players.LocalPlayer
local replicatedStorage = game:GetService("ReplicatedStorage")
local workspace = game:GetService("Workspace")
local lighting = game:GetService("Lighting")

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local Name = Instance.new("TextLabel")
local Credits = Instance.new("TextLabel")
local e1x1x1x1Message = Instance.new("TextButton")
local e1x1x1x1Music = Instance.new("TextButton")
local e1x1x1x1Laugh = Instance.new("TextButton")
local DayToNight = Instance.new("TextButton")
local e666 = Instance.new("TextButton")
local EpicSaxGuy = Instance.new("TextButton")
local Disc0 = Instance.new("TextButton")
local e2006Theme = Instance.new("TextButton")
local ForceField = Instance.new("TextButton")

--Properties:
ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Frame.Position = UDim2.new(0.382171214, 0, 0.328530252, 0)
Frame.Size = UDim2.new(0, 378, 0, 250)
Frame.Active = true
Frame.Draggable = true

Name.Name = "Name"
Name.Parent = Frame
Name.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
Name.Size = UDim2.new(0, 378, 0, 25)
Name.Font = Enum.Font.GothamBold
Name.Text = "1x1x1x1 GUI (NO ADMIN)"
Name.TextColor3 = Color3.fromRGB(0, 0, 0)
Name.TextScaled = true
Name.TextWrapped = true

Credits.Name = "Credits"
Credits.Parent = Frame
Credits.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
Credits.Position = UDim2.new(0, 0, 0.912, 0)
Credits.Size = UDim2.new(0, 378, 0, 22)
Credits.Font = Enum.Font.GothamBold
Credits.Text = "By Albert134542 (Modified for No Admin)"
Credits.TextColor3 = Color3.fromRGB(0, 0, 0)
Credits.TextScaled = true
Credits.TextWrapped = true

-- Функция для создания сообщений в чат
function sendChatMessage(message)
    local args = {
        [1] = message,
        [2] = "All"
    }
    game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(unpack(args))
end

-- Функция для воспроизведения звука
function playSound(soundId, pitch, volume)
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://" .. soundId
    sound.Volume = volume or 1
    sound.Pitch = pitch or 1
    sound.Parent = workspace
    sound:Play()
    
    -- Автоматическое удаление после окончания
    sound.Ended:Connect(function()
        sound:Destroy()
    end)
end

e1x1x1x1Message.Name = "e1x1x1x1Message"
e1x1x1x1Message.Parent = Frame
e1x1x1x1Message.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
e1x1x1x1Message.Position = UDim2.new(0.0714285746, 0, 0.216000006, 0)
e1x1x1x1Message.Size = UDim2.new(0, 79, 0, 31)
e1x1x1x1Message.Font = Enum.Font.GothamBold
e1x1x1x1Message.Text = "1x1x1x1 Message"
e1x1x1x1Message.TextColor3 = Color3.fromRGB(0, 0, 0)
e1x1x1x1Message.TextScaled = true
e1x1x1x1Message.TextWrapped = true

e1x1x1x1Message.MouseButton1Down:Connect(function()
    wait(12)
    sendChatMessage("1x1x1x1: MUHAWHAWHAW! NOOBS! I HAVE RETURNED FOR MY REVENGE!")
    wait(10)
    sendChatMessage("1x1x1x1: NOW YOU WILL ALL PERISH IN MY FIRE OF DOOM!")
    wait(10)
    sendChatMessage("1x1x1x1: I WILL DESTROY YOU ALL! YOU ARE WORTHLESS!")
    wait(10)
    sendChatMessage("1x1x1x1: YOU WILL NOT LIVE THROUGH MY DEADLY ATTACKS!")
    wait(10)
    sendChatMessage("1x1x1x1: I MIGHT AS WELL CLONE YOU INTO BOTS!")
    wait(10)
    sendChatMessage("1x1x1x1: AND THEN THOSE BOTS WILL DESTROY ROBLOX! HAHAHAHAHA!")
    wait(10)
    sendChatMessage("1x1x1x1: YOU CAN'T STOP ME! THERE'S NOTHING YOU CAN DO!")
end)

e1x1x1x1Music.Name = "e1x1x1x1Music"
e1x1x1x1Music.Parent = Frame
e1x1x1x1Music.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
e1x1x1x1Music.Position = UDim2.new(0.0714285746, 0, 0.436000019, 0)
e1x1x1x1Music.Size = UDim2.new(0, 79, 0, 31)
e1x1x1x1Music.Font = Enum.Font.GothamBold
e1x1x1x1Music.Text = "1x1x1x1 Music"
e1x1x1x1Music.TextColor3 = Color3.fromRGB(0, 0, 0)
e1x1x1x1Music.TextScaled = true
e1x1x1x1Music.TextWrapped = true

e1x1x1x1Music.MouseButton1Down:Connect(function()
    playSound("139488665764275", 1, 10)
end)

e1x1x1x1Laugh.Name = "e1x1x1x1Laugh"
e1x1x1x1Laugh.Parent = Frame
e1x1x1x1Laugh.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
e1x1x1x1Laugh.Position = UDim2.new(0.0714285746, 0, 0.648000002, 0)
e1x1x1x1Laugh.Size = UDim2.new(0, 79, 0, 34)
e1x1x1x1Laugh.Font = Enum.Font.GothamBold
e1x1x1x1Laugh.Text = "1x1x1x1 Laugh"
e1x1x1x1Laugh.TextColor3 = Color3.fromRGB(0, 0, 0)
e1x1x1x1Laugh.TextScaled = true
e1x1x1x1Laugh.TextWrapped = true

e1x1x1x1Laugh.MouseButton1Down:Connect(function()
    playSound("35935204", 0.9, 10)
end)

DayToNight.Name = "DayToNight"
DayToNight.Parent = Frame
DayToNight.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
DayToNight.Position = UDim2.new(0.388888896, 0, 0.216000006, 0)
DayToNight.Size = UDim2.new(0, 83, 0, 31)
DayToNight.Font = Enum.Font.GothamBold
DayToNight.Text = "Night"
DayToNight.TextColor3 = Color3.fromRGB(0, 0, 0)
DayToNight.TextScaled = true
DayToNight.TextWrapped = true

DayToNight.MouseButton1Down:Connect(function()
    lighting.ClockTime = 18
end)

e666.Name = "e666"
e666.Parent = Frame
e666.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
e666.Position = UDim2.new(0.388888896, 0, 0.43599999, 0)
e666.Size = UDim2.new(0, 83, 0, 31)
e666.Font = Enum.Font.GothamBold
e666.Text = "666"
e666.TextColor3 = Color3.fromRGB(0, 0, 0)
e666.TextScaled = true
e666.TextWrapped = true

e666.MouseButton1Down:Connect(function()
    lighting.ClockTime = 0
    
    -- Добавляем огонь на все части в Workspace
    for i, v in pairs(workspace:GetDescendants()) do
        if v:IsA("BasePart") and not v:IsA("Terrain") then
            local fire = Instance.new("Fire")
            fire.Parent = v
        end
    end
end)

EpicSaxGuy.Name = "EpicSaxGuy"
EpicSaxGuy.Parent = Frame
EpicSaxGuy.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
EpicSaxGuy.Position = UDim2.new(0.388888896, 0, 0.648000002, 0)
EpicSaxGuy.Size = UDim2.new(0, 83, 0, 34)
EpicSaxGuy.Font = Enum.Font.GothamBold
EpicSaxGuy.Text = "Epic Sax Guy"
EpicSaxGuy.TextColor3 = Color3.fromRGB(0, 0, 0)
EpicSaxGuy.TextScaled = true
EpicSaxGuy.TextWrapped = true

EpicSaxGuy.MouseButton1Down:Connect(function()
    playSound("99930819694048", 0.302, 10)
end)

Disc0.Name = "Disc0"
Disc0.Parent = Frame
Disc0.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
Disc0.Position = UDim2.new(0.693121672, 0, 0.216000006, 0)
Disc0.Size = UDim2.new(0, 89, 0, 31)
Disc0.Font = Enum.Font.GothamBold
Disc0.Text = "Disco"
Disc0.TextColor3 = Color3.fromRGB(0, 0, 0)
Disc0.TextScaled = true
Disc0.TextWrapped = true

Disc0.MouseButton1Down:Connect(function()
    -- Простой эффект диско
    local colors = {Color3.fromRGB(255,0,0), Color3.fromRGB(0,255,0), Color3.fromRGB(0,0,255), 
                    Color3.fromRGB(255,255,0), Color3.fromRGB(255,0,255), Color3.fromRGB(0,255,255)}
    
    for i = 1, 30 do
        lighting.Ambient = colors[math.random(1, #colors)]
        lighting.ColorShift_Top = colors[math.random(1, #colors)]
        lighting.ColorShift_Bottom = colors[math.random(1, #colors)]
        wait(0.3)
    end
    
    lighting.Ambient = Color3.fromRGB(0, 0, 0)
    lighting.ColorShift_Top = Color3.fromRGB(0, 0, 0)
    lighting.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
end)

e2006Theme.Name = "e2006Theme"
e2006Theme.Parent = Frame
e2006Theme.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
e2006Theme.Position = UDim2.new(0.693121672, 0, 0.43599999, 0)
e2006Theme.Size = UDim2.new(0, 89, 0, 31)
e2006Theme.Font = Enum.Font.GothamBold
e2006Theme.Text = "2006 Music"
e2006Theme.TextColor3 = Color3.fromRGB(0, 0, 0)
e2006Theme.TextScaled = true
e2006Theme.TextWrapped = true

e2006Theme.MouseButton1Down:Connect(function()
    playSound("125591252722564", 0.13, 10)
end)

ForceField.Name = "ForceField"
ForceField.Parent = Frame
ForceField.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
ForceField.Position = UDim2.new(0.693121672, 0, 0.648000002, 0)
ForceField.Size = UDim2.new(0, 89, 0, 34)
ForceField.Font = Enum.Font.GothamBold
ForceField.Text = "FF"
ForceField.TextColor3 = Color3.fromRGB(0, 0, 0)
ForceField.TextScaled = true
ForceField.TextWrapped = true

ForceField.MouseButton1Down:Connect(function()
    local ForceFieldGUI = Instance.new("ScreenGui")
    local ForceFieldGUI_2 = Instance.new("TextButton")
    local ForceFieldOFF = Instance.new("TextButton")
    local ForceFieldON = Instance.new("TextButton")

    ForceFieldGUI.Name = "ForceFieldGUI"
    ForceFieldGUI.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
    ForceFieldGUI.ResetOnSpawn = false

    ForceFieldGUI_2.Name = "ForceFieldGUI"
    ForceFieldGUI_2.Parent = ForceFieldGUI
    ForceFieldGUI_2.BackgroundColor3 = Color3.fromRGB(0, 255, 255)
    ForceFieldGUI_2.BackgroundTransparency = 0.300
    ForceFieldGUI_2.Position = UDim2.new(0, 0, 0, 240)
    ForceFieldGUI_2.Size = UDim2.new(0, 100, 0, 20)
    ForceFieldGUI_2.Font = Enum.Font.GothamBold
    ForceFieldGUI_2.Text = "ForceField"
    ForceFieldGUI_2.TextColor3 = Color3.fromRGB(17, 17, 17)
    ForceFieldGUI_2.TextTransparency = 0.300

    ForceFieldOFF.Name = "ForceFieldOFF"
    ForceFieldOFF.Parent = ForceFieldGUI
    ForceFieldOFF.BackgroundColor3 = Color3.fromRGB(253, 253, 253)
    ForceFieldOFF.BackgroundTransparency = 0.300
    ForceFieldOFF.Position = UDim2.new(0, 0, 0, 280)
    ForceFieldOFF.Size = UDim2.new(0, 100, 0, 20)
    ForceFieldOFF.Visible = false
    ForceFieldOFF.Font = Enum.Font.GothamBold
    ForceFieldOFF.Text = "Off"
    ForceFieldOFF.TextColor3 = Color3.fromRGB(17, 17, 17)

    ForceFieldON.Name = "ForceFieldON"
    ForceFieldON.Parent = ForceFieldGUI
    ForceFieldON.BackgroundColor3 = Color3.fromRGB(253, 253, 253)
    ForceFieldON.BackgroundTransparency = 0.300
    ForceFieldON.Position = UDim2.new(0, 0, 0, 260)
    ForceFieldON.Size = UDim2.new(0, 100, 0, 20)
    ForceFieldON.Visible = false
    ForceFieldON.Font = Enum.Font.GothamBold
    ForceFieldON.Text = "On"
    ForceFieldON.TextColor3 = Color3.fromRGB(17, 17, 17)

    -- Функционал кнопок
    ForceFieldGUI_2.MouseButton1Click:Connect(function()
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            ForceFieldOFF.Visible = true
            ForceFieldON.Visible = true
        end
    end)

    ForceFieldOFF.MouseButton1Click:Connect(function()
        if player.Character then
            local forceField = player.Character:FindFirstChildOfClass("ForceField")
            if forceField then
                forceField:Destroy()
            end
        end
        ForceFieldOFF.Visible = false
        ForceFieldON.Visible = false
    end)

    ForceFieldON.MouseButton1Click:Connect(function()
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            local FF = Instance.new("ForceField")
            FF.Parent = player.Character
        end
        ForceFieldOFF.Visible = false
        ForceFieldON.Visible = false
    end)
end)

-- Делаем фрейм перетаскиваемым
local UIS = game:GetService("UserInputService")
local dragging = false
local dragInput
local dragStart
local startPos

Frame.InputBegan:Connect(function(input)
    if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) and UIS:GetFocusedTextBox() == nil then
        dragging = true
        dragStart = input.Position
        startPos = Frame.Position
        
        input.Changed:Connect(function()
            if input.UserInputState == Enum.UserInputState.End then
                dragging = false
            end
        end)
    end
end)

Frame.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
        dragInput = input
    end
end)

UIS.InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        local delta = input.Position - dragStart
        Frame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end
end)