-- LocalScript (помести в StarterPlayerScripts или StarterCharacterScripts)
local player = game:GetService("Players").LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")

-- Функция создания эффекта льда
local function createIceEffect()
	-- Замораживаем персонажа
	humanoid.WalkSpeed = 0
	humanoid.JumpPower = 0
	
	local rootPart = character:FindFirstChild("HumanoidRootPart")
	if rootPart then
		rootPart.Anchored = true
	end
	
	-- Создаем ледяные части на всём персонаже
	local iceMaterials = {
		"Ice",
		"SmoothPlastic"
	}
	
	-- Проходим по всем частям персонажа
	for _, part in ipairs(character:GetDescendants()) do
		if part:IsA("BasePart") and part ~= rootPart then
			-- Сохраняем оригинальные свойства
			part:SetAttribute("OriginalMaterial", part.Material)
			part:SetAttribute("OriginalColor", part.Color)
			
			-- Применяем ледяной эффект
			part.Material = Enum.Material.Ice
			part.Color = Color3.fromRGB(180, 230, 255) -- Голубоватый цвет льда
			part.Transparency = 0.2 -- Немного прозрачности
			part.Reflectance = 0.3 -- Отражение как у льда
		end
	end
	
	-- Создаем дополнительные ледяные эффекты вокруг персонажа
	local iceParts = {}
	
	-- Создаем ледяные шипы на голове
	local head = character:FindFirstChild("Head")
	if head then
		local iceCrown = Instance.new("Part")
		iceCrown.Name = "IceCrown"
		iceCrown.Size = Vector3.new(2, 1, 2)
		iceCrown.Position = head.Position + Vector3.new(0, 1.5, 0)
		iceCrown.Anchored = true
		iceCrown.CanCollide = false
		iceCrown.Material = Enum.Material.Ice
		iceCrown.Color = Color3.fromRGB(200, 230, 255)
		iceCrown.Transparency = 0.1
		iceCrown.Reflectance = 0.4
		iceCrown.BrickColor = BrickColor.new("Cool blue")
		iceCrown.Parent = character
		
		-- Создаем ледяные шипы по кругу
		for i = 1, 8 do
			local angle = (i / 8) * math.pi * 2
			local spike = Instance.new("Part")
			spike.Name = "IceSpike"
			spike.Size = Vector3.new(0.5, 1.5, 0.5)
			spike.Position = head.Position + Vector3.new(math.sin(angle) * 1.2, 1, math.cos(angle) * 1.2)
			spike.Anchored = true
			spike.CanCollide = false
			spike.Material = Enum.Material.Ice
			spike.Color = Color3.fromRGB(170, 220, 255)
			spike.Transparency = 0.15
			spike.Reflectance = 0.35
			spike.BrickColor = BrickColor.new("Really blue")
			spike.Parent = character
			table.insert(iceParts, spike)
		end
		
		table.insert(iceParts, iceCrown)
	end
	
	-- Добавляем ледяные оковы на руки
	local arms = {
		character:FindFirstChild("Left Arm") or character:FindFirstChild("LeftHand"),
		character:FindFirstChild("Right Arm") or character:FindFirstChild("RightHand")
	}
	
	for _, arm in ipairs(arms) do
		if arm then
			local cuff = Instance.new("Part")
			cuff.Name = "IceCuff"
			cuff.Size = Vector3.new(1.2, 1, 1.2)
			cuff.Position = arm.Position + Vector3.new(0, 0.5, 0)
			cuff.Anchored = true
			cuff.CanCollide = false
			cuff.Material = Enum.Material.Ice
			cuff.Color = Color3.fromRGB(190, 230, 255)
			cuff.Transparency = 0.2
			cuff.Reflectance = 0.3
			cuff.BrickColor = BrickColor.new("Light blue")
			cuff.Parent = character
			table.insert(iceParts, cuff)
		end
	end
	
	-- Добавляем ледяной пьедестал под ноги
	local torso = character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso")
	if torso then
		local pedestal = Instance.new("Part")
		pedestal.Name = "IcePedestal"
		pedestal.Size = Vector3.new(4, 0.5, 4)
		pedestal.Position = torso.Position - Vector3.new(0, 3, 0)
		pedestal.Anchored = true
		pedestal.CanCollide = true
		pedestal.Material = Enum.Material.Ice
		pedestal.Color = Color3.fromRGB(150, 210, 255)
		pedestal.Transparency = 0.3
		pedestal.Reflectance = 0.2
		pedestal.BrickColor = BrickColor.new("Cyan")
		pedestal.Parent = character
		table.insert(iceParts, pedestal)
		
		-- Добавляем ледяные столбы по углам
		for x = -1, 1, 2 do
			for z = -1, 1, 2 do
				local pillar = Instance.new("Part")
				pillar.Name = "IcePillar"
				pillar.Size = Vector3.new(0.8, 3, 0.8)
				pillar.Position = torso.Position - Vector3.new(0, 1.5, 0) + Vector3.new(x * 1.8, 0, z * 1.8)
				pillar.Anchored = true
				pillar.CanCollide = true
				pillar.Material = Enum.Material.Ice
				pillar.Color = Color3.fromRGB(160, 215, 255)
				pillar.Transparency = 0.25
				pillar.Reflectance = 0.3
				pillar.BrickColor = BrickColor.new("Pastel blue")
				pillar.Parent = character
				table.insert(iceParts, pillar)
			end
		end
	end
	
	-- Добавляем партиклы (ледяную пыль)
	local attachment = Instance.new("Attachment")
	attachment.Parent = rootPart or character
	
	local iceParticles = Instance.new("ParticleEmitter")
	iceParticles.Parent = attachment
	iceParticles.Texture = "rbxasset://textures/particles/sparkles_main.dds"
	iceParticles.Rate = 20
	iceParticles.Lifetime = NumberRange.new(1, 2)
	iceParticles.Speed = NumberRange.new(1, 3)
	iceParticles.SpreadAngle = Vector2.new(180, 180)
	iceParticles.Color = ColorSequence.new(Color3.fromRGB(200, 240, 255))
	iceParticles.LightEmission = 0.3
	iceParticles.Transparency = NumberSequence.new(0.4)
	
	print("❄️ Персонаж превратился в ледяную статую!")
	
	return iceParts, attachment, iceParticles
end

-- Функция удаления ледяного эффекта
local function removeIceEffect(iceParts, attachment, iceParticles)
	local rootPart = character:FindFirstChild("HumanoidRootPart")
	if rootPart then
		rootPart.Anchored = false
	end
	
	humanoid.WalkSpeed = 16
	humanoid.JumpPower = 50
	
	-- Восстанавливаем оригинальные материалы частей
	for _, part in ipairs(character:GetDescendants()) do
		if part:IsA("BasePart") then
			local originalMaterial = part:GetAttribute("OriginalMaterial")
			local originalColor = part:GetAttribute("OriginalColor")
			
			if originalMaterial then
				part.Material = Enum.Material[originalMaterial] or Enum.Material.Plastic
				part:SetAttribute("OriginalMaterial", nil)
			end
			
			if originalColor then
				part.Color = originalColor
				part:SetAttribute("OriginalColor", nil)
			end
			
			part.Transparency = 0
			part.Reflectance = 0
		end
	end
	
	-- Удаляем ледяные части
	for _, part in ipairs(iceParts) do
		if part and part.Parent then
			part:Destroy()
		end
	end
	
	-- Удаляем партиклы
	if iceParticles then
		iceParticles:Destroy()
	end
	
	if attachment then
		attachment:Destroy()
	end
	
	print("🌡️ Лёд растаял!")
end

-- Пример использования:
local iceParts, attachment, iceParticles = createIceEffect() -- замораживаем с эффектом

-- Разморозка через 10 секунд
task.wait(10)
removeIceEffect(iceParts, attachment, iceParticles)