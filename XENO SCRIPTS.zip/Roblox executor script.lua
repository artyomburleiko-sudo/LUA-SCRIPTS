local gui = Instance.new("ScreenGui")
gui.Name = "ScriptExecutorGUI"
gui.Parent = game.Players.LocalPlayer.PlayerGui

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 300, 0, 300)
frame.Position = UDim2.new(0, 10, 0.5, -150)
frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
frame.Parent = gui

local scriptTextBox = Instance.new("TextBox")
scriptTextBox.Size = UDim2.new(0, 280, 0, 100)
scriptTextBox.Position = UDim2.new(0, 10, 0.1, 0)
scriptTextBox.PlaceholderText = "Enter your script here"
scriptTextBox.Text = ""
scriptTextBox.MultiLine = true
scriptTextBox.TextWrapped = true
scriptTextBox.Parent = frame

local repeatTextBox = Instance.new("TextBox")
repeatTextBox.Size = UDim2.new(0, 280, 0, 30)
repeatTextBox.Position = UDim2.new(0, 10, 0.45, 0)
repeatTextBox.PlaceholderText = "Enter repeat count"
repeatTextBox.Text = ""
repeatTextBox.Parent = frame

local executeButton = Instance.new("TextButton")
executeButton.Size = UDim2.new(0, 80, 0, 30)
executeButton.Position = UDim2.new(0.05, 0, 0.8, 0)
executeButton.Text = "Execute"
executeButton.Parent = frame

local clearButton = Instance.new("TextButton")
clearButton.Size = UDim2.new(0, 80, 0, 30)
clearButton.Position = UDim2.new(0.3, 0, 0.8, 0)
clearButton.Text = "Clear"
clearButton.Parent = frame

local repeatButton = Instance.new("TextButton")
repeatButton.Size = UDim2.new(0, 80, 0, 30)
repeatButton.Position = UDim2.new(0.55, 0, 0.8, 0)
repeatButton.Text = "Repeat"
repeatButton.Parent = frame

local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 30, 0, 30)
closeButton.Position = UDim2.new(0, 0, 0, 0)
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
closeButton.Parent = frame

local function executeScript()
    local scriptText = scriptTextBox.Text
    if scriptText and scriptText ~= "" then
        local success, errorMessage = pcall(function()
            loadstring(scriptText)()
        end)
        if not success then
            warn("Error executing script: " .. errorMessage)
        end
    else
        warn("Please enter a valid script.")
    end
end

local function clearScriptTextBox()
    scriptTextBox.Text = ""
end

local function repeatScript()
    local scriptText = scriptTextBox.Text
    local repeatCount = tonumber(repeatTextBox.Text)
    if scriptText and repeatCount and repeatCount > 0 then
        for i = 1, repeatCount do
            local success, errorMessage = pcall(function()
                loadstring(scriptText)()
            end)
            if not success then
                warn("Error executing script: " .. errorMessage)
            end
        end
    else
        warn("Please enter a valid script and repeat count.")
    end
end

local function closeGUI()
    gui:Destroy()
end

executeButton.MouseButton1Click:Connect(executeScript)
clearButton.MouseButton1Click:Connect(clearScriptTextBox)
repeatButton.MouseButton1Click:Connect(repeatScript)
closeButton.MouseButton1Click:Connect(closeGUI)

frame.Draggable = true
frame.Active = true
frame.Selectable = true
