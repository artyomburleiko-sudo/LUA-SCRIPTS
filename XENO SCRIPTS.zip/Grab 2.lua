local player = game:GetService("Players").LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")

-- Состояния
local selected = true
local attacking = false
local hurt = false
local grabbed = nil
local mode = "drop"
local bloodcolors = {"Really red", "Bright red"}

-- Ссылки на части тела
local rarm = character:FindFirstChild("Right Arm") or character:FindFirstChild("RightHand")
local larm = character:FindFirstChild("Left Arm") or character:FindFirstChild("LeftHand")
local lleg = character:FindFirstChild("Left Leg") or character:FindFirstChild("LeftFoot")
local torso = character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso")

-- Хранилище для weld'ов
local grabweld = nil
local platlol = nil
local lolhum = nil

-- Вспомогательные функции
function prop(part, parent, collide, tran, ref, x, y, z, color, anchor, form)
    part.Parent = parent
    part.CanCollide = collide
    part.Transparency = tran
    part.Reflectance = ref
    part.Size = Vector3.new(x, y, z)
    part.BrickColor = BrickColor.new(color)
    part.Anchored = anchor
    part.Locked = true
    part:BreakJoints()
end

function weld(w, p0, p1, a, b, c, x, y, z)
    w.Parent = p0
    w.Part0 = p0
    w.Part1 = p1
    w.C1 = CFrame.fromEulerAnglesXYZ(a, b, c) * CFrame.new(x, y, z)
end

function mesh(mesh, parent, x, y, z, type)
    mesh.Parent = parent
    mesh.Scale = Vector3.new(x, y, z)
    mesh.MeshType = type
end

function inform(text, delay)
    -- Удаляем предыдущее уведомление
    for _, v in pairs(player.PlayerGui:GetChildren()) do
        if v.Name == "Modeshow" then
            v:Destroy()
        end
    end
    
    -- Создаем новое уведомление (современный стиль)
    local screenGui = Instance.new("ScreenGui")
    screenGui.Parent = player.PlayerGui
    screenGui.Name = "Modeshow"
    screenGui.ResetOnSpawn = false
    
    local frame = Instance.new("Frame")
    frame.Parent = screenGui
    frame.BackgroundColor3 = Color3.new(1, 1, 1)
    frame.Size = UDim2.new(0.3, 0, 0.08, 0)
    frame.Position = UDim2.new(0.35, 0, 0.02, 0)
    frame.BorderSizePixel = 0
    
    local label = Instance.new("TextLabel")
    label.Parent = screenGui
    label.Size = UDim2.new(0.28, 0, 0.07, 0)
    label.BackgroundColor3 = Color3.new(0, 0, 0)
    label.Position = UDim2.new(0.36, 0, 0.025, 0)
    label.TextColor3 = Color3.new(1, 1, 1)
    label.Font = Enum.Font.SourceSans
    label.TextSize = 20
    label.Text = text
    
    task.delay(delay, function()
        screenGui:Destroy()
    end)
end

-- Функция создания оружия
function createWeapon()
    -- Удаляем старую модель если есть
    if character:FindFirstChild("Bricks") then
        character.Bricks:Destroy()
    end
    
    local bricks = Instance.new("Model")
    bricks.Name = "Bricks"
    bricks.Parent = character
    
    -- Создаем части оружия
    local righthold = Instance.new("Part")
    prop(righthold, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, Enum.FormFactor.Custom)
    local w11 = Instance.new("Weld")
    weld(w11, rarm, righthold, 0, 0, 0, 0, 1, 0)
    
    local lefthold = Instance.new("Part")
    prop(lefthold, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, Enum.FormFactor.Custom)
    local w12 = Instance.new("Weld")
    weld(w12, larm, lefthold, 0, 0, 0, 0, 1, 0)
    
    local hold = Instance.new("Part")
    prop(hold, bricks, false, 0, 0, 0.2, 0.4, 0.7, "Really red", false, Enum.FormFactor.Custom)
    local oh = Instance.new("Weld")
    weld(oh, lleg, hold, -math.pi/1.4, 0, math.rad(35), 0.55, -0.9, 0.3)
    
    local knife = Instance.new("Part")
    prop(knife, bricks, false, 0, 0, 0.35, 1.1, 0.5, "Really black", false, Enum.FormFactor.Custom)
    local orr = Instance.new("Weld")
    weld(orr, hold, knife, 0, 0, 0, 0, 0.7, 0)
    local ar = Instance.new("Weld")
    weld(ar, lefthold, nil, math.pi/2, 0, math.pi, 0, 0, 0)
    
    local blade = Instance.new("Part")
    prop(blade, bricks, false, 0, 0, 0.1, 1.5, 0.4, "Medium grey", false, Enum.FormFactor.Custom)
    Instance.new("BlockMesh", blade).Scale = Vector3.new(0.3, 1, 1)
    local w2 = Instance.new("Weld")
    weld(w2, knife, blade, 0, 0, 0, 0, -1.2, 0)
    
    local blade2 = Instance.new("Part")
    prop(blade2, bricks, false, 0, 0, 0.1, 0.5, 0.4, "Medium grey", false, Enum.FormFactor.Custom)
    local mew = Instance.new("SpecialMesh", blade2)
    mew.MeshType = Enum.MeshType.Wedge
    mew.Scale = Vector3.new(0.3, 1, 1)
    local w3 = Instance.new("Weld")
    weld(w3, blade, blade2, 0, 0, 0, 0, -1, 0)
    
    local rb = Instance.new("Part")
    prop(rb, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, Enum.FormFactor.Custom)
    local w13 = Instance.new("Weld")
    weld(w13, torso, rb, 0, 0, 0, -1.5, -0.5, 0)
    
    local lb = Instance.new("Part")
    prop(lb, bricks, false, 1, 0, 0.1, 0.1, 0.1, "White", false, Enum.FormFactor.Custom)
    local w14 = Instance.new("Weld")
    weld(w14, torso, lb, 0, 0, 0, 1.5, -0.5, 0)
    
    local rw = Instance.new("Weld")
    weld(rw, rb, nil, 0, 0, 0, 0, 0.5, 0)
    
    local lw = Instance.new("Weld")
    weld(lw, lb, nil, 0, 0, 0, 0, 0.5, 0)
    
    return {
        bricks = bricks,
        righthold = righthold,
        lefthold = lefthold,
        hold = hold,
        knife = knife,
        blade = blade,
        blade2 = blade2,
        rb = rb,
        lb = lb,
        rw = rw,
        lw = lw,
        orr = orr,
        ar = ar
    }
end

-- Функция создания инструмента
function createTool()
    -- Удаляем старый инструмент если есть
    local oldTool = player.Backpack:FindFirstChild("Grab") or character:FindFirstChild("Grab")
    if oldTool then
        oldTool:Destroy()
    end
    
    local tool = Instance.new("Tool")
    tool.Name = "Grab"
    tool.RequiresHandle = false
    tool.CanBeDropped = false
    tool.Parent = player.Backpack
    
    return tool
end

-- Функция обработки касания
local function touch(hit)
    if hurt and grabbed == nil then
        local hu = hit.Parent:FindFirstChildOfClass("Humanoid")
        local head = hit.Parent:FindFirstChild("Head")
        local torz = hit.Parent:FindFirstChild("Torso") or hit.Parent:FindFirstChild("UpperTorso")
        
        if hu and head and torz and hit.Parent ~= character then
            if hu.Health > 0 then
                grabbed = torz
                hu.PlatformStand = true
                
                local w = Instance.new("Weld")
                weld(w, righthold, grabbed, math.pi/2, 0.2, 0, 0.7, -0.9, -0.6)
                grabweld = w
                lolhum = hu
                
                local lolxd = true
                platlol = lolxd
                
                hu:GetPropertyChangedSignal("PlatformStand"):Connect(function()
                    if platlol then
                        hu.PlatformStand = true
                    end
                end)
            end
        end
    end
end

-- Функция кровотечения
function bleed(part, po)
    local lol1 = math.random(5, 30) / 100
    local lol2 = math.random(5, 30) / 100
    local lol3 = math.random(5, 30) / 100
    local lol4 = math.random(1, #bloodcolors)
    
    local p = Instance.new("Part")
    prop(p, part.Parent, false, 0, 0, lol1, lol2, lol3, bloodcolors[lol4], false, Enum.FormFactor.Custom)
    p.CFrame = part.CFrame * CFrame.new(math.random(-5, 5) / 10, po, math.random(-5, 5) / 10)
    p.Velocity = Vector3.new(math.random(-190, 190) / 10, math.random(-190, 190) / 10, math.random(-190, 190) / 10)
    p.RotVelocity = Vector3.new(math.random(-400, 400) / 10, math.random(-400, 400) / 10, math.random(-400, 400) / 10)
    
    task.delay(3, function()
        p:Destroy()
    end)
end

-- Создаем оружие и инструмент
local weapon = createWeapon()
local tool = createTool()

-- Получаем ссылки на части
local righthold = weapon.righthold
local lefthold = weapon.lefthold
local rw = weapon.rw
local lw = weapon.lw
local orr = weapon.orr
local ar = weapon.ar

-- Подключаем обработчики касания
righthold.Touched:Connect(touch)
lefthold.Touched:Connect(touch)

-- Обработка выбора инструмента
tool.Equipped:Connect(function(mouse)
    orr.Part1 = nil
    ar.Part1 = weapon.knife
    
    -- Обработка нажатия кнопки мыши
    mouse.Button1Down:Connect(function()
        if attacking == false then
            attacking = true
            lw.Part1 = larm
            rw.Part1 = rarm
            hurt = true
            
            for i = 1, 8 do
                rw.C0 = rw.C0 * CFrame.new(-0.03, 0, -0.08) * CFrame.fromEulerAnglesXYZ(0.18, 0.04, 0)
                lw.C0 = lw.C0 * CFrame.new(0.06, 0, -0.06) * CFrame.fromEulerAnglesXYZ(0.15, -0.11, -0.05)
                task.wait(0.1)
            end
            
            task.wait(1)
            hurt = false
            
            if grabbed == nil then
                for i = 1, 4 do
                    rw.C0 = rw.C0 * CFrame.new(0.06, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.36, -0.08, 0)
                    lw.C0 = lw.C0 * CFrame.new(-0.12, 0, 0.12) * CFrame.fromEulerAnglesXYZ(-0.3, 0.22, 0.05)
                    task.wait(0.1)
                end
                
                lw.C0 = CFrame.new(0, 0, 0)
                rw.C0 = CFrame.new(0, 0, 0)
                lw.Part1 = nil
                rw.Part1 = nil
                attacking = false
            end
        elseif hurt == false and grabbed ~= nil and mode == "drop" then
            grabweld:Destroy()
            grabweld = nil
            platlol = false
            grabbed = nil
            lolhum.PlatformStand = false
            lolhum = nil
            
            for i = 1, 4 do
                rw.C0 = rw.C0 * CFrame.new(0.06, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.36, -0.08, 0)
                lw.C0 = lw.C0 * CFrame.new(-0.12, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.3, 0.2, 0)
                task.wait(0.1)
            end
            
            lw.C0 = CFrame.new(0, 0, 0)
            rw.C0 = CFrame.new(0, 0, 0)
            lw.Part1 = nil
            rw.Part1 = nil
            attacking = false
            platlol = nil
            
        elseif hurt == false and grabbed ~= nil and grabweld ~= nil and mode == "throw" then
            grabweld:Destroy()
            grabweld = nil
            
            local bf = Instance.new("BodyForce", grabbed)
            bf.Force = torso.CFrame.LookVector * 8500 + Vector3.new(0, 7400, 0)
            
            task.delay(0.12, function()
                bf:Destroy()
            end)
            
            for i = 1, 6 do
                rw.C0 = rw.C0 * CFrame.fromEulerAnglesXYZ(0.35, 0, 0)
                lw.C0 = lw.C0 * CFrame.fromEulerAnglesXYZ(-0.18, 0, 0)
                task.wait(0.1)
            end
            
            for i = 1, 4 do
                rw.C0 = rw.C0 * CFrame.fromEulerAnglesXYZ(-0.47, 0, 0)
                lw.C0 = lw.C0 * CFrame.fromEulerAnglesXYZ(0.2, 0, 0)
                task.wait(0.1)
            end
            
            task.wait(0.2)
            platlol = false
            grabbed = nil
            lolhum.PlatformStand = false
            lolhum = nil
            
            for i = 1, 4 do
                rw.C0 = rw.C0 * CFrame.new(0.06, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.36, -0.08, 0)
                lw.C0 = lw.C0 * CFrame.new(-0.12, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.3, 0.2, 0)
                task.wait(0.1)
            end
            
            lw.C0 = CFrame.new(0, 0, 0)
            rw.C0 = CFrame.new(0, 0, 0)
            lw.Part1 = nil
            rw.Part1 = nil
            attacking = false
            platlol = nil
            
        elseif hurt == false and grabbed ~= nil and lolhum ~= nil and grabweld ~= nil and mode == "kill" then
            for i = 1, 5 do
                lw.C0 = lw.C0 * CFrame.new(0.02, 0.12, 0.1) * CFrame.fromEulerAnglesXYZ(-0.05, 0, -0.03)
                task.wait(0.1)
            end
            
            local neck = grabbed:FindFirstChild("Neck")
            local head = grabbed.Parent:FindFirstChild("Head")
            local targetHum = lolhum
            
            -- Анимация убийства
            task.spawn(function()
                local duh = grabbed
                local duh2 = head
                local lolas = targetHum
                
                duh.RotVelocity = Vector3.new(math.random(-20, 20), math.random(-20, 20), math.random(-20, 20))
                
                for i = 1, 60 do
                    task.wait(0.1)
                    local hm = math.random(1, 9)
                    pcall(function()
                        if hm == 1 and duh2 and duh2:FindFirstChild("Sound") then
                            duh2.Sound.Pitch = math.random(90, 110) / 100
                            duh2.Sound:Play()
                        end
                    end)
                    
                    if hm > 0 and hm < 3 then
                        bleed(duh, 1)
                        bleed(duh2, -0.5)
                    end
                end
                
                lolas.Health = 0
                
                for i = 1, 85 do
                    task.wait(0.1)
                    local hm = math.random(1, 9)
                    pcall(function()
                        if hm == 1 and duh2 and duh2:FindFirstChild("Sound") then
                            duh2.Sound.Pitch = math.random(90, 110) / 100
                            duh2.Sound:Play()
                        end
                    end)
                    
                    if hm > 0 and hm < 3 then
                        bleed(duh, 1)
                        bleed(duh2, -0.5)
                    end
                end
            end)
            
            for i = 1, 3 do
                lw.C0 = lw.C0 * CFrame.new(0.02, 0.12, 0.1) * CFrame.fromEulerAnglesXYZ(-0.05, 0, -0.03)
                if neck then
                    grabbed.Neck.C0 = grabbed.Neck.C0 * CFrame.fromEulerAnglesXYZ(-0.35, 0, 0)
                end
                task.wait(0.1)
            end
            
            grabweld:Destroy()
            grabweld = nil
            
            for i = 1, 4 do
                lw.C0 = lw.C0 * CFrame.new(-0.04, -0.24, -0.2) * CFrame.fromEulerAnglesXYZ(0.1, 0, 0.06)
                task.wait(0.1)
            end
            
            for i = 1, 4 do
                rw.C0 = rw.C0 * CFrame.new(0.06, 0, 0.16) * CFrame.fromEulerAnglesXYZ(-0.36, -0.08, 0)
                lw.C0 = lw.C0 * CFrame.new(-0.12, 0, 0.12) * CFrame.fromEulerAnglesXYZ(-0.3, 0.22, 0.05)
                task.wait(0.1)
            end
            
            lw.C0 = CFrame.new(0, 0, 0)
            rw.C0 = CFrame.new(0, 0, 0)
            lw.Part1 = nil
            rw.Part1 = nil
            platlol = false
            grabbed = nil
            lolhum = nil
            attacking = false
            platlol = nil
        end
    end)
    
    -- Обработка нажатия клавиш
    mouse.KeyDown:Connect(function(key)
        key = key:lower()
        if key == "q" then
            mode = "drop"
            inform("Mode: Drop", 2)
        elseif key == "e" then
            mode = "throw"
            inform("Mode: Throw", 2)
        elseif key == "f" then
            mode = "kill"
            inform("Mode: Kill", 2)
        end
    end)
end)

-- Обработка деактивации инструмента
tool.Unequipped:Connect(function()
    -- Ждем завершения атаки
    local function waitForAttack()
        if attacking then
            task.wait(0.1)
            waitForAttack()
        end
    end
    waitForAttack()
    
    orr.Part1 = weapon.knife
    ar.Part1 = nil
end)

-- Обработка смерти персонажа
humanoid.Died:Connect(function()
    pcall(function()
        if grabweld then
            grabweld:Destroy()
            grabweld = nil
        end
        grabbed = nil
        platlol = false
        platlol = nil
    end)
end)

inform("Grab script loaded successfully.", 2)