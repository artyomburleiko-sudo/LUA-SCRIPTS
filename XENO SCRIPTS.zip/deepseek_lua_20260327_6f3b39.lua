local screenGui = Instance.new("ScreenGui")
screenGui.Name = "SpamExecutorGUI"
screenGui.Parent = game:GetService("CoreGui")
screenGui.ResetOnSpawn = false

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 400, 0, 250)
frame.Position = UDim2.new(0.5, -200, 0.5, -125)
frame.BackgroundColor3 = Color3.fromRGB(30, 30, 35)
frame.BackgroundTransparency = 0.1
frame.BorderSizePixel = 0
frame.Parent = screenGui

local corners = Instance.new("UICorner")
corners.CornerRadius = UDim.new(0, 8)
corners.Parent = frame

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, 0, 0, 40)
title.Position = UDim2.new(0, 0, 0, 0)
title.BackgroundColor3 = Color3.fromRGB(40, 40, 45)
title.BackgroundTransparency = 0.2
title.Text = "Script Spammer Executor"
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.TextScaled = true
title.Font = Enum.Font.GothamBold
title.Parent = frame

local titleCorners = Instance.new("UICorner")
titleCorners.CornerRadius = UDim.new(0, 8)
titleCorners.Parent = title

local scriptLabel = Instance.new("TextLabel")
scriptLabel.Size = UDim2.new(0.9, 0, 0, 25)
scriptLabel.Position = UDim2.new(0.05, 0, 0, 50)
scriptLabel.BackgroundTransparency = 1
scriptLabel.Text = "Script to execute:"
scriptLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
scriptLabel.TextXAlignment = Enum.TextXAlignment.Left
scriptLabel.TextSize = 14
scriptLabel.Font = Enum.Font.Gotham
scriptLabel.Parent = frame

local scriptBox = Instance.new("TextBox")
scriptBox.Size = UDim2.new(0.9, 0, 0, 80)
scriptBox.Position = UDim2.new(0.05, 0, 0, 75)
scriptBox.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
scriptBox.TextColor3 = Color3.fromRGB(255, 255, 255)
scriptBox.PlaceholderText = "Enter your script here..."
scriptBox.Text = ""
scriptBox.TextWrapped = true
scriptBox.TextXAlignment = Enum.TextXAlignment.Left
scriptBox.TextYAlignment = Enum.TextYAlignment.Top
scriptBox.Font = Enum.Font.SourceSans
scriptBox.TextSize = 12
scriptBox.ClearTextOnFocus = false
scriptBox.Parent = frame

local scriptBoxCorners = Instance.new("UICorner")
scriptBoxCorners.CornerRadius = UDim.new(0, 5)
scriptBoxCorners.Parent = scriptBox

local countLabel = Instance.new("TextLabel")
countLabel.Size = UDim2.new(0.9, 0, 0, 25)
countLabel.Position = UDim2.new(0.05, 0, 0, 160)
countLabel.BackgroundTransparency = 1
countLabel.Text = "Number of executions:"
countLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
countLabel.TextXAlignment = Enum.TextXAlignment.Left
countLabel.TextSize = 14
countLabel.Font = Enum.Font.Gotham
countLabel.Parent = frame

local countBox = Instance.new("TextBox")
countBox.Size = UDim2.new(0.9, 0, 0, 30)
countBox.Position = UDim2.new(0.05, 0, 0, 185)
countBox.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
countBox.TextColor3 = Color3.fromRGB(255, 255, 255)
countBox.PlaceholderText = "Enter number (e.g., 5)"
countBox.Text = ""
countBox.Font = Enum.Font.SourceSans
countBox.TextSize = 14
countBox.ClearTextOnFocus = false
countBox.Parent = frame

local countBoxCorners = Instance.new("UICorner")
countBoxCorners.CornerRadius = UDim.new(0, 5)
countBoxCorners.Parent = countBox

local executeButton = Instance.new("TextButton")
executeButton.Size = UDim2.new(0.9, 0, 0, 40)
executeButton.Position = UDim2.new(0.05, 0, 0, 225)
executeButton.BackgroundColor3 = Color3.fromRGB(80, 60, 200)
executeButton.Text = "Spam Execute"
executeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
executeButton.TextSize = 16
executeButton.Font = Enum.Font.GothamBold
executeButton.Parent = frame

local buttonCorners = Instance.new("UICorner")
buttonCorners.CornerRadius = UDim.new(0, 5)
buttonCorners.Parent = executeButton

executeButton.MouseEnter:Connect(function()
    executeButton.BackgroundColor3 = Color3.fromRGB(100, 80, 220)
end)

executeButton.MouseLeave:Connect(function()
    executeButton.BackgroundColor3 = Color3.fromRGB(80, 60, 200)
end)

local function executeScript(scriptText)
    if scriptText and scriptText ~= "" then
        local func, err = loadstring(scriptText)
        if func then
            local success, execErr = pcall(func)
            if not success then
                warn("Script execution error: " .. tostring(execErr))
            end
        else
            warn("Invalid script: " .. tostring(err))
        end
    end
end

local function spamExecute()
    local scriptText = scriptBox.Text
    local countText = countBox.Text
    
    if scriptText == "" or scriptText == nil then
        local notification = Instance.new("TextLabel")
        notification.Size = UDim2.new(0, 300, 0, 40)
        notification.Position = UDim2.new(0.5, -150, 0, 20)
        notification.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
        notification.Text = "Please enter a script!"
        notification.TextColor3 = Color3.fromRGB(255, 255, 255)
        notification.TextSize = 14
        notification.Font = Enum.Font.Gotham
        notification.BackgroundTransparency = 0.2
        notification.Parent = screenGui
        
        local notifCorners = Instance.new("UICorner")
        notifCorners.CornerRadius = UDim.new(0, 5)
        notifCorners.Parent = notification
        
        game:GetService("Debris"):AddItem(notification, 2)
        return
    end
    
    local count = tonumber(countText)
    if not count or count <= 0 then
        local notification = Instance.new("TextLabel")
        notification.Size = UDim2.new(0, 300, 0, 40)
        notification.Position = UDim2.new(0.5, -150, 0, 20)
        notification.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
        notification.Text = "Please enter a valid number (greater than 0)!"
        notification.TextColor3 = Color3.fromRGB(255, 255, 255)
        notification.TextSize = 14
        notification.Font = Enum.Font.Gotham
        notification.BackgroundTransparency = 0.2
        notification.Parent = screenGui
        
        local notifCorners = Instance.new("UICorner")
        notifCorners.CornerRadius = UDim.new(0, 5)
        notifCorners.Parent = notification
        
        game:GetService("Debris"):AddItem(notification, 2)
        return
    end
    
    local progressFrame = Instance.new("Frame")
    progressFrame.Size = UDim2.new(0, 400, 0, 30)
    progressFrame.Position = UDim2.new(0.5, -200, 0, frame.Position.Y.Offset + frame.Size.Y.Offset + 10)
    progressFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
    progressFrame.BackgroundTransparency = 0.1
    progressFrame.Parent = screenGui
    
    local progressCorners = Instance.new("UICorner")
    progressCorners.CornerRadius = UDim.new(0, 5)
    progressCorners.Parent = progressFrame
    
    local progressText = Instance.new("TextLabel")
    progressText.Size = UDim2.new(1, 0, 1, 0)
    progressText.BackgroundTransparency = 1
    progressText.Text = "Executing: 0/" .. count
    progressText.TextColor3 = Color3.fromRGB(255, 255, 255)
    progressText.TextSize = 12
    progressText.Font = Enum.Font.Gotham
    progressText.Parent = progressFrame
    
    local func, err = loadstring(scriptText)
    if not func then
        progressFrame:Destroy()
        local errorNotif = Instance.new("TextLabel")
        errorNotif.Size = UDim2.new(0, 300, 0, 40)
        errorNotif.Position = UDim2.new(0.5, -150, 0, 20)
        errorNotif.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
        errorNotif.Text = "Invalid script: " .. tostring(err)
        errorNotif.TextColor3 = Color3.fromRGB(255, 255, 255)
        errorNotif.TextSize = 14
        errorNotif.Font = Enum.Font.Gotham
        errorNotif.BackgroundTransparency = 0.2
        errorNotif.Parent = screenGui
        
        local errorCorners = Instance.new("UICorner")
        errorCorners.CornerRadius = UDim.new(0, 5)
        errorCorners.Parent = errorNotif
        
        game:GetService("Debris"):AddItem(errorNotif, 3)
        return
    end
    
    local startTime = tick()
    
    for i = 1, count do
        local success, execErr = pcall(func)
        if not success then
            warn("Script execution error: " .. tostring(execErr))
        end
        progressText.Text = "Executing: " .. i .. "/" .. count
    end
    
    local endTime = tick()
    local executionTime = (endTime - startTime) * 1000
    
    progressFrame:Destroy()
    
    local successNotif = Instance.new("TextLabel")
    successNotif.Size = UDim2.new(0, 350, 0, 40)
    successNotif.Position = UDim2.new(0.5, -175, 0, 20)
    successNotif.BackgroundColor3 = Color3.fromRGB(50, 150, 50)
    successNotif.Text = "Executed " .. count .. " times in " .. string.format("%.2f", executionTime) .. "ms!"
    successNotif.TextColor3 = Color3.fromRGB(255, 255, 255)
    successNotif.TextSize = 12
    successNotif.Font = Enum.Font.Gotham
    successNotif.BackgroundTransparency = 0.2
    successNotif.Parent = screenGui
    
    local notifCorners = Instance.new("UICorner")
    notifCorners.CornerRadius = UDim.new(0, 5)
    notifCorners.Parent = successNotif
    
    game:GetService("Debris"):AddItem(successNotif, 3)
end

executeButton.MouseButton1Click:Connect(spamExecute)

local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 30, 0, 30)
closeButton.Position = UDim2.new(1, -35, 0, 5)
closeButton.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextSize = 18
closeButton.Font = Enum.Font.GothamBold
closeButton.Parent = frame

local closeCorners = Instance.new("UICorner")
closeCorners.CornerRadius = UDim.new(0, 5)
closeCorners.Parent = closeButton

closeButton.MouseButton1Click:Connect(function()
    screenGui:Destroy()
end)

local dragging = false
local dragStart = nil
local startPos = nil

title.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = true
        dragStart = input.Position
        startPos = frame.Position
    end
end)

title.InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = false
    end
end)

game:GetService("UserInputService").InputChanged:Connect(function(input)
    if dragging and input.UserInputType == Enum.UserInputType.MouseMovement then
        local delta = input.Position - dragStart
        frame.Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
    end
end)