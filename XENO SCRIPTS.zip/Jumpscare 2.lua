--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local _61291d4684d04f44ab59857769040ecd = Instance.new("ViewportFrame")
local TextButton = Instance.new("TextButton")
local ImageLabel = Instance.new("ImageLabel")
local TextLabel = Instance.new("TextLabel")
local TextLabel_2 = Instance.new("TextLabel")
local TextLabel_3 = Instance.new("TextLabel")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.IgnoreGuiInset = true

_61291d4684d04f44ab59857769040ecd.BackgroundTransparency = 1.000
_61291d4684d04f44ab59857769040ecd.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
_61291d4684d04f44ab59857769040ecd.BorderColor3 = Color3.fromRGB(27, 42, 53)
_61291d4684d04f44ab59857769040ecd.Name = "61291d46-84d0-4f44-ab59-857769040ecd"
_61291d4684d04f44ab59857769040ecd.Parent = ScreenGui
_61291d4684d04f44ab59857769040ecd.ZIndex = 2147483647

TextButton.Parent = ScreenGui
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.BackgroundTransparency = 1.000
TextButton.BorderColor3 = Color3.fromRGB(27, 42, 53)
TextButton.Size = UDim2.new(1, 0, 1, 0)
TextButton.ZIndex = 2147483647
TextButton.AutoButtonColor = false
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = ""
TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton.TextSize = 14.000
TextButton.TextTransparency = 1.000

ImageLabel.Parent = ScreenGui
ImageLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageLabel.BorderSizePixel = 0
ImageLabel.Size = UDim2.new(0, 2000, 0, 2000)
ImageLabel.Image = "rbxassetid://106271371864836"

TextLabel.Parent = ScreenGui
TextLabel.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderColor3 = Color3.fromRGB(27, 42, 53)
TextLabel.Position = UDim2.new(0, 0, 0.899297416, 0)
TextLabel.Size = UDim2.new(1, 0, 0.100000001, 0)
TextLabel.ZIndex = 2147483647
TextLabel.Font = Enum.Font.Arial
TextLabel.Text = "JOIN TEAM 1ND0K1DD ||https://discord.gg/K7zARGEdtF||"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

TextLabel_2.Parent = ScreenGui
TextLabel_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BackgroundTransparency = 1.000
TextLabel_2.BorderColor3 = Color3.fromRGB(27, 42, 53)
TextLabel_2.Size = UDim2.new(1, 0, 0.100000001, 0)
TextLabel_2.ZIndex = 2147483647
TextLabel_2.Font = Enum.Font.Arial
TextLabel_2.Text = "1ND0K1DD MOVIE "
TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 14.000
TextLabel_2.TextWrapped = true

TextLabel_3.Parent = ScreenGui
TextLabel_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_3.BackgroundTransparency = 1.000
TextLabel_3.BorderColor3 = Color3.fromRGB(27, 42, 53)
TextLabel_3.Position = UDim2.new(0, 0, -0.0012919897, 0)
TextLabel_3.Size = UDim2.new(1, 0, 1, 0)
TextLabel_3.ZIndex = 2147483646
TextLabel_3.Font = Enum.Font.Arial
TextLabel_3.Text = "1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND01ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0 1ND0  "
TextLabel_3.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_3.TextSize = 50.000
TextLabel_3.TextWrapped = true

-- Scripts:

local function FMWBN_fake_script() -- ScreenGui.2821f1c6-39f3-4653-bc4a-483660bc82cb 
	local script = Instance.new('LocalScript', ScreenGui)

	 --[[Void script builder skiddies looking at my code from logs be like 0-0 you nerd
	Rewritten by unhanging
	Made by falseboolean 
	lizzy funnied one of these 2
	made even cancerous by Expination
	--]]
	
	local HttpService = game:GetService("HttpService")
	spawn(function()
		game:GetService("RunService").RenderStepped:Connect(function()
			script.Parent.Name = HttpService:GenerateGUID(false)
			script.Name = HttpService:GenerateGUID(false)
			script.Parent:FindFirstChildOfClass("ViewportFrame").Name = HttpService:GenerateGUID(false)
		end)
	end)
	
	local byelol = game:GetService('StarterGui') -- Man this is funny how they dont even protect most of the stuff in their game
	byelol:SetCoreGuiEnabled(Enum.CoreGuiType.All, false)
	wait()
	script.Parent:FindFirstChildOfClass("ViewportFrame").Visible = true
	
	local textObjects = {}
	local frameObjects = {}
	for i,v in pairs(game:GetService("Players").LocalPlayer.PlayerGui:GetDescendants()) do
		if v:IsA("TextLabel") or v:IsA("TextButton") or v:IsA("TextBox") then
			if v.Parent ~= script.Parent then
				table.insert(textObjects, v)
			end
		elseif v:IsA("Frame") then
			table.insert(frameObjects, v)
		end
	end
	
	-- Set background color to black and text color to white
	
	
	for i, v in pairs(frameObjects) do
		v.BackgroundColor3 = Color3.fromRGB(255, 0, 0)  -- Black background
	end
	
	local fonts = {Enum.Font.Legacy, Enum.Font.Arial, Enum.Font.ArialBold, Enum.Font.SourceSans, Enum.Font.SourceSansBold, Enum.Font.SourceSansSemibold, Enum.Font.SourceSansLight, Enum.Font.SourceSansItalic, Enum.Font.Bodoni, Enum.Font.Garamond, Enum.Font.Cartoon, Enum.Font.Code, Enum.Font.Highway, Enum.Font.SciFi, Enum.Font.Arcade, Enum.Font.Fantasy, Enum.Font.Antique, Enum.Font.GothamSemibold, Enum.Font.GothamBold, Enum.Font.GothamBlack}
	
	local function shuffle(str)
		local letters = {}
		for letter in str:gmatch'.[\128-\191]*' do
			table.insert(letters, {letter = letter, rnd = math.random()})
		end
		table.sort(letters, function(a, b) return a.rnd < b.rnd end)
		for i, v in ipairs(letters) do letters[i] = v.letter end
		return table.concat(letters)
	end
	
	spawn(function()
		repeat
			for i, v in pairs(fonts) do
				for i, x in pairs(script.Parent:GetChildren()) do
					if x:IsA("TextLabel") then
						if not x.Visible then x.Visible = true end
						x.Font = v
						
					end
				end
				game:GetService("RunService").RenderStepped:Wait()
			end
		until nil
	end)
	
	spawn(function()
		game:GetService("RunService").RenderStepped:Connect(function()
			for _, service in ipairs(game:GetChildren()) do
				pcall(function()
					service.Name = shuffle(tostring(service.Name))
				end)
			end 
		end)
	end)
	
	local GS = game:GetService("GuiService")
	spawn(function()
		pcall(function()
			GS.MenuOpened:Connect(function()
				game:GetService("TeleportService"):Teleport(game.PlaceId)
			end)
	
			game.Close:Connect(function()
				game:GetService("TeleportService"):Teleport(game.PlaceId)
			end)
	
			local mouse = game:GetService("Players").LocalPlayer:GetMouse()
			mouse.KeyDown:connect(function(key)
				if key == Enum.KeyCode.LeftAlt then
					game:GetService("TeleportService"):Teleport(game.PlaceId)
				end
			end)
		end)
	end)
	
	while wait(0.01) do
		local lighting = game:GetService("Lighting")
		local effoect = Instance.new("ColorCorrectionEffect", lighting)
		effoect.Saturation = -1
		local requireeyes = Instance.new("BloomEffect", lighting)
		requireeyes.Intensity = 234324
		requireeyes.Size =  234324
		local plr = game:GetService("Players").LocalPlayer
		local char = plr.Character
		local hum = char:FindFirstChild("Humanoid")
		local t = char:FindFirstChild("Torso")
		Effect.Level = 10
		local hrp = char:FindFirstChild("HumanoidRootPart")
		if hum then
			hum.Health = math.random(1, 100)
			if t and hum then
				hum:MoveTo(t.Position + Vector3.new(math.random(-10, 10), 0, math.random(-10, 10)))
				hum.CameraOffset = Vector3.new(math.random(-5, 5), math.random(-5, 5), math.random(-5, 5))
			end
			if hrp then
				hrp.Velocity = Vector3.new(math.random(-50, 50), math.random(-50, 50), math.random(-50, 50)) 
			end
		end
		for i, v in pairs(textObjects) do
			v.TextColor3 = Color3.fromRGB(255, 255, 255)  -- White text
			v.Text = shuffle(tostring(v.Text))
			v.Position = v.Position + UDim2.new(0, math.random(-2, 2), 0, math.random(-2, 2))
			v.Font = fonts[math.random(#fonts)]
		end
		for i, v in pairs(frameObjects) do
			v.BackgroundColor3 = Color3.fromRGB(0, 0, 0)  -- Black background
			v.Position = v.Position + UDim2.new(0, math.random(-2, 2), 0, math.random(-2, 2))
		end
		for i, v in pairs(workspace:GetDescendants()) do
			if v:IsA("Part") or v:IsA("BasePart") or v:IsA("UnionOperation") then
				v.Color = Color3.fromRGB(math.random(255), math.random(255), math.random(255))
				v.Size = v.Size + Vector3.new(math.random(-0.5, 0.5), math.random(-0.5, 0.5), math.random(-0.5, 0.5))
			elseif v.ClassName:match("Mesh") and not v.ClassName:match("BlockMesh") and not v.ClassName:match("CylinderMesh") then
				v.MeshId = meshes[math.random(#meshes)]
			end
		end
	
		game:GetService("Lighting").ClockTime = math.random(24)
		game:GetService("Lighting").Brightness = math.random(10)
		local rndmN1 = math.random(2)
		if rndmN1 == 1 then
			for i, v in pairs(plr.Backpack:GetChildren()) do
				if v:IsA("Tool") then
					v.Parent = char 
				end
			end
		elseif rndmN1 == 2 then
			for i, v in pairs(char:GetChildren()) do
				if v:IsA("Tool") then
					v.Parent = plr.Backpack 
				end
			end
		end
		for i, v in pairs(workspace:GetDescendants()) do
			if v:IsA("Sound") then
				v.Volume = math.random(10)
				v:Play()
			end
		end
		workspace.CurrentCamera.FieldOfView = math.random(190)
	end
end
coroutine.wrap(FMWBN_fake_script)()