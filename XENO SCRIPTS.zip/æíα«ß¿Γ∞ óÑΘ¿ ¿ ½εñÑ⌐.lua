local Workspace = game:GetService("Workspace")
local Debris = game:GetService("Debris")
local GuiService = game:GetService("GuiService")
local UserInputService = game:GetService("UserInputService")
local strength = 470
local fling = false

-- Create toggle button
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Parent = game.Players.LocalPlayer.PlayerGui
local ToggleButton = Instance.new("TextButton")
ToggleButton.Size = UDim2.new(0, 110, 0.04, 25)
ToggleButton.Position = UDim2.new(0.5, -60, 0.14, -15) -- Centered
ToggleButton.Text = "Fling: OFF"
ToggleButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0) -- Red when OFF
ToggleButton.Parent = ScreenGui

-- Функция для переключения fling
local function toggleFling()
    fling = not fling
    ToggleButton.Text = fling and "Fling: ON" or "Fling: OFF"
    ToggleButton.BackgroundColor3 = fling and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 0, 0) -- Green when ON, Red when OFF
end

-- Клик по кнопке
ToggleButton.MouseButton1Click:Connect(toggleFling)

-- Нажатие клавиши H
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end -- Игнорируем, если обработано игрой (например, чат)
    
    if input.KeyCode == Enum.KeyCode.H then
        toggleFling()
    end
end)

-- Original script
Workspace.ChildAdded:Connect(function(model)
    if model.Name == "GrabParts" then
        local partInfo = model:FindFirstChild("GrabPart")
        if not partInfo then return end
        local weld = partInfo:FindFirstChild("WeldConstraint")
        if not weld or not weld.Part1 then return end
        local part = weld.Part1
        local velocity = Instance.new("BodyVelocity")
        velocity.Parent = part
        model:GetPropertyChangedSignal("Parent"):Connect(function()
            if not model.Parent then
                if fling then
                    velocity.MaxForce = Vector3.new(1e9, 1e9, 1e9)
                    velocity.Velocity = Workspace.CurrentCamera.CFrame.LookVector * strength
                else
                    velocity.MaxForce = Vector3.zero
                end
                Debris:AddItem(velocity, 1)
            end
        end)
    end
end)