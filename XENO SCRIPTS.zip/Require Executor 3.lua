-- Gui to Lua
-- Version: 3.2

-- Instances:

local ServerSideExecutor = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TITLE = Instance.new("TextLabel")
local ExecuteButton = Instance.new("TextButton")
local TextBoxCode = Instance.new("TextBox")
local RemotesFolder = Instance.new("Folder")
local Credit = Instance.new("TextLabel")
local ImageButtonOpen = Instance.new("ImageButton")
local UICorner = Instance.new("UICorner")
local ImageButtonOpen_2 = Instance.new("ImageButton")
local UICorner_2 = Instance.new("UICorner")

--Properties:

ServerSideExecutor.Name = "ServerSideExecutor"
ServerSideExecutor.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ServerSideExecutor.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ServerSideExecutor.ResetOnSpawn = false

Frame.Parent = ServerSideExecutor
Frame.BackgroundColor3 = Color3.fromRGB(168, 168, 168)
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.291647285, 0, 0.361282378, 0)
Frame.Size = UDim2.new(0.393901676, 0, 0.389642417, 0)
Frame.Active = true
Frame.Draggable = true

TITLE.Name = "TITLE"
TITLE.Parent = Frame
TITLE.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
TITLE.BorderColor3 = Color3.fromRGB(0, 0, 0)
TITLE.BorderSizePixel = 0
TITLE.Position = UDim2.new(0.00157977885, 0, 0, 0)
TITLE.Size = UDim2.new(1, 0, 0.158227846, 0)
TITLE.Font = Enum.Font.Arcade
TITLE.Text = "SERVERSIDE EXECUTOR"
TITLE.TextColor3 = Color3.fromRGB(255, 255, 255)
TITLE.TextScaled = true
TITLE.TextSize = 14.000
TITLE.TextWrapped = true

ExecuteButton.Name = "ExecuteButton"
ExecuteButton.Parent = Frame
ExecuteButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ExecuteButton.BorderColor3 = Color3.fromRGB(0, 0, 0)
ExecuteButton.BorderSizePixel = 0
ExecuteButton.Position = UDim2.new(0.061611373, 0, 0.743670881, 0)
ExecuteButton.Size = UDim2.new(0.879936814, 0, 0.212025315, 0)
ExecuteButton.Font = Enum.Font.Arcade
ExecuteButton.Text = "Execute"
ExecuteButton.TextColor3 = Color3.fromRGB(255, 255, 255)
ExecuteButton.TextScaled = true
ExecuteButton.TextSize = 14.000
ExecuteButton.TextWrapped = true

TextBoxCode.Name = "TextBoxCode"
TextBoxCode.Parent = Frame
TextBoxCode.BackgroundColor3 = Color3.fromRGB(88, 88, 88)
TextBoxCode.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextBoxCode.BorderSizePixel = 0
TextBoxCode.Position = UDim2.new(0.061611373, 0, 0.202531651, 0)
TextBoxCode.Size = UDim2.new(0.879936814, 0, 0.484177202, 0)
TextBoxCode.Font = Enum.Font.Arcade
TextBoxCode.PlaceholderColor3 = Color3.fromRGB(255, 255, 255)
TextBoxCode.PlaceholderText = "Require Script"
TextBoxCode.Text = ""
TextBoxCode.TextColor3 = Color3.fromRGB(0, 0, 0)
TextBoxCode.TextScaled = true
TextBoxCode.TextSize = 14.000
TextBoxCode.TextWrapped = true

RemotesFolder.Name = "RemotesFolder"
RemotesFolder.Parent = Frame

Credit.Name = "Credit"
Credit.Parent = Frame
Credit.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Credit.BorderColor3 = Color3.fromRGB(0, 0, 0)
Credit.BorderSizePixel = 0
Credit.Position = UDim2.new(9.6422049e-08, 0, 1, 0)
Credit.Size = UDim2.new(1, 0, 0.129746839, 0)
Credit.Font = Enum.Font.Arcade
Credit.Text = "Create by DevScript_Workspace"
Credit.TextColor3 = Color3.fromRGB(255, 255, 255)
Credit.TextScaled = true
Credit.TextSize = 14.000
Credit.TextWrapped = true

ImageButtonOpen.Name = "ImageButtonOpen"
ImageButtonOpen.Parent = Frame
ImageButtonOpen.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButtonOpen.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButtonOpen.BorderSizePixel = 0
ImageButtonOpen.Position = UDim2.new(0.00157977885, 0, -0.319233954, 0)
ImageButtonOpen.Size = UDim2.new(0.157977879, 0, 0.316455692, 0)
ImageButtonOpen.Image = "rbxassetid://14856776704"
ImageButtonOpen.Active = true
ImageButtonOpen.Draggable = true

UICorner.CornerRadius = UDim.new(0, 90)
UICorner.Parent = ImageButtonOpen

ImageButtonOpen_2.Name = "ImageButtonOpen"
ImageButtonOpen_2.Parent = ServerSideExecutor
ImageButtonOpen_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageButtonOpen_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageButtonOpen_2.BorderSizePixel = 0
ImageButtonOpen_2.Position = UDim2.new(0, 0, 0.199753389, 0)
ImageButtonOpen_2.Size = UDim2.new(0.0622277521, 0, 0.123304561, 0)
ImageButtonOpen_2.Image = "rbxassetid://14856776704"

UICorner_2.CornerRadius = UDim.new(0, 90)
UICorner_2.Parent = ImageButtonOpen_2

-- Scripts:

local function AYDXIKA_fake_script() -- Frame.Main Script 
	local script = Instance.new('LocalScript', Frame)

	script.Parent.Draggable = true
	
	-- Variables
	local codetextbox = script.Parent.TextBoxCode
	local execute = script.Parent.ExecuteButton
	local remotesFolder = script.Parent.RemotesFolder
	
	-- Main script
	execute.MouseButton1Click:Connect(function()
		remotesFolder.Execute:FireServer(codetextbox.Text)
	end)
end
coroutine.wrap(AYDXIKA_fake_script)()
local function XHTDXR_fake_script() -- ImageButtonOpen.LocalScript 
	local script = Instance.new('LocalScript', ImageButtonOpen)

	script.Parent.MouseButton1Click:Connect(function(player)
		script.Parent.Parent.Visible = false
	end)
	
end
coroutine.wrap(XHTDXR_fake_script)()
local function ITTEYOG_fake_script() -- ImageButtonOpen_2.LocalScript 
	local script = Instance.new('LocalScript', ImageButtonOpen_2)

	script.Parent.MouseButton1Click:Connect(function(player)
		script.Parent.Parent.Frame.Visible = true
	end)
	
end
coroutine.wrap(ITTEYOG_fake_script)()
