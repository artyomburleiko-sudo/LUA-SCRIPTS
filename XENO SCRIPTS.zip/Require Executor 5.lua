-- Instances:
-- the very new version with dripped out UI

local febypass = Instance.new("ScreenGui")
local main = Instance.new("Frame")
local Inject = Instance.new("TextButton")
local Scripts = Instance.new("TextButton")
local Executor = Instance.new("TextButton")
local TextLabel = Instance.new("TextLabel")
local Startup = Instance.new("Frame")
local ImageLabel = Instance.new("ImageLabel")
local scripts = Instance.new("Frame")
local ScrollingFrame = Instance.new("ScrollingFrame")
local _4nn1 = Instance.new("TextButton")
local UIListLayout = Instance.new("UIListLayout")
local c00lgui = Instance.new("TextButton")
local IYAdmin = Instance.new("TextButton")
local k00pgui = Instance.new("TextButton")
local k00pguipass = Instance.new("TextButton")
local roexploit = Instance.new("TextButton")
local mml = Instance.new("TextButton")
local exit = Instance.new("TextButton")
local executor = Instance.new("Frame")
local TextLabel_2 = Instance.new("TextLabel")
local size = Instance.new("ScrollingFrame")
local UICorner = Instance.new("UICorner")
local Lines = Instance.new("TextLabel")
local CMDBox = Instance.new("TextBox")
local Tokens_ = Instance.new("TextLabel")
local Strings_ = Instance.new("TextLabel")
local RemoteHighlight_ = Instance.new("TextLabel")
local Numbers_ = Instance.new("TextLabel")
local Keywords_ = Instance.new("TextLabel")
local Globals_ = Instance.new("TextLabel")
local Comments_ = Instance.new("TextLabel")
local Execute = Instance.new("TextButton")
local Clear = Instance.new("TextButton")
local Respawn = Instance.new("TextButton")
local R6 = Instance.new("TextButton")
local sidebar = Instance.new("ScrollingFrame")
local close = Instance.new("TextButton")
local minimize = Instance.new("TextButton")
local oldexecutor = Instance.new("Frame")
local TextBox = Instance.new("TextBox")
local exe = Instance.new("TextButton")
local clr = Instance.new("TextButton")
local exit_2 = Instance.new("TextButton")

--Properties:

febypass.Name = "fe bypass"
febypass.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
febypass.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
febypass.ResetOnSpawn = false

main.Name = "main"
main.Parent = febypass
main.BackgroundColor3 = Color3.fromRGB(122, 122, 122)
main.BorderColor3 = Color3.fromRGB(189, 0, 0)
main.BorderSizePixel = 5
main.Position = UDim2.new(0.0296585672, 0, 0.631171346, 0)
main.Size = UDim2.new(0, 461, 0, 247)

Inject.Name = "Inject"
Inject.Parent = main
Inject.BackgroundColor3 = Color3.fromRGB(171, 171, 171)
Inject.BorderColor3 = Color3.fromRGB(157, 32, 32)
Inject.BorderSizePixel = 4
Inject.Position = UDim2.new(0.0244563799, 0, 0.0445344113, 0)
Inject.Size = UDim2.new(0, 148, 0, 225)
Inject.Font = Enum.Font.Gotham
Inject.Text = "LOAD FE BYPASS"
Inject.TextColor3 = Color3.fromRGB(0, 0, 0)
Inject.TextSize = 40.000
Inject.TextWrapped = true

Scripts.Name = "Scripts"
Scripts.Parent = main
Scripts.BackgroundColor3 = Color3.fromRGB(171, 171, 171)
Scripts.BorderColor3 = Color3.fromRGB(157, 32, 32)
Scripts.BorderSizePixel = 4
Scripts.Position = UDim2.new(0.408486992, 0, 0.0445344113, 0)
Scripts.Size = UDim2.new(0, 111, 0, 139)
Scripts.Font = Enum.Font.Gotham
Scripts.Text = "Scripts"
Scripts.TextColor3 = Color3.fromRGB(0, 0, 0)
Scripts.TextSize = 30.000
Scripts.TextWrapped = true

Executor.Name = "Executor"
Executor.Parent = main
Executor.BackgroundColor3 = Color3.fromRGB(171, 171, 171)
Executor.BorderColor3 = Color3.fromRGB(157, 32, 32)
Executor.BorderSizePixel = 4
Executor.Position = UDim2.new(0.717809081, 0, 0.0445344113, 0)
Executor.Size = UDim2.new(0, 111, 0, 139)
Executor.Font = Enum.Font.Gotham
Executor.Text = "Executor"
Executor.TextColor3 = Color3.fromRGB(0, 0, 0)
Executor.TextSize = 25.000
Executor.TextWrapped = true

TextLabel.Parent = main
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.381778747, 0, 0.607287467, 0)
TextLabel.Size = UDim2.new(0, 285, 0, 97)
TextLabel.Font = Enum.Font.Gotham
TextLabel.Text = "FE Bypass made by c00lkid"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextSize = 30.000
TextLabel.TextWrapped = true

Startup.Name = "Startup"
Startup.Parent = febypass
Startup.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Startup.BackgroundTransparency = 1.000
Startup.BorderColor3 = Color3.fromRGB(0, 0, 0)
Startup.BorderSizePixel = 0
Startup.Size = UDim2.new(0, 1915, 0, 930)
Startup.Visible = false

ImageLabel.Parent = Startup
ImageLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel.BackgroundTransparency = 1.000
ImageLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
ImageLabel.BorderSizePixel = 0
ImageLabel.Position = UDim2.new(0.242483005, 0, 0.190859482, 0)
ImageLabel.Size = UDim2.new(0, 988, 0, 576)
ImageLabel.Image = "http://www.roblox.com/asset/?id=13983709155"
ImageLabel.ImageTransparency = 1.000

scripts.Name = "scripts"
scripts.Parent = febypass
scripts.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
scripts.BorderColor3 = Color3.fromRGB(0, 0, 0)
scripts.BorderSizePixel = 0
scripts.Position = UDim2.new(0.558078647, 0, 0.374556422, 0)
scripts.Size = UDim2.new(0, 382, 0, 285)
scripts.Visible = false

ScrollingFrame.Parent = scripts
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScrollingFrame.BorderColor3 = Color3.fromRGB(0, 0, 0)
ScrollingFrame.BorderSizePixel = 0
ScrollingFrame.Position = UDim2.new(0.0523560196, 0, 0.0771929845, 0)
ScrollingFrame.Size = UDim2.new(0, 341, 0, 240)

_4nn1.Name = "4nn1"
_4nn1.Parent = ScrollingFrame
_4nn1.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
_4nn1.BorderColor3 = Color3.fromRGB(0, 0, 0)
_4nn1.BorderSizePixel = 0
_4nn1.Size = UDim2.new(0, 341, 0, 41)
_4nn1.ZIndex = 2
_4nn1.Font = Enum.Font.Gotham
_4nn1.Text = "require(9sxf7TVz)('username') -- 4nn1 GUI"
_4nn1.TextColor3 = Color3.fromRGB(255, 255, 255)
_4nn1.TextSize = 15.000

UIListLayout.Parent = ScrollingFrame
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder

c00lgui.Name = "c00lgui"
c00lgui.Parent = ScrollingFrame
c00lgui.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
c00lgui.BorderColor3 = Color3.fromRGB(0, 0, 0)
c00lgui.BorderSizePixel = 0
c00lgui.Size = UDim2.new(0, 341, 0, 41)
c00lgui.ZIndex = 2
c00lgui.Font = Enum.Font.Gotham
c00lgui.Text = "require(6032524768).Eagle('username') -- c00lgui"
c00lgui.TextColor3 = Color3.fromRGB(255, 255, 255)
c00lgui.TextSize = 12.000

IYAdmin.Name = "IY Admin"
IYAdmin.Parent = ScrollingFrame
IYAdmin.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
IYAdmin.BorderColor3 = Color3.fromRGB(0, 0, 0)
IYAdmin.BorderSizePixel = 0
IYAdmin.Size = UDim2.new(0, 341, 0, 41)
IYAdmin.ZIndex = 2
IYAdmin.Font = Enum.Font.Gotham
IYAdmin.Text = "require(7624679472)('username') -- IY Admin"
IYAdmin.TextColor3 = Color3.fromRGB(255, 255, 255)
IYAdmin.TextSize = 14.000

k00pgui.Name = "k00pgui"
k00pgui.Parent = ScrollingFrame
k00pgui.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
k00pgui.BorderColor3 = Color3.fromRGB(0, 0, 0)
k00pgui.BorderSizePixel = 0
k00pgui.Size = UDim2.new(0, 341, 0, 41)
k00pgui.ZIndex = 2
k00pgui.Font = Enum.Font.Gotham
k00pgui.Text = "require(0436277224).V8SKIDO('username') -- k00pgui"
k00pgui.TextColor3 = Color3.fromRGB(255, 255, 255)
k00pgui.TextSize = 11.000

k00pguipass.Name = "k00pgui pass"
k00pguipass.Parent = ScrollingFrame
k00pguipass.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
k00pguipass.BorderColor3 = Color3.fromRGB(0, 0, 0)
k00pguipass.BorderSizePixel = 0
k00pguipass.Size = UDim2.new(0, 341, 0, 41)
k00pguipass.ZIndex = 2
k00pguipass.Font = Enum.Font.Gotham
k00pguipass.Text = "k00pgui password : k00pkidd"
k00pguipass.TextColor3 = Color3.fromRGB(255, 255, 255)
k00pguipass.TextSize = 12.000

roexploit.Name = "roexploit"
roexploit.Parent = ScrollingFrame
roexploit.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
roexploit.BorderColor3 = Color3.fromRGB(0, 0, 0)
roexploit.BorderSizePixel = 0
roexploit.Size = UDim2.new(0, 341, 0, 41)
roexploit.ZIndex = 2
roexploit.Font = Enum.Font.Gotham
roexploit.Text = "require(4159766103).load('username') -- Ro-Xploit 6.0"
roexploit.TextColor3 = Color3.fromRGB(255, 255, 255)
roexploit.TextSize = 11.000

mml.Name = "mml"
mml.Parent = ScrollingFrame
mml.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
mml.BorderColor3 = Color3.fromRGB(0, 0, 0)
mml.BorderSizePixel = 0
mml.Size = UDim2.new(0, 341, 0, 41)
mml.ZIndex = 2
mml.Font = Enum.Font.Gotham
mml.Text = "require(4159766103).load('username') -- MML Admin"
mml.TextColor3 = Color3.fromRGB(255, 255, 255)
mml.TextSize = 12.000

exit.Name = "exit"
exit.Parent = scripts
exit.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
exit.BorderColor3 = Color3.fromRGB(0, 0, 0)
exit.BorderSizePixel = 0
exit.Position = UDim2.new(0.973822176, 0, -0.00278620142, 0)
exit.Size = UDim2.new(0, 10, 0, 14)
exit.Font = Enum.Font.Gotham
exit.Text = "X"
exit.TextColor3 = Color3.fromRGB(0, 0, 0)
exit.TextSize = 10.000

executor.Name = "executor"
executor.Parent = febypass
executor.BackgroundColor3 = Color3.fromRGB(53, 53, 53)
executor.BorderColor3 = Color3.fromRGB(255, 255, 255)
executor.Position = UDim2.new(0.0190408826, 0, 0.314197153, 0)
executor.Size = UDim2.new(0, 526, 0, 258)
executor.Visible = false

TextLabel_2.Parent = executor
TextLabel_2.BackgroundColor3 = Color3.fromRGB(53, 53, 53)
TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0.250950575, 0, 0, 0)
TextLabel_2.Size = UDim2.new(0, 237, 0, 31)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "Executor"
TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 13.000
TextLabel_2.TextWrapped = true
TextLabel_2.TextYAlignment = Enum.TextYAlignment.Top

size.Name = "size"
size.Parent = executor
size.Active = true
size.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
size.BorderSizePixel = 0
size.Position = UDim2.new(0.00708738808, 0, 0.122131824, 0)
size.Size = UDim2.new(0, 444, 0, 190)
size.BottomImage = "rbxassetid://148970562"
size.CanvasSize = UDim2.new(10, 0, 6, 0)
size.MidImage = "rbxassetid://148970562"
size.ScrollBarThickness = 3
size.TopImage = "rbxassetid://148970562"

UICorner.CornerRadius = UDim.new(0, 4)
UICorner.Parent = size

Lines.Name = "Lines"
Lines.Parent = size
Lines.BackgroundColor3 = Color3.fromRGB(53, 53, 53)
Lines.BorderSizePixel = 0
Lines.Size = UDim2.new(0, 24, 0, 1899)
Lines.Font = Enum.Font.Code
Lines.Text = "1"
Lines.TextColor3 = Color3.fromRGB(255, 255, 255)
Lines.TextSize = 14.000
Lines.TextWrapped = true
Lines.TextXAlignment = Enum.TextXAlignment.Right
Lines.TextYAlignment = Enum.TextYAlignment.Top

CMDBox.Name = "CMDBox"
CMDBox.Parent = size
CMDBox.BackgroundColor3 = Color3.fromRGB(33, 33, 33)
CMDBox.BackgroundTransparency = 1.000
CMDBox.Position = UDim2.new(0.00885447953, -21, -7.4505806e-09, 0)
CMDBox.Size = UDim2.new(0, 4760, 0, 1868)
CMDBox.ClearTextOnFocus = false
CMDBox.Font = Enum.Font.Code
CMDBox.MultiLine = true
CMDBox.PlaceholderColor3 = Color3.fromRGB(118, 118, 118)
CMDBox.PlaceholderText = "-- best exploit better than ronaldo christiano 7"
CMDBox.Text = ""
CMDBox.TextColor3 = Color3.fromRGB(0, 0, 0)
CMDBox.TextSize = 14.000
CMDBox.TextWrapped = true
CMDBox.TextXAlignment = Enum.TextXAlignment.Left
CMDBox.TextYAlignment = Enum.TextYAlignment.Top

Tokens_.Name = "Tokens_"
Tokens_.Parent = CMDBox
Tokens_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Tokens_.BackgroundTransparency = 1.000
Tokens_.Size = UDim2.new(1, 0, 1, 0)
Tokens_.ZIndex = 5
Tokens_.Font = Enum.Font.Code
Tokens_.Text = ""
Tokens_.TextColor3 = Color3.fromRGB(165, 56, 255)
Tokens_.TextSize = 14.000
Tokens_.TextWrapped = true
Tokens_.TextXAlignment = Enum.TextXAlignment.Left
Tokens_.TextYAlignment = Enum.TextYAlignment.Top

Strings_.Name = "Strings_"
Strings_.Parent = CMDBox
Strings_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Strings_.BackgroundTransparency = 1.000
Strings_.Size = UDim2.new(1, 0, 1, 0)
Strings_.ZIndex = 5
Strings_.Font = Enum.Font.Code
Strings_.Text = ""
Strings_.TextColor3 = Color3.fromRGB(173, 241, 149)
Strings_.TextSize = 14.000
Strings_.TextWrapped = true
Strings_.TextXAlignment = Enum.TextXAlignment.Left
Strings_.TextYAlignment = Enum.TextYAlignment.Top

RemoteHighlight_.Name = "RemoteHighlight_"
RemoteHighlight_.Parent = CMDBox
RemoteHighlight_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
RemoteHighlight_.BackgroundTransparency = 1.000
RemoteHighlight_.Size = UDim2.new(1, 0, 1, 0)
RemoteHighlight_.ZIndex = 5
RemoteHighlight_.Font = Enum.Font.Code
RemoteHighlight_.Text = ""
RemoteHighlight_.TextColor3 = Color3.fromRGB(0, 144, 255)
RemoteHighlight_.TextSize = 14.000
RemoteHighlight_.TextWrapped = true
RemoteHighlight_.TextXAlignment = Enum.TextXAlignment.Left
RemoteHighlight_.TextYAlignment = Enum.TextYAlignment.Top

Numbers_.Name = "Numbers_"
Numbers_.Parent = CMDBox
Numbers_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Numbers_.BackgroundTransparency = 1.000
Numbers_.Size = UDim2.new(1, 0, 1, 0)
Numbers_.ZIndex = 4
Numbers_.Font = Enum.Font.Code
Numbers_.Text = ""
Numbers_.TextColor3 = Color3.fromRGB(255, 198, 0)
Numbers_.TextSize = 14.000
Numbers_.TextWrapped = true
Numbers_.TextXAlignment = Enum.TextXAlignment.Left
Numbers_.TextYAlignment = Enum.TextYAlignment.Top

Keywords_.Name = "Keywords_"
Keywords_.Parent = CMDBox
Keywords_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Keywords_.BackgroundTransparency = 1.000
Keywords_.Size = UDim2.new(1, 0, 1, 0)
Keywords_.ZIndex = 5
Keywords_.Font = Enum.Font.Code
Keywords_.Text = ""
Keywords_.TextColor3 = Color3.fromRGB(248, 0, 4)
Keywords_.TextSize = 14.000
Keywords_.TextWrapped = true
Keywords_.TextXAlignment = Enum.TextXAlignment.Left
Keywords_.TextYAlignment = Enum.TextYAlignment.Top

Globals_.Name = "Globals_"
Globals_.Parent = CMDBox
Globals_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Globals_.BackgroundTransparency = 1.000
Globals_.Size = UDim2.new(1, 0, 1, 0)
Globals_.ZIndex = 5
Globals_.Font = Enum.Font.Code
Globals_.Text = ""
Globals_.TextColor3 = Color3.fromRGB(132, 214, 247)
Globals_.TextSize = 14.000
Globals_.TextWrapped = true
Globals_.TextXAlignment = Enum.TextXAlignment.Left
Globals_.TextYAlignment = Enum.TextYAlignment.Top

Comments_.Name = "Comments_"
Comments_.Parent = CMDBox
Comments_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Comments_.BackgroundTransparency = 1.000
Comments_.Size = UDim2.new(1, 0, 1, 0)
Comments_.ZIndex = 5
Comments_.Font = Enum.Font.Code
Comments_.Text = ""
Comments_.TextColor3 = Color3.fromRGB(59, 200, 59)
Comments_.TextSize = 14.000
Comments_.TextWrapped = true
Comments_.TextXAlignment = Enum.TextXAlignment.Left
Comments_.TextYAlignment = Enum.TextYAlignment.Top

Execute.Name = "Execute"
Execute.Parent = executor
Execute.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Execute.BorderColor3 = Color3.fromRGB(0, 0, 0)
Execute.BorderSizePixel = 0
Execute.Position = UDim2.new(0.00570342224, 0, 0.875968993, 2)
Execute.Size = UDim2.new(0, 142, 0, 26)
Execute.Font = Enum.Font.SourceSans
Execute.Text = "Execute"
Execute.TextColor3 = Color3.fromRGB(0, 0, 0)
Execute.TextScaled = true
Execute.TextSize = 14.000
Execute.TextWrapped = true

Clear.Name = "Clear"
Clear.Parent = executor
Clear.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Clear.BorderColor3 = Color3.fromRGB(0, 0, 0)
Clear.BorderSizePixel = 0
Clear.Position = UDim2.new(0.292775661, 0, 0.875968993, 2)
Clear.Size = UDim2.new(0, 142, 0, 26)
Clear.Font = Enum.Font.SourceSans
Clear.Text = "Clear"
Clear.TextColor3 = Color3.fromRGB(0, 0, 0)
Clear.TextScaled = true
Clear.TextSize = 14.000
Clear.TextWrapped = true

Respawn.Name = "Respawn"
Respawn.Parent = executor
Respawn.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Respawn.BorderColor3 = Color3.fromRGB(0, 0, 0)
Respawn.BorderSizePixel = 0
Respawn.Position = UDim2.new(0.579847872, 0, 0.875968993, 2)
Respawn.Size = UDim2.new(0, 142, 0, 26)
Respawn.Font = Enum.Font.SourceSans
Respawn.Text = "Respawn"
Respawn.TextColor3 = Color3.fromRGB(0, 0, 0)
Respawn.TextScaled = true
Respawn.TextSize = 14.000
Respawn.TextWrapped = true

R6.Name = "R6"
R6.Parent = executor
R6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
R6.BorderColor3 = Color3.fromRGB(0, 0, 0)
R6.BorderSizePixel = 0
R6.Position = UDim2.new(0.865018964, 0, 0.875968993, 2)
R6.Size = UDim2.new(0, 68, 0, 26)
R6.Font = Enum.Font.SourceSans
R6.Text = "R6"
R6.TextColor3 = Color3.fromRGB(0, 0, 0)
R6.TextScaled = true
R6.TextSize = 14.000
R6.TextWrapped = true

sidebar.Name = "sidebar"
sidebar.Parent = executor
sidebar.Active = true
sidebar.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
sidebar.BorderColor3 = Color3.fromRGB(0, 0, 0)
sidebar.BorderSizePixel = 0
sidebar.Position = UDim2.new(0.865018964, 0, 0.120155036, 0)
sidebar.Size = UDim2.new(0, 68, 0, 192)
sidebar.BottomImage = "rbxassetid://148970562"
sidebar.CanvasSize = UDim2.new(0, 0, 6, 0)
sidebar.MidImage = "rbxassetid://148970562"
sidebar.ScrollBarThickness = 3

close.Name = "close"
close.Parent = executor
close.BackgroundColor3 = Color3.fromRGB(115, 115, 115)
close.BorderColor3 = Color3.fromRGB(0, 0, 0)
close.BorderSizePixel = 0
close.Position = UDim2.new(0.961977184, 0, -0.00775193796, 2)
close.Size = UDim2.new(0, 20, 0, 20)
close.Font = Enum.Font.SourceSans
close.Text = "X"
close.TextColor3 = Color3.fromRGB(255, 255, 255)
close.TextScaled = true
close.TextSize = 14.000
close.TextWrapped = true

minimize.Name = "minimize"
minimize.Parent = executor
minimize.BackgroundColor3 = Color3.fromRGB(115, 115, 115)
minimize.BorderColor3 = Color3.fromRGB(0, 0, 0)
minimize.BorderSizePixel = 0
minimize.Position = UDim2.new(0.923954368, 0, -0.00775193796, 2)
minimize.Size = UDim2.new(0, 20, 0, 20)
minimize.Font = Enum.Font.SourceSans
minimize.Text = "-"
minimize.TextColor3 = Color3.fromRGB(255, 255, 255)
minimize.TextScaled = true
minimize.TextSize = 14.000
minimize.TextWrapped = true

oldexecutor.Name = "old executor"
oldexecutor.Parent = febypass
oldexecutor.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
oldexecutor.BorderColor3 = Color3.fromRGB(0, 0, 0)
oldexecutor.BorderSizePixel = 0
oldexecutor.Position = UDim2.new(0.625851631, 0, 0.316864103, 0)
oldexecutor.Size = UDim2.new(0, 382, 0, 285)
oldexecutor.Visible = false

TextBox.Parent = oldexecutor
TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextBox.BorderSizePixel = 0
TextBox.Position = UDim2.new(0.0235603694, 0, 0.0479001589, 0)
TextBox.Size = UDim2.new(0, 363, 0, 217)
TextBox.Font = Enum.Font.SourceSans
TextBox.Text = ""
TextBox.TextColor3 = Color3.fromRGB(0, 0, 0)
TextBox.TextSize = 14.000
TextBox.TextXAlignment = Enum.TextXAlignment.Left
TextBox.TextYAlignment = Enum.TextYAlignment.Top

exe.Name = "exe"
exe.Parent = oldexecutor
exe.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
exe.BorderColor3 = Color3.fromRGB(0, 0, 0)
exe.BorderSizePixel = 0
exe.Position = UDim2.new(0, 0, 0.84984535, 0)
exe.Size = UDim2.new(0, 183, 0, 46)
exe.Font = Enum.Font.Gotham
exe.Text = "execute"
exe.TextColor3 = Color3.fromRGB(0, 0, 0)
exe.TextSize = 40.000

clr.Name = "clr"
clr.Parent = oldexecutor
clr.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
clr.BorderColor3 = Color3.fromRGB(0, 0, 0)
clr.BorderSizePixel = 0
clr.Position = UDim2.new(0.520942569, 0, 0.84984535, 0)
clr.Size = UDim2.new(0, 183, 0, 46)
clr.Font = Enum.Font.Gotham
clr.Text = "clear"
clr.TextColor3 = Color3.fromRGB(0, 0, 0)
clr.TextSize = 40.000

exit_2.Name = "exit"
exit_2.Parent = oldexecutor
exit_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
exit_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
exit_2.BorderSizePixel = 0
exit_2.Position = UDim2.new(0.973822176, 0, -0.00278620142, 0)
exit_2.Size = UDim2.new(0, 10, 0, 14)
exit_2.Font = Enum.Font.Gotham
exit_2.Text = "X"
exit_2.TextColor3 = Color3.fromRGB(0, 0, 0)
exit_2.TextSize = 10.000

-- Scripts:

local function EYBRV_fake_script() -- Inject.LocalScript 
	local script = Instance.new('LocalScript', Inject)

	local injected = false
	
	script.Parent.MouseButton1Click:Connect(function()
		if injected == false then
			local message = Instance.new("Message")
			message.Parent = workspace
			message.Text = "FEBYPASS SKID LOADING..."
			wait(4)
			message.Text = "FEBYPASS SKID LOADED DESTROY THE GAME!"
			wait(2)
			message:Destroy()
			injected = true
		elseif injected == true then
			local message = Instance.new("Message")
			message.Parent = workspace
			message.Text = "Already loaded!"
			wait(1)
			message:Destroy()
		end
	end)
end
coroutine.wrap(EYBRV_fake_script)()
local function DWQQH_fake_script() -- Scripts.LocalScript 
	local script = Instance.new('LocalScript', Scripts)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.scripts.Visible = true
	end)
end
coroutine.wrap(DWQQH_fake_script)()
local function QPQOTFN_fake_script() -- Executor.LocalScript 
	local script = Instance.new('LocalScript', Executor)

	local bypassed = false
	
	script.Parent.Parent.Inject.MouseButton1Click:Connect(function()
		wait(4)
		bypassed = true
	end)
	
	script.Parent.MouseButton1Click:Connect(function()
		if bypassed == true then
			script.Parent.Parent.Parent.executor.Visible = true
		elseif bypassed == false then
			local message = Instance.new("Message")
			message.Parent = workspace
			message.Text = "HAVENT LOADED FEBYASS SKID"
			wait(1)
			message:Destroy()
		end
	end)
end
coroutine.wrap(QPQOTFN_fake_script)()
local function OMYK_fake_script() -- main.Smooth GUI Dragging 
	local script = Instance.new('LocalScript', main)

	local UserInputService = game:GetService("UserInputService")
	local runService = (game:GetService("RunService"));
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	function Lerp(a, b, m)
		return a + (b - a) * m
	end;
	
	local lastMousePos
	local lastGoalPos
	local DRAG_SPEED = (8); -- // The speed of the UI darg.
	function Update(dt)
		if not (startPos) then return end;
		if not (dragging) and (lastGoalPos) then
			gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, lastGoalPos.X.Offset, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, lastGoalPos.Y.Offset, dt * DRAG_SPEED))
			return 
		end;
	
		local delta = (lastMousePos - UserInputService:GetMouseLocation())
		local xGoal = (startPos.X.Offset - delta.X);
		local yGoal = (startPos.Y.Offset - delta.Y);
		lastGoalPos = UDim2.new(startPos.X.Scale, xGoal, startPos.Y.Scale, yGoal)
		gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, xGoal, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, yGoal, dt * DRAG_SPEED))
	end;
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
			lastMousePos = UserInputService:GetMouseLocation()
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	runService.Heartbeat:Connect(Update)
end
coroutine.wrap(OMYK_fake_script)()
local function AINEOYK_fake_script() -- Startup.LocalScript 
	local script = Instance.new('LocalScript', Startup)

	script.Parent.BackgroundTransparency = 1
	script.Parent.ImageLabel.ImageTransparency = 1
	wait()
	script.Parent.BackgroundTransparency = 0.9
	script.Parent.ImageLabel.ImageTransparency = 0.9
	wait()
	script.Parent.BackgroundTransparency = 0.8
	script.Parent.ImageLabel.ImageTransparency = 0.8
	wait()
	script.Parent.BackgroundTransparency = 0.7
	script.Parent.ImageLabel.ImageTransparency = 0.7
	wait()
	script.Parent.BackgroundTransparency = 0.6
	script.Parent.ImageLabel.ImageTransparency = 0.6
	wait()
	script.Parent.BackgroundTransparency = 0.5
	script.Parent.ImageLabel.ImageTransparency = 0.5
	wait()
	script.Parent.BackgroundTransparency = 0.4
	script.Parent.ImageLabel.ImageTransparency = 0.4
	wait()
	script.Parent.BackgroundTransparency = 0.3
	script.Parent.ImageLabel.ImageTransparency = 0.3
	wait()
	script.Parent.BackgroundTransparency = 0.2
	script.Parent.ImageLabel.ImageTransparency = 0.2
	wait()
	script.Parent.BackgroundTransparency = 0.1
	script.Parent.ImageLabel.ImageTransparency = 0.1
	wait()
	script.Parent.BackgroundTransparency = 0
	script.Parent.ImageLabel.ImageTransparency = 0
	wait(5)
	script.Parent.BackgroundTransparency = 0.1
	script.Parent.ImageLabel.ImageTransparency = 0.1
	wait()
	script.Parent.BackgroundTransparency = 0.2
	script.Parent.ImageLabel.ImageTransparency = 0.2
	wait()
	script.Parent.BackgroundTransparency = 0.3
	script.Parent.ImageLabel.ImageTransparency = 0.3
	wait()
	script.Parent.BackgroundTransparency = 0.4
	script.Parent.ImageLabel.ImageTransparency = 0.4
	wait()
	script.Parent.BackgroundTransparency = 0.5
	script.Parent.ImageLabel.ImageTransparency = 0.5
	wait()
	script.Parent.BackgroundTransparency = 0.6
	script.Parent.ImageLabel.ImageTransparency = 0.6
	wait()
	script.Parent.BackgroundTransparency = 0.7
	script.Parent.ImageLabel.ImageTransparency = 0.7
	wait()
	script.Parent.BackgroundTransparency = 0.8
	script.Parent.ImageLabel.ImageTransparency = 0.8
	wait()
	script.Parent.BackgroundTransparency = 0.9
	script.Parent.ImageLabel.ImageTransparency = 0.9
	wait()
	script.Parent.BackgroundTransparency = 1
	script.Parent.ImageLabel.ImageTransparency = 1
	wait()
end
coroutine.wrap(AINEOYK_fake_script)()
local function KFOAPR_fake_script() -- scripts.Smooth GUI Dragging 
	local script = Instance.new('LocalScript', scripts)

	local UserInputService = game:GetService("UserInputService")
	local runService = (game:GetService("RunService"));
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	function Lerp(a, b, m)
		return a + (b - a) * m
	end;
	
	local lastMousePos
	local lastGoalPos
	local DRAG_SPEED = (8); -- // The speed of the UI darg.
	function Update(dt)
		if not (startPos) then return end;
		if not (dragging) and (lastGoalPos) then
			gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, lastGoalPos.X.Offset, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, lastGoalPos.Y.Offset, dt * DRAG_SPEED))
			return 
		end;
	
		local delta = (lastMousePos - UserInputService:GetMouseLocation())
		local xGoal = (startPos.X.Offset - delta.X);
		local yGoal = (startPos.Y.Offset - delta.Y);
		lastGoalPos = UDim2.new(startPos.X.Scale, xGoal, startPos.Y.Scale, yGoal)
		gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, xGoal, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, yGoal, dt * DRAG_SPEED))
	end;
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
			lastMousePos = UserInputService:GetMouseLocation()
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	runService.Heartbeat:Connect(Update)
end
coroutine.wrap(KFOAPR_fake_script)()
local function ENLQY_fake_script() -- _4nn1.LocalScript 
	local script = Instance.new('LocalScript', _4nn1)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(9sxf7TVz)('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(ENLQY_fake_script)()
local function LBQG_fake_script() -- c00lgui.LocalScript 
	local script = Instance.new('LocalScript', c00lgui)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(6032524768).Eagle('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(LBQG_fake_script)()
local function SARG_fake_script() -- IYAdmin.LocalScript 
	local script = Instance.new('LocalScript', IYAdmin)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(7624679472)('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(SARG_fake_script)()
local function LHWE_fake_script() -- k00pgui.LocalScript 
	local script = Instance.new('LocalScript', k00pgui)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(0x31051dacc).v2FIXED('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(LHWE_fake_script)()
local function UZZQTF_fake_script() -- roexploit.LocalScript 
	local script = Instance.new('LocalScript', roexploit)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(4159766103).load('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(UZZQTF_fake_script)()
local function JYJLOMR_fake_script() -- mml.LocalScript 
	local script = Instance.new('LocalScript', mml)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Parent.Parent.executor.size.CMDBox.Text = "require(5051243290).mml('"..game.Players.LocalPlayer.Name.."')"
	end)
end
coroutine.wrap(JYJLOMR_fake_script)()
local function FTTAREU_fake_script() -- exit.LocalScript 
	local script = Instance.new('LocalScript', exit)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Visible = false
	end)
end
coroutine.wrap(FTTAREU_fake_script)()
local function IGTPY_fake_script() -- Lines.stats 
	local script = Instance.new('LocalScript', Lines)

	function updateStats()
		while true do
			local function getLines(str)
				local lin = 1
				str:gsub("\n", function()
					lin = lin + 1
				end)
	
				return lin
			end
			local function getCharacter(str)
				local lin = 0
				str:gsub("", function()
					lin = lin + 1
				end)
	
				return lin
			end
			while true do
				script.Parent.Text = "\n"..getLines(script.Parent.Parent.CMDBox.Text)
				game:GetService("RunService").Stepped:Wait()
			end
		end	
	end
	
	function Main()
		spawn(updateStats)
	end
	
	updateStats()
	Main()
	
	
end
coroutine.wrap(IGTPY_fake_script)()
local function LYANG_fake_script() -- size.Highlighting 
	local script = Instance.new('LocalScript', size)

	local lua_keywords = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while"}
	local global_env = {"getrawmetatable", "game", "workspace", "script", "math", "string", "table", "print", "wait", "BrickColor", "Color3", "next", "pairs", "ipairs", "select", "unpack", "Instance", "Vector2", "Vector3", "CFrame", "Ray", "UDim2", "Enum", "assert", "error", "warn", "tick", "loadstring", "_G", "shared", "getfenv", "setfenv", "newproxy", "setmetatable", "getmetatable", "os", "debug", "pcall", "ypcall", "xpcall", "rawequal", "rawset", "rawget", "tonumber", "tostring", "type", "typeof", "_VERSION", "coroutine", "delay", "require", "spawn", "LoadLibrary", "settings", "stats", "time", "UserSettings", "version", "Axes", "ColorSequence", "Faces", "ColorSequenceKeypoint", "NumberRange", "NumberSequence", "NumberSequenceKeypoint", "gcinfo", "elapsedTime", "collectgarbage", "PhysicalProperties", "Rect", "Region3", "Region3int16", "UDim", "Vector2int16", "Vector3int16"}
	
	local Source = script.Parent.CMDBox
	local Lines = Source.Parent.Lines
	
	local Highlight = function(string, keywords)
		local K = {}
		local S = string
		local Token =
			{
				["="] = true,
				["."] = true,
				[","] = true,
				["("] = true,
				[")"] = true,
				["["] = true,
				["]"] = true,
				["{"] = true,
				["}"] = true,
				[":"] = true,
				["*"] = true,
				["/"] = true,
				["+"] = true,
				["-"] = true,
				["%"] = true,
				[";"] = true,
				["~"] = true
			}
		for i, v in pairs(keywords) do
			K[v] = true
		end
		S = S:gsub(".", function(c)
			if Token[c] ~= nil then
				return "\32"
			else
				return c
			end
		end)
		S = S:gsub("%S+", function(c)
			if K[c] ~= nil then
				return c
			else
				return (" "):rep(#c)
			end
		end)
	
		return S
	end
	
	local hTokens = function(string)
		local Token =
			{
				["="] = true,
				["."] = true,
				[","] = true,
				["("] = true,
				[")"] = true,
				["["] = true,
				["]"] = true,
				["{"] = true,
				["}"] = true,
				[":"] = true,
				["*"] = true,
				["/"] = true,
				["+"] = true,
				["-"] = true,
				["%"] = true,
				[";"] = true,
				["~"] = true
			}
		local A = ""
		string:gsub(".", function(c)
			if Token[c] ~= nil then
				A = A .. c
			elseif c == "\n" then
				A = A .. "\n"
			elseif c == "\t" then
				A = A .. "\t"
			else
				A = A .. "\32"
			end
		end)
	
		return A
	end
	
	
	local strings = function(string)
		local highlight = ""
		local quote = false
		string:gsub(".", function(c)
			if quote == false and c == "\"" then
				quote = true
			elseif quote == true and c == "\"" then
				quote = false
			end
			if quote == false and c == "\"" then
				highlight = highlight .. "\""
			elseif c == "\n" then
				highlight = highlight .. "\n"
			elseif c == "\t" then
				highlight = highlight .. "\t"
			elseif quote == true then
				highlight = highlight .. c
			elseif quote == false then
				highlight = highlight .. "\32"
			end
		end)
	
		return highlight
	end
	
	local comments = function(string)
		local ret = ""
		string:gsub("[^\r\n]+", function(c)
			local comm = false
			local i = 0
			c:gsub(".", function(n)
				i = i + 1
				if c:sub(i, i + 1) == "--" then
					comm = true
				end
				if comm == true then
					ret = ret .. n
				else
					ret = ret .. "\32"
				end
			end)
			ret = ret
		end)
	
		return ret
	end
	
	local numbers = function(string)
		local A = ""
		string:gsub(".", function(c)
			if tonumber(c) ~= nil then
				A = A .. c
			elseif c == "\n" then
				A = A .. "\n"
			elseif c == "\t" then
				A = A .. "\t"
			else
				A = A .. "\32"
			end
		end)
	
		return A
	end
	
	local highlight_source = function(type)
		if type == "Text" then
			Source.Text = Source.Text:gsub("\13", "")
			Source.Text = Source.Text:gsub("\t", "      ")
			local s = Source.Text
			Source.Keywords_.Text = Highlight(s, lua_keywords)
			Source.Globals_.Text = Highlight(s, global_env)
			Source.RemoteHighlight_.Text = Highlight(s, {"FireServer", "fireServer", "InvokeServer", "invokeServer"})
			Source.Tokens_.Text = hTokens(s)
			Source.Numbers_.Text = numbers(s)
			Source.Strings_.Text = strings(s)
			local lin = 1
			s:gsub("\n", function()
				lin = lin + 1
			end)
			Lines.Text = ""
			for i = 1, lin do
				Lines.Text = Lines.Text .. i .. "\n"
			end
		end
	end
	
	highlight_source("Text")
	
	Source.Changed:Connect(highlight_source)
end
coroutine.wrap(LYANG_fake_script)()
local function YPLY_fake_script() -- Execute.LocalScript 
	local script = Instance.new('LocalScript', Execute)

	script.Parent.MouseButton1Click:Connect(function()
		if script.Parent.Parent.size.CMDBox.Text == "require(6032524768).Eagle('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/c00lgui%20reimagined'),true))()
		elseif script.Parent.Parent.size.CMDBox.Text == "require(9sxf7TVz)('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://pastebin.com/raw/9sxf7TVz'),true))()
		elseif script.Parent.Parent.size.CMDBox.Text == "require(7624679472)('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/IY%20Admin'),true))()
		elseif script.Parent.Parent.size.CMDBox.Text == "require(0x31051dacc).v2FIXED('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/k00pgui'),true))()
		elseif script.Parent.Parent.size.CMDBox.Text == "require(4159766103).load('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/Ro-Xploit'),true))()
		elseif script.Parent.Parent.size.CMDBox.Text == "require(5051243290).mml('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/mml%20admin'),true))()
		end
	end)
end
coroutine.wrap(YPLY_fake_script)()
local function FDXUXR_fake_script() -- Execute.LocalScript 
	local script = Instance.new('LocalScript', Execute)

	script.Parent.MouseButton1Click:Connect(function()
		assert(loadstring(script.Parent.Parent.size.CMDBox.Text))()
	end)
end
coroutine.wrap(FDXUXR_fake_script)()
local function DORNZC_fake_script() -- Clear.LocalScript 
	local script = Instance.new('LocalScript', Clear)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.size.CMDBox.Text = "Cleared Text!"
		wait(1)
		script.Parent.Parent.size.CMDBox.Text = ""
	end)
end
coroutine.wrap(DORNZC_fake_script)()
local function QHSTX_fake_script() -- Respawn.LocalScript 
	local script = Instance.new('LocalScript', Respawn)

	script.Parent.MouseButton1Click:connect(function()
		game.Players.LocalPlayer.Character:Destroy()
	end)
end
coroutine.wrap(QHSTX_fake_script)()
local function MAGV_fake_script() -- R6.LocalScript 
	local script = Instance.new('LocalScript', R6)

	script.Parent.MouseButton1Click:Connect(function()
		loadstring(game:HttpGet("https://raw.githubusercontent.com/rusello25/scripts/main/R6", true))()
	end)
end
coroutine.wrap(MAGV_fake_script)()
local function RHPQ_fake_script() -- close.LocalScript 
	local script = Instance.new('LocalScript', close)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Visible = true
	end)
end
coroutine.wrap(RHPQ_fake_script)()
local function UFFYZ_fake_script() -- minimize.LocalScript 
	local script = Instance.new('LocalScript', minimize)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Visible = false
	end)
end
coroutine.wrap(UFFYZ_fake_script)()
local function ESLR_fake_script() -- executor.LocalScript 
	local script = Instance.new('LocalScript', executor)

	local UIS = game:GetService("UserInputService")
	function dragify(Frame)
		dragToggle = nil
		local dragSpeed = 0.33
		dragInput = nil
		dragStart = nil
		local dragPos = nil
		function updateInput(input)
			local Delta = input.Position - dragStart
			local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
			game:GetService("TweenService"):Create(Frame, TweenInfo.new(0.25), {Position = Position}):Play()
		end
		Frame.InputBegan:Connect(function(input)
			if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) and UIS:GetFocusedTextBox() == nil then
				dragToggle = true
				dragStart = input.Position
				startPos = Frame.Position
				input.Changed:Connect(function()
					if input.UserInputState == Enum.UserInputState.End then
						dragToggle = false
					end
				end)
			end
		end)
		Frame.InputChanged:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
				dragInput = input
			end
		end)
		game:GetService("UserInputService").InputChanged:Connect(function(input)
			if input == dragInput and dragToggle then
				updateInput(input)
			end
		end)
	end
	
	dragify(script.Parent)
end
coroutine.wrap(ESLR_fake_script)()
local function IUOIY_fake_script() -- exe.LocalScript 
	local script = Instance.new('LocalScript', exe)

	script.Parent.MouseButton1Click:Connect(function()
		if script.Parent.Parent.TextBox.Text == "require(6032524768).Eagle('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/c00lgui%20reimagined'),true))()
		elseif script.Parent.Parent.TextBox.Text == "require(9sxf7TVz)('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://pastebin.com/raw/9sxf7TVz'),true))()
		elseif script.Parent.Parent.TextBox.Text == "require(7624679472)('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/IY%20Admin'),true))()
		elseif script.Parent.Parent.TextBox.Text == "require(0x31051dacc).v2FIXED('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/k00pgui'),true))()
		elseif script.Parent.Parent.TextBox.Text == "require(4159766103).load('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/Ro-Xploit'),true))()
		elseif script.Parent.Parent.TextBox.Text == "require(5051243290).mml('"..game.Players.LocalPlayer.Name.."')" then
			loadstring(game:HttpGet(('https://raw.githubusercontent.com/rusello25/scripts/main/mml%20admin'),true))()
		end
	end)
end
coroutine.wrap(IUOIY_fake_script)()
local function FSJNU_fake_script() -- clr.LocalScript 
	local script = Instance.new('LocalScript', clr)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.TextBox.Text = ""
	end)
end
coroutine.wrap(FSJNU_fake_script)()
local function WAKMR_fake_script() -- oldexecutor.Smooth GUI Dragging 
	local script = Instance.new('LocalScript', oldexecutor)

	local UserInputService = game:GetService("UserInputService")
	local runService = (game:GetService("RunService"));
	
	local gui = script.Parent
	
	local dragging
	local dragInput
	local dragStart
	local startPos
	
	function Lerp(a, b, m)
		return a + (b - a) * m
	end;
	
	local lastMousePos
	local lastGoalPos
	local DRAG_SPEED = (8); -- // The speed of the UI darg.
	function Update(dt)
		if not (startPos) then return end;
		if not (dragging) and (lastGoalPos) then
			gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, lastGoalPos.X.Offset, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, lastGoalPos.Y.Offset, dt * DRAG_SPEED))
			return 
		end;
	
		local delta = (lastMousePos - UserInputService:GetMouseLocation())
		local xGoal = (startPos.X.Offset - delta.X);
		local yGoal = (startPos.Y.Offset - delta.Y);
		lastGoalPos = UDim2.new(startPos.X.Scale, xGoal, startPos.Y.Scale, yGoal)
		gui.Position = UDim2.new(startPos.X.Scale, Lerp(gui.Position.X.Offset, xGoal, dt * DRAG_SPEED), startPos.Y.Scale, Lerp(gui.Position.Y.Offset, yGoal, dt * DRAG_SPEED))
	end;
	
	gui.InputBegan:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch then
			dragging = true
			dragStart = input.Position
			startPos = gui.Position
			lastMousePos = UserInputService:GetMouseLocation()
	
			input.Changed:Connect(function()
				if input.UserInputState == Enum.UserInputState.End then
					dragging = false
				end
			end)
		end
	end)
	
	gui.InputChanged:Connect(function(input)
		if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
			dragInput = input
		end
	end)
	
	runService.Heartbeat:Connect(Update)
end
coroutine.wrap(WAKMR_fake_script)()
local function COLYK_fake_script() -- exit_2.LocalScript 
	local script = Instance.new('LocalScript', exit_2)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.Visible = false
	end)
end
coroutine.wrap(COLYK_fake_script)()