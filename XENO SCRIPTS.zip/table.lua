--Support Sign^-^
local runDummyScript = function(f,scri)
local oldenv = getfenv(f)
local newenv = setmetatable({}, {
__index = function(_, k)
if k:lower() == 'script' then
return scri
else
return oldenv[k]
end
end
})
setfenv(f, newenv)
ypcall(function() f() end)
end
cors = {}
mas = Instance.new("Model",game:GetService("Lighting")) 
mas.Name = "CompiledModel"
o1 = Instance.new("Tool")
o2 = Instance.new("Part")
o3 = Instance.new("SurfaceGui")
o4 = Instance.new("TextLabel")
o5 = Instance.new("Part")
o6 = Instance.new("ManualWeld")
o7 = Instance.new("ManualWeld")
o9 = Instance.new("Model")
o10 = Instance.new("LocalScript")
o11 = Instance.new("ScreenGui")
o12 = Instance.new("Frame")
o13 = Instance.new("TextLabel")
o14 = Instance.new("TextBox")
o1.Name = "Sign"
o1.Parent = game.Players.LocalPlayer.Backpack
o1.GripPos = Vector3.new(0, -1, 0)
o2.Name = "Sign"
o2.Parent = o1
o2.Material = Enum.Material.WoodPlanks
o2.BrickColor = BrickColor.new("Reddish brown")
o2.Position = Vector3.new(6.00002432, -6.5, -7.6999712)
o2.Rotation = Vector3.new(0, 1, 0)
o2.Size = Vector3.new(4, 2.20000005, 0.200000003)
o2.CFrame = CFrame.new(6.00002432, -6.5, -7.6999712, 0.99984777, 0, 0.0174509957, 0, 1, 0, -0.0174509957, 0, 0.99984777)
o2.Color = Color3.new(0.411765, 0.25098, 0.156863)
o2.Position = Vector3.new(6.00002432, -6.5, -7.6999712)
o3.Parent = o2
o3.CanvasSize = Vector2.new(200, 100)
o4.Parent = o3
o4.Size = UDim2.new(1,0,1,0)
o4.Text = "Insert Text Here"
o4.Active = true
o4.BackgroundColor3 = Color3.new(1, 1, 1)
o4.BackgroundTransparency = 1
o4.Font = Enum.Font.ArialBold
o4.FontSize = Enum.FontSize.Size12
o4.TextColor3 = Color3.new(1, 1, 1)
o4.TextScaled = true
o4.TextStrokeColor3 = Color3.new(0, 0.0117647, 0)
o4.TextStrokeTransparency = 0
o4.TextWrapped = true
o5.Name = "Handle"
o5.Parent = o1
o5.Material = Enum.Material.WoodPlanks
o5.BrickColor = BrickColor.new("Reddish brown")
o5.Position = Vector3.new(6.00351143, -7.5999999, -7.49999571)
o5.Rotation = Vector3.new(0, 1, 0)
o5.Size = Vector3.new(0.400000006, 4.80000019, 0.200000003)
o5.CFrame = CFrame.new(6.00351143, -7.5999999, -7.49999571, 0.99984777, 0, 0.0174509957, 0, 1, 0, -0.0174509957, 0, 0.99984777)
o5.Color = Color3.new(0.411765, 0.25098, 0.156863)
o5.Position = Vector3.new(6.00351143, -7.5999999, -7.49999571)
o6.Name = "Part-to-Part Strong Joint"
o6.Parent = o5
o6.C0 = CFrame.new(0.200000003, -2.4000001, -0.100000001, -1, 0, 0, 0, 1, 0, 0, 0, -1)
o6.C1 = CFrame.new(0.199996948, -3.5, 0.100006104, -1, 0, 0, 0, 1, 0, 0, 0, -1)
o6.Part0 = o5
o6.Part1 = o2
o7.Name = "Part Terrain Joint"
o7.Parent = o5
o7.Part1 = o5
o9.Name = "SignStyles"
o9.Parent = o1
o10.Name = "MainScript"
o10.Parent = o1
table.insert(cors,coroutine.create(function()
wait()
runDummyScript(function()
function OnEquipped()
gui = o1.SignGui:Clone()
gui.Parent = game.Players.LocalPlayer.PlayerGui
while true do
wait()
o1.Sign.SurfaceGui.TextLabel.Text = gui.Frame.TextBox.Text
wait()  
end
end
 
function OnUnequipped()
gui:Remove()
end
 
o1.Equipped:connect(OnEquipped)
o1.Unequipped:connect(OnUnequipped)
end,o10)
end))
o11.Name = "SignGui"
o11.Parent = o1
o12.Parent = o11
o12.Position = UDim2.new(0.37999999523163,0,0.34999999403954,0)
o12.Size = UDim2.new(0.25,0,0.25,0)
o12.Position = UDim2.new(0.37999999523163,0,0.34999999403954,0)
o12.Active = true
o12.BackgroundColor3 = Color3.new(0.705882, 0.705882, 0.705882)
o12.BackgroundTransparency = 0.5
o12.Draggable = true
o13.Parent = o12
o13.Size = UDim2.new(1,0,0.10000000149012,0)
o13.Text = "Text"
o13.BackgroundColor3 = Color3.new(0, 0, 0)
o13.Font = Enum.Font.SourceSans
o13.FontSize = Enum.FontSize.Size14
o13.TextColor3 = Color3.new(1, 1, 1)
o14.Parent = o12
o14.Position = UDim2.new(0,0,0.10000000149012,0)
o14.Size = UDim2.new(1,0,0.89999997615814,0)
o14.Text = "Insert Text Here"
o14.Position = UDim2.new(0,0,0.10000000149012,0)
o14.BackgroundColor3 = Color3.new(1, 1, 1)
o14.BackgroundTransparency = 1
o14.Font = Enum.Font.SourceSans
o14.FontSize = Enum.FontSize.Size14
o14.TextScaled = true
o14.TextWrapped = true
mas.Parent = workspace
mas:MakeJoints()
local mas1 = mas:GetChildren()
for i=1,#mas1 do
    mas1[i].Parent = workspace 
    ypcall(function() mas1[i]:MakeJoints() end)
end
mas:Destroy()
for i=1,#cors do
coroutine.resume(cors[i])
end