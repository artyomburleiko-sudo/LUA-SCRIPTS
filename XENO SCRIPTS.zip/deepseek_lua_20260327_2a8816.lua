local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local backpack = player.Backpack
local umbrellaTool = nil
local umbrellaHandle = nil
local isUmbrellaOpen = false
local protectionZone = nil

local function createUmbrellaTool()
    if umbrellaTool and umbrellaTool.Parent then
        umbrellaTool:Destroy()
    end
    
    umbrellaTool = Instance.new("Tool")
    umbrellaTool.Name = "Вечный зонт"
    umbrellaTool.RequiresHandle = true
    umbrellaTool.CanBeDropped = false
    
    local handle = Instance.new("Part")
    handle.Name = "Handle"
    handle.Size = Vector3.new(0.8, 0.8, 1.2)
    handle.Shape = Enum.PartType.Cylinder
    handle.BrickColor = BrickColor.new("Dark red")
    handle.Material = Enum.Material.SmoothPlastic
    handle.Anchored = false
    handle.CanCollide = false
    
    local umbrellaTop = Instance.new("Part")
    umbrellaTop.Name = "UmbrellaTop"
    umbrellaTop.Size = Vector3.new(3.5, 0.1, 3.5)
    umbrellaTop.Shape = Enum.PartType.Cylinder
    umbrellaTop.BrickColor = BrickColor.new("Bright red")
    umbrellaTop.Material = Enum.Material.DiamondPlate
    umbrellaTop.Anchored = false
    umbrellaTop.CanCollide = true
    umbrellaTop.Transparency = 0.5
    
    umbrellaTop.CustomPhysicalProperties = PhysicalProperties.new(1000, 0, 0, 999999, 999999)
    
    local topMesh = Instance.new("CylinderMesh")
    topMesh.Parent = umbrellaTop
    
    local weld = Instance.new("Weld")
    weld.Part0 = handle
    weld.Part1 = umbrellaTop
    weld.C0 = CFrame.new(0, 2, 0)
    weld.Parent = umbrellaTop
    
    handle.Parent = umbrellaTool
    umbrellaTop.Parent = umbrellaTool
    
    umbrellaTool.Parent = backpack
    
    return umbrellaTool
end

local function createProtectionZone()
    if protectionZone then
        protectionZone:Destroy()
    end
    
    protectionZone = Instance.new("Model")
    protectionZone.Name = "UmbrellaProtection"
    protectionZone.Parent = character
    
    local topShield = Instance.new("Part")
    topShield.Name = "TopShield"
    topShield.Size = Vector3.new(6, 0.05, 6)
    topShield.Shape = Enum.PartType.Cylinder
    topShield.BrickColor = BrickColor.new("Bright red")
    topShield.Material = Enum.Material.Neon
    topShield.Anchored = false
    topShield.CanCollide = false
    topShield.Transparency = 0.7
    
    local bodyShield = Instance.new("Part")
    bodyShield.Name = "BodyShield"
    bodyShield.Size = Vector3.new(4, 5, 4)
    bodyShield.Shape = Enum.PartType.Cylinder
    bodyShield.BrickColor = BrickColor.new("Bright red")
    bodyShield.Material = Enum.Material.Neon
    bodyShield.Anchored = false
    bodyShield.CanCollide = false
    bodyShield.Transparency = 0.7
    
    local bottomShield = Instance.new("Part")
    bottomShield.Name = "BottomShield"
    bottomShield.Size = Vector3.new(3, 0.05, 3)
    bottomShield.Shape = Enum.PartType.Cylinder
    bottomShield.BrickColor = BrickColor.new("Bright red")
    bottomShield.Material = Enum.Material.Neon
    bottomShield.Anchored = false
    bottomShield.CanCollide = false
    bottomShield.Transparency = 0.7
    
    local torso = character:FindFirstChild("Torso") or character:FindFirstChild("UpperTorso")
    local humanoidRootPart = character:FindFirstChild("HumanoidRootPart")
    
    local weldTop = Instance.new("Weld")
    weldTop.Part0 = torso or humanoidRootPart
    weldTop.Part1 = topShield
    weldTop.C0 = CFrame.new(0, 2.5, 0)
    weldTop.Parent = topShield
    
    local weldBody = Instance.new("Weld")
    weldBody.Part0 = torso or humanoidRootPart
    weldBody.Part1 = bodyShield
    weldBody.C0 = CFrame.new(0, 0, 0)
    weldBody.Parent = bodyShield
    
    local weldBottom = Instance.new("Weld")
    weldBottom.Part0 = torso or humanoidRootPart
    weldBottom.Part1 = bottomShield
    weldBottom.C0 = CFrame.new(0, -2, 0)
    weldBottom.Parent = bottomShield
    
    topShield.Parent = protectionZone
    bodyShield.Parent = protectionZone
    bottomShield.Parent = protectionZone
    
    return protectionZone
end

local function createActiveUmbrella()
    if umbrellaHandle then
        umbrellaHandle:Destroy()
    end
    
    umbrellaHandle = Instance.new("Model")
    umbrellaHandle.Name = "ActiveUmbrella"
    umbrellaHandle.Parent = character
    
    local handlePart = Instance.new("Part")
    handlePart.Name = "Handle"
    handlePart.Size = Vector3.new(0.8, 0.8, 1.2)
    handlePart.Shape = Enum.PartType.Cylinder
    handlePart.BrickColor = BrickColor.new("Dark red")
    handlePart.Material = Enum.Material.SmoothPlastic
    handlePart.Anchored = false
    handlePart.CanCollide = false
    
    local umbrellaTop = Instance.new("Part")
    umbrellaTop.Name = "UmbrellaTop"
    umbrellaTop.Size = Vector3.new(3.5, 0.1, 3.5)
    umbrellaTop.Shape = Enum.PartType.Cylinder
    umbrellaTop.BrickColor = BrickColor.new("Bright red")
    umbrellaTop.Material = Enum.Material.DiamondPlate
    umbrellaTop.Anchored = false
    umbrellaTop.CanCollide = true
    umbrellaTop.Transparency = 0.3
    
    umbrellaTop.CustomPhysicalProperties = PhysicalProperties.new(1000, 0, 0, 999999, 999999)
    
    local topMesh = Instance.new("CylinderMesh")
    topMesh.Parent = umbrellaTop
    
    local weld1 = Instance.new("Weld")
    weld1.Part0 = handlePart
    weld1.Part1 = umbrellaTop
    weld1.C0 = CFrame.new(0, 2, 0)
    weld1.Parent = umbrellaTop
    
    local armWeld = Instance.new("Weld")
    local rightArm = character:FindFirstChild("Right Arm")
    local leftArm = character:FindFirstChild("Left Arm")
    local torso = character:FindFirstChild("Torso")
    
    if rightArm then
        armWeld.Part0 = rightArm
    elseif leftArm then
        armWeld.Part0 = leftArm
    else
        armWeld.Part0 = torso
    end
    
    armWeld.Part1 = handlePart
    armWeld.C0 = CFrame.new(0, -1, -0.5)
    armWeld.Parent = handlePart
    
    handlePart.Parent = umbrellaHandle
    umbrellaTop.Parent = umbrellaHandle
    
    return umbrellaHandle
end

local function openUmbrella()
    if not isUmbrellaOpen then
        if umbrellaHandle then
            umbrellaHandle:Destroy()
        end
        if protectionZone then
            protectionZone:Destroy()
        end
        createActiveUmbrella()
        createProtectionZone()
        isUmbrellaOpen = true
    end
end

local function closeUmbrella()
    if isUmbrellaOpen then
        if umbrellaHandle then
            umbrellaHandle:Destroy()
            umbrellaHandle = nil
        end
        if protectionZone then
            protectionZone:Destroy()
            protectionZone = nil
        end
        isUmbrellaOpen = false
    end
end

local function absoluteProtection()
    while true do
        wait(0.1)
        
        if not character or not character.Parent then
            character = player.Character or player.CharacterAdded:Wait()
        end
        
        if umbrellaHandle and umbrellaHandle.Parent then
            local topPart = umbrellaHandle:FindFirstChild("UmbrellaTop")
            if topPart then
                pcall(function()
                    if topPart.CustomPhysicalProperties.Density < 900 then
                        topPart.CustomPhysicalProperties = PhysicalProperties.new(1000, 0, 0, 999999, 999999)
                    end
                    
                    if topPart.Material ~= Enum.Material.DiamondPlate then
                        topPart.Material = Enum.Material.DiamondPlate
                    end
                    
                    topPart.BreakJointsOnDeath = false
                end)
            end
        end
        
        if protectionZone and protectionZone.Parent then
            for _, shield in pairs(protectionZone:GetChildren()) do
                if shield:IsA("Part") then
                    pcall(function()
                        shield.Transparency = 0.7
                        shield.CanCollide = false
                    end)
                end
            end
        end
        
        if isUmbrellaOpen then
            if (not umbrellaHandle or not umbrellaHandle.Parent) then
                createActiveUmbrella()
            end
            if (not protectionZone or not protectionZone.Parent) then
                createProtectionZone()
            end
        end
    end
end

local function setupTool()
    umbrellaTool = createUmbrellaTool()
    
    umbrellaTool.Equipped:Connect(function()
        openUmbrella()
    end)
    
    umbrellaTool.Unequipped:Connect(function()
        closeUmbrella()
    end)
end

spawn(absoluteProtection)

player.CharacterAdded:Connect(function(newChar)
    character = newChar
    wait(1)
    if umbrellaTool and umbrellaTool.Parent ~= backpack then
        umbrellaTool.Parent = backpack
    else
        setupTool()
    end
end)

if character then
    wait(1)
    setupTool()
end

local UserInputService = game:GetService("UserInputService")
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end
    
    if input.KeyCode == Enum.KeyCode.U then
        if umbrellaTool then
            if isUmbrellaOpen then
                closeUmbrella()
            else
                openUmbrella()
            end
        end
    end
end)