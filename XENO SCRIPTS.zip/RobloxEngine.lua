(function()
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local UserInputService = game:GetService("UserInputService")
    local RunService = game:GetService("RunService")
    local HttpService = game:GetService("HttpService")

    local colors = {
        bg = Color3.fromRGB(240, 240, 240),
        panel = Color3.fromRGB(245, 245, 245),
        border = Color3.fromRGB(0, 0, 0),
        text = Color3.fromRGB(0, 0, 0),
        textDim = Color3.fromRGB(80, 80, 80),
        highlight = Color3.fromRGB(210, 210, 210),
        title = Color3.fromRGB(220, 220, 220),
        button = Color3.fromRGB(235, 235, 235),
        success = Color3.fromRGB(100, 150, 100),
        warning = Color3.fromRGB(200, 150, 50),
        selected = Color3.fromRGB(180, 180, 255),
        error = Color3.fromRGB(200, 100, 100),
        explorer = Color3.fromRGB(250, 250, 250),
        scriptBg = Color3.fromRGB(30, 30, 35)
    }

    local objectTree = {}
    local selectedObject = nil
    local clipboard = nil
    local expandedNodes = {}
    local allObjectsList = {}
    
    local function buildFullTree()
        objectTree = {}
        allObjectsList = {}
        local function scan(obj, parent, depth)
            if depth > 15 then return end
            local node = {
                obj = obj,
                name = obj.Name,
                class = obj.ClassName,
                children = {},
                parent = parent,
                expanded = expandedNodes[obj] or false,
                path = ""
            }
            local pathParts = {}
            local current = obj
            while current do
                table.insert(pathParts, 1, current.Name)
                current = current.Parent
            end
            node.path = table.concat(pathParts, "/")
            table.insert(allObjectsList, node)
            
            if parent then
                table.insert(parent.children, node)
            else
                table.insert(objectTree, node)
            end
            
            for _, child in ipairs(obj:GetChildren()) do
                scan(child, node, (depth or 0) + 1)
            end
        end
        for _, obj in ipairs(game:GetChildren()) do
            scan(obj, nil, 0)
        end
        return #allObjectsList
    end
    
    local function searchObjects(searchTerm, searchType)
        local results = {}
        local searchLower = searchTerm:lower()
        
        for _, node in ipairs(allObjectsList) do
            if searchType == "Name" and node.name:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Class" and node.class:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Path" and node.path:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Both" then
                if node.name:lower():find(searchLower, 1, true) or node.class:lower():find(searchLower, 1, true) then
                    table.insert(results, node)
                end
            end
        end
        
        return results
    end
    
    local function exportToJSON()
        local exportData = {
            gameName = game.Name,
            placeId = game.PlaceId,
            timestamp = os.date("%Y-%m-%d %H:%M:%S"),
            objects = {}
        }
        
        for _, node in ipairs(allObjectsList) do
            local objData = {
                name = node.name,
                className = node.class,
                path = node.path,
                properties = {}
            }
            
            pcall(function()
                objData.properties.Archivable = node.obj.Archivable
            end)
            if node.obj:IsA("BasePart") then
                pcall(function()
                    objData.properties.Position = {node.obj.Position.X, node.obj.Position.Y, node.obj.Position.Z}
                    objData.properties.Size = {node.obj.Size.X, node.obj.Size.Y, node.obj.Size.Z}
                end)
            end
            if node.obj:IsA("NumberValue") or node.obj:IsA("IntValue") then
                pcall(function()
                    objData.properties.Value = node.obj.Value
                end)
            elseif node.obj:IsA("StringValue") then
                pcall(function()
                    objData.properties.Value = node.obj.Value
                end)
            end
            
            table.insert(exportData.objects, objData)
        end
        
        local json = HttpService:JSONEncode(exportData)
        setclipboard(json)
        return json
    end
    
    local scriptWindow = nil
    local scriptFrame = nil
    local scriptEditor = nil
    local currentScript = nil
    
    local function createScriptEditor()
        scriptWindow = Instance.new("Frame")
        scriptWindow.Parent = ScreenGui
        scriptWindow.BackgroundColor3 = colors.scriptBg
        scriptWindow.BorderColor3 = colors.border
        scriptWindow.BorderSizePixel = 2
        scriptWindow.Position = UDim2.new(0, 200, 0, 100)
        scriptWindow.Size = UDim2.new(0, 600, 0, 400)
        scriptWindow.Visible = false
        scriptWindow.Active = true
        scriptWindow.Draggable = true
        
        local titleBar = Instance.new("Frame")
        titleBar.Parent = scriptWindow
        titleBar.BackgroundColor3 = colors.title
        titleBar.BorderColor3 = colors.border
        titleBar.BorderSizePixel = 1
        titleBar.Size = UDim2.new(1, 0, 0, 28)
        
        local titleText = Instance.new("TextLabel")
        titleText.Parent = titleBar
        titleText.BackgroundTransparency = 1
        titleText.Position = UDim2.new(0, 8, 0, 0)
        titleText.Size = UDim2.new(0, 200, 1, 0)
        titleText.Text = "Script Viewer"
        titleText.TextColor3 = colors.text
        titleText.TextSize = 12
        titleText.TextXAlignment = Enum.TextXAlignment.Left
        
        local closeScript = Instance.new("TextButton")
        closeScript.Parent = titleBar
        closeScript.BackgroundColor3 = colors.title
        closeScript.BorderColor3 = colors.border
        closeScript.BorderSizePixel = 1
        closeScript.Position = UDim2.new(1, -28, 0, 0)
        closeScript.Size = UDim2.new(0, 27, 1, 0)
        closeScript.Text = "X"
        closeScript.TextColor3 = colors.text
        closeScript.TextSize = 12
        closeScript.MouseButton1Click:Connect(function()
            scriptWindow.Visible = false
        end)
        
        local editorFrame = Instance.new("Frame")
        editorFrame.Parent = scriptWindow
        editorFrame.BackgroundColor3 = colors.bg
        editorFrame.BorderColor3 = colors.border
        editorFrame.BorderSizePixel = 1
        editorFrame.Position = UDim2.new(0, 5, 0, 33)
        editorFrame.Size = UDim2.new(1, -10, 1, -68)
        
        scriptEditor = Instance.new("TextBox")
        scriptEditor.Parent = editorFrame
        scriptEditor.BackgroundColor3 = colors.bg
        scriptEditor.BorderColor3 = colors.border
        scriptEditor.BorderSizePixel = 1
        scriptEditor.Size = UDim2.new(1, -10, 1, -10)
        scriptEditor.Position = UDim2.new(0, 5, 0, 5)
        scriptEditor.Text = ""
        scriptEditor.TextColor3 = colors.text
        scriptEditor.TextSize = 11
        scriptEditor.Font = Enum.Font.SourceSans
        scriptEditor.MultiLine = true
        scriptEditor.TextXAlignment = Enum.TextXAlignment.Left
        scriptEditor.TextYAlignment = Enum.TextYAlignment.Top
        scriptEditor.ClearTextOnFocus = false
        
        local saveBtn = Instance.new("TextButton")
        saveBtn.Parent = scriptWindow
        saveBtn.BackgroundColor3 = colors.button
        saveBtn.BorderColor3 = colors.border
        saveBtn.BorderSizePixel = 1
        saveBtn.Position = UDim2.new(1, -85, 1, -30)
        saveBtn.Size = UDim2.new(0, 80, 0, 26)
        saveBtn.Text = "SAVE"
        saveBtn.TextColor3 = colors.text
        saveBtn.TextSize = 11
        
        local executeBtn = Instance.new("TextButton")
        executeBtn.Parent = scriptWindow
        executeBtn.BackgroundColor3 = colors.button
        executeBtn.BorderColor3 = colors.border
        executeBtn.BorderSizePixel = 1
        executeBtn.Position = UDim2.new(1, -170, 1, -30)
        executeBtn.Size = UDim2.new(0, 80, 0, 26)
        executeBtn.Text = "EXECUTE"
        executeBtn.TextColor3 = colors.text
        executeBtn.TextSize = 11
        
        saveBtn.MouseButton1Click:Connect(function()
            if currentScript and scriptEditor.Text then
                pcall(function()
                    if currentScript:IsA("LocalScript") or currentScript:IsA("ModuleScript") or currentScript:IsA("Script") then
                        currentScript.Source = scriptEditor.Text
                        updateStatus("Script saved: " .. currentScript.Name)
                    end
                end)
            end
        end)
        
        executeBtn.MouseButton1Click:Connect(function()
            local success, err = pcall(loadstring, scriptEditor.Text)
            if success then
                pcall(success)
                updateStatus("Script executed")
            else
                updateStatus("Error: " .. tostring(err), true)
            end
        end)
        
        return scriptWindow
    end
    
    local function viewScript(obj)
        if not scriptWindow then
            createScriptEditor()
        end
        
        if obj:IsA("LocalScript") or obj:IsA("ModuleScript") or obj:IsA("Script") then
            currentScript = obj
            local source = ""
            pcall(function()
                source = obj.Source
            end)
            scriptEditor.Text = source or "-- Unable to read script source"
            scriptWindow.Visible = true
            scriptWindow.Position = UDim2.new(0, 200, 0, 100)
            scriptWindow.Title.Text = "Script: " .. obj.Name
            updateStatus("Viewing script: " .. obj.Name)
        else
            updateStatus("Not a script: " .. obj.ClassName, true)
        end
    end
    
    local ScreenGui = Instance.new("ScreenGui")
    ScreenGui.Name = "RobloxEngine"
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")
    ScreenGui.ResetOnSpawn = false
    
    local MainFrame = Instance.new("Frame")
    MainFrame.Parent = ScreenGui
    MainFrame.BackgroundColor3 = colors.bg
    MainFrame.BorderColor3 = colors.border
    MainFrame.BorderSizePixel = 2
    MainFrame.Position = UDim2.new(0, 100, 0, 50)
    MainFrame.Size = UDim2.new(0, 1000, 0, 650)
    MainFrame.Active = true
    MainFrame.Draggable = true
    
    local TitleBar = Instance.new("Frame")
    TitleBar.Parent = MainFrame
    TitleBar.BackgroundColor3 = colors.title
    TitleBar.BorderColor3 = colors.border
    TitleBar.BorderSizePixel = 1
    TitleBar.Size = UDim2.new(1, 0, 0, 28)
    
    local TitleText = Instance.new("TextLabel")
    TitleText.Parent = TitleBar
    TitleText.BackgroundTransparency = 1
    TitleText.Position = UDim2.new(0, 8, 0, 0)
    TitleText.Size = UDim2.new(0, 200, 1, 0)
    TitleText.Text = "Roblox Engine 2.0"
    TitleText.TextColor3 = colors.text
    TitleText.TextSize = 12
    TitleText.TextXAlignment = Enum.TextXAlignment.Left
    TitleText.Font = Enum.Font.SourceSansBold
    
    local CloseBtn = Instance.new("TextButton")
    CloseBtn.Parent = TitleBar
    CloseBtn.BackgroundColor3 = colors.title
    CloseBtn.BorderColor3 = colors.border
    CloseBtn.BorderSizePixel = 1
    CloseBtn.Position = UDim2.new(1, -28, 0, 0)
    CloseBtn.Size = UDim2.new(0, 27, 1, 0)
    CloseBtn.Text = "X"
    CloseBtn.TextColor3 = colors.text
    CloseBtn.TextSize = 12
    CloseBtn.MouseButton1Click:Connect(function()
        ScreenGui:Destroy()
    end)
    
    local MinBtn = Instance.new("TextButton")
    MinBtn.Parent = TitleBar
    MinBtn.BackgroundColor3 = colors.title
    MinBtn.BorderColor3 = colors.border
    MinBtn.BorderSizePixel = 1
    MinBtn.Position = UDim2.new(1, -56, 0, 0)
    MinBtn.Size = UDim2.new(0, 27, 1, 0)
    MinBtn.Text = "_"
    MinBtn.TextColor3 = colors.text
    MinBtn.TextSize = 12
    local minimized = false
    local originalSize = MainFrame.Size
    MinBtn.MouseButton1Click:Connect(function()
        minimized = not minimized
        if minimized then
            MainFrame.Size = UDim2.new(0, 1000, 0, 28)
        else
            MainFrame.Size = originalSize
        end
    end)
    
    local ToolBar = Instance.new("Frame")
    ToolBar.Parent = MainFrame
    ToolBar.BackgroundColor3 = colors.panel
    ToolBar.BorderColor3 = colors.border
    ToolBar.BorderSizePixel = 1
    ToolBar.Position = UDim2.new(0, 0, 0, 28)
    ToolBar.Size = UDim2.new(1, 0, 0, 36)
    
    local SearchLabel = Instance.new("TextLabel")
    SearchLabel.Parent = ToolBar
    SearchLabel.BackgroundTransparency = 1
    SearchLabel.Position = UDim2.new(0, 8, 0, 10)
    SearchLabel.Size = UDim2.new(0, 45, 0, 18)
    SearchLabel.Text = "Search:"
    SearchLabel.TextColor3 = colors.text
    SearchLabel.TextSize = 11
    
    local SearchBox = Instance.new("TextBox")
    SearchBox.Parent = ToolBar
    SearchBox.BackgroundColor3 = colors.bg
    SearchBox.BorderColor3 = colors.border
    SearchBox.BorderSizePixel = 1
    SearchBox.Position = UDim2.new(0, 55, 0, 7)
    SearchBox.Size = UDim2.new(0, 150, 0, 24)
    SearchBox.Text = ""
    SearchBox.TextColor3 = colors.text
    SearchBox.TextSize = 11
    SearchBox.PlaceholderText = "Object name, class or path..."
    
    local SearchTypeBox = Instance.new("TextBox")
    SearchTypeBox.Parent = ToolBar
    SearchTypeBox.BackgroundColor3 = colors.bg
    SearchTypeBox.BorderColor3 = colors.border
    SearchTypeBox.BorderSizePixel = 1
    SearchTypeBox.Position = UDim2.new(0, 215, 0, 7)
    SearchTypeBox.Size = UDim2.new(0, 70, 0, 24)
    SearchTypeBox.Text = "Both"
    SearchTypeBox.TextColor3 = colors.text
    SearchTypeBox.TextSize = 11
    
    local ScanBtn = Instance.new("TextButton")
    ScanBtn.Parent = ToolBar
    ScanBtn.BackgroundColor3 = colors.button
    ScanBtn.BorderColor3 = colors.border
    ScanBtn.BorderSizePixel = 1
    ScanBtn.Position = UDim2.new(0, 295, 0, 7)
    ScanBtn.Size = UDim2.new(0, 80, 0, 24)
    ScanBtn.Text = "SCAN"
    ScanBtn.TextColor3 = colors.text
    ScanBtn.TextSize = 11
    
    local ScanAllBtn = Instance.new("TextButton")
    ScanAllBtn.Parent = ToolBar
    ScanAllBtn.BackgroundColor3 = colors.success
    ScanAllBtn.BorderColor3 = colors.border
    ScanAllBtn.BorderSizePixel = 1
    ScanAllBtn.Position = UDim2.new(0, 385, 0, 7)
    ScanAllBtn.Size = UDim2.new(0, 100, 0, 24)
    ScanAllBtn.Text = "SCAN ALL"
    ScanAllBtn.TextColor3 = colors.text
    ScanAllBtn.TextSize = 11
    
    local ExportBtn = Instance.new("TextButton")
    ExportBtn.Parent = ToolBar
    ExportBtn.BackgroundColor3 = colors.button
    ExportBtn.BorderColor3 = colors.border
    ExportBtn.BorderSizePixel = 1
    ExportBtn.Position = UDim2.new(0, 495, 0, 7)
    ExportBtn.Size = UDim2.new(0, 80, 0, 24)
    ExportBtn.Text = "EXPORT JSON"
    ExportBtn.TextColor3 = colors.text
    ExportBtn.TextSize = 11
    
    local RefreshBtn = Instance.new("TextButton")
    RefreshBtn.Parent = ToolBar
    RefreshBtn.BackgroundColor3 = colors.button
    RefreshBtn.BorderColor3 = colors.border
    RefreshBtn.BorderSizePixel = 1
    RefreshBtn.Position = UDim2.new(0, 585, 0, 7)
    RefreshBtn.Size = UDim2.new(0, 70, 0, 24)
    RefreshBtn.Text = "REFRESH"
    RefreshBtn.TextColor3 = colors.text
    RefreshBtn.TextSize = 11
    
    local ObjectCountLabel = Instance.new("TextLabel")
    ObjectCountLabel.Parent = ToolBar
    ObjectCountLabel.BackgroundTransparency = 1
    ObjectCountLabel.Position = UDim2.new(1, -150, 0, 10)
    ObjectCountLabel.Size = UDim2.new(0, 140, 0, 18)
    ObjectCountLabel.Text = "Objects: 0"
    ObjectCountLabel.TextColor3 = colors.textDim
    ObjectCountLabel.TextSize = 10
    ObjectCountLabel.TextXAlignment = Enum.TextXAlignment.Right
    
    local Splitter = Instance.new("Frame")
    Splitter.Parent = MainFrame
    Splitter.BackgroundColor3 = colors.border
    Splitter.BorderSizePixel = 0
    Splitter.Position = UDim2.new(0, 320, 0, 64)
    Splitter.Size = UDim2.new(0, 1, 1, -70)
    
    local LeftPanel = Instance.new("Frame")
    LeftPanel.Parent = MainFrame
    LeftPanel.BackgroundColor3 = colors.explorer
    LeftPanel.BorderColor3 = colors.border
    LeftPanel.BorderSizePixel = 1
    LeftPanel.Position = UDim2.new(0, 5, 0, 66)
    LeftPanel.Size = UDim2.new(0, 310, 1, -80)
    
    local ExplorerTitle = Instance.new("TextLabel")
    ExplorerTitle.Parent = LeftPanel
    ExplorerTitle.BackgroundTransparency = 1
    ExplorerTitle.Position = UDim2.new(0, 5, 0, 5)
    ExplorerTitle.Size = UDim2.new(1, -10, 0, 20)
    ExplorerTitle.Text = "▸ Object Explorer"
    ExplorerTitle.TextColor3 = colors.text
    ExplorerTitle.TextSize = 11
    ExplorerTitle.TextXAlignment = Enum.TextXAlignment.Left
    ExplorerTitle.Font = Enum.Font.SourceSansBold
    
    local ExplorerList = Instance.new("ScrollingFrame")
    ExplorerList.Parent = LeftPanel
    ExplorerList.BackgroundColor3 = colors.bg
    ExplorerList.BorderColor3 = colors.border
    ExplorerList.BorderSizePixel = 1
    ExplorerList.Position = UDim2.new(0, 5, 0, 28)
    ExplorerList.Size = UDim2.new(1, -10, 1, -38)
    ExplorerList.CanvasSize = UDim2.new(0, 0, 0, 0)
    ExplorerList.ScrollBarThickness = 10
    
    local RightPanel = Instance.new("Frame")
    RightPanel.Parent = MainFrame
    RightPanel.BackgroundColor3 = colors.panel
    RightPanel.BorderColor3 = colors.border
    RightPanel.BorderSizePixel = 1
    RightPanel.Position = UDim2.new(0, 330, 0, 66)
    RightPanel.Size = UDim2.new(1, -340, 1, -80)
    
    local ResultsTitle = Instance.new("TextLabel")
    ResultsTitle.Parent = RightPanel
    ResultsTitle.BackgroundTransparency = 1
    ResultsTitle.Position = UDim2.new(0, 5, 0, 5)
    ResultsTitle.Size = UDim2.new(1, -10, 0, 20)
    ResultsTitle.Text = "▸ Search Results"
    ResultsTitle.TextColor3 = colors.text
    ResultsTitle.TextSize = 11
    ResultsTitle.TextXAlignment = Enum.TextXAlignment.Left
    ResultsTitle.Font = Enum.Font.SourceSansBold
    
    local ResultsList = Instance.new("ScrollingFrame")
    ResultsList.Parent = RightPanel
    ResultsList.BackgroundColor3 = colors.bg
    ResultsList.BorderColor3 = colors.border
    ResultsList.BorderSizePixel = 1
    ResultsList.Position = UDim2.new(0, 5, 0, 28)
    ResultsList.Size = UDim2.new(1, -10, 0.5, -35)
    ResultsList.CanvasSize = UDim2.new(0, 0, 0, 0)
    ResultsList.ScrollBarThickness = 10
    
    local PropsTitle = Instance.new("TextLabel")
    PropsTitle.Parent = RightPanel
    PropsTitle.BackgroundTransparency = 1
    PropsTitle.Position = UDim2.new(0, 5, 0, 0.5, 5)
    PropsTitle.Size = UDim2.new(1, -10, 0, 20)
    PropsTitle.Text = "▸ Object Properties"
    PropsTitle.TextColor3 = colors.text
    PropsTitle.TextSize = 11
    PropsTitle.TextXAlignment = Enum.TextXAlignment.Left
    PropsTitle.Font = Enum.Font.SourceSansBold
    
    local PropsList = Instance.new("ScrollingFrame")
    PropsList.Parent = RightPanel
    PropsList.BackgroundColor3 = colors.bg
    PropsList.BorderColor3 = colors.border
    PropsList.BorderSizePixel = 1
    PropsList.Position = UDim2.new(0, 5, 0, 0.5, 28)
    PropsList.Size = UDim2.new(1, -10, 0.45, -38)
    PropsList.CanvasSize = UDim2.new(0, 0, 0, 0)
    PropsList.ScrollBarThickness = 10
    
    local ActionBar = Instance.new("Frame")
    ActionBar.Parent = MainFrame
    ActionBar.BackgroundColor3 = colors.title
    ActionBar.BorderColor3 = colors.border
    ActionBar.BorderSizePixel = 1
    ActionBar.Position = UDim2.new(0, 0, 1, -42)
    ActionBar.Size = UDim2.new(1, 0, 0, 42)
    
    local CopyBtn = Instance.new("TextButton")
    CopyBtn.Parent = ActionBar
    CopyBtn.BackgroundColor3 = colors.button
    CopyBtn.BorderColor3 = colors.border
    CopyBtn.BorderSizePixel = 1
    CopyBtn.Position = UDim2.new(0, 5, 0, 6)
    CopyBtn.Size = UDim2.new(0, 70, 0, 30)
    CopyBtn.Text = "COPY"
    CopyBtn.TextColor3 = colors.text
    
    local PasteBtn = Instance.new("TextButton")
    PasteBtn.Parent = ActionBar
    PasteBtn.BackgroundColor3 = colors.button
    PasteBtn.BorderColor3 = colors.border
    PasteBtn.BorderSizePixel = 1
    PasteBtn.Position = UDim2.new(0, 80, 0, 6)
    PasteBtn.Size = UDim2.new(0, 70, 0, 30)
    PasteBtn.Text = "PASTE"
    PasteBtn.TextColor3 = colors.text
    
    local DeleteBtn = Instance.new("TextButton")
    DeleteBtn.Parent = ActionBar
    DeleteBtn.BackgroundColor3 = colors.button
    DeleteBtn.BorderColor3 = colors.border
    DeleteBtn.BorderSizePixel = 1
    DeleteBtn.Position = UDim2.new(0, 155, 0, 6)
    DeleteBtn.Size = UDim2.new(0, 70, 0, 30)
    DeleteBtn.Text = "DELETE"
    DeleteBtn.TextColor3 = colors.text
    
    local RenameBtn = Instance.new("TextButton")
    RenameBtn.Parent = ActionBar
    RenameBtn.BackgroundColor3 = colors.button
    RenameBtn.BorderColor3 = colors.border
    RenameBtn.BorderSizePixel = 1
    RenameBtn.Position = UDim2.new(0, 230, 0, 6)
    RenameBtn.Size = UDim2.new(0, 70, 0, 30)
    RenameBtn.Text = "RENAME"
    RenameBtn.TextColor3 = colors.text
    
    local ViewScriptBtn = Instance.new("TextButton")
    ViewScriptBtn.Parent = ActionBar
    ViewScriptBtn.BackgroundColor3 = colors.button
    ViewScriptBtn.BorderColor3 = colors.border
    ViewScriptBtn.BorderSizePixel = 1
    ViewScriptBtn.Position = UDim2.new(0, 305, 0, 6)
    ViewScriptBtn.Size = UDim2.new(0, 90, 0, 30)
    ViewScriptBtn.Text = "VIEW SCRIPT"
    ViewScriptBtn.TextColor3 = colors.text
    
    local ApplyPropBtn = Instance.new("TextButton")
    ApplyPropBtn.Parent = ActionBar
    ApplyPropBtn.BackgroundColor3 = colors.button
    ApplyPropBtn.BorderColor3 = colors.border
    ApplyPropBtn.BorderSizePixel = 1
    ApplyPropBtn.Position = UDim2.new(1, -160, 0, 6)
    ApplyPropBtn.Size = UDim2.new(0, 70, 0, 30)
    ApplyPropBtn.Text = "APPLY"
    ApplyPropBtn.TextColor3 = colors.text
    
    local MoveBtn = Instance.new("TextButton")
    MoveBtn.Parent = ActionBar
    MoveBtn.BackgroundColor3 = colors.button
    MoveBtn.BorderColor3 = colors.border
    MoveBtn.BorderSizePixel = 1
    MoveBtn.Position = UDim2.new(1, -85, 0, 6)
    MoveBtn.Size = UDim2.new(0, 70, 0, 30)
    MoveBtn.Text = "MOVE"
    MoveBtn.TextColor3 = colors.text
    
    local StatusBar = Instance.new("Frame")
    StatusBar.Parent = MainFrame
    StatusBar.BackgroundColor3 = colors.title
    StatusBar.BorderColor3 = colors.border
    StatusBar.BorderSizePixel = 1
    StatusBar.Position = UDim2.new(0, 0, 1, -26)
    StatusBar.Size = UDim2.new(1, 0, 0, 26)
    
    local StatusText = Instance.new("TextLabel")
    StatusText.Parent = StatusBar
    StatusText.BackgroundTransparency = 1
    StatusText.Position = UDim2.new(0, 8, 0, 4)
    StatusText.Size = UDim2.new(1, -16, 0, 18)
    StatusText.Text = "Ready | Click SCAN ALL to load object tree"
    StatusText.TextColor3 = colors.textDim
    StatusText.TextSize = 10
    
    local RenameBox = Instance.new("TextBox")
    RenameBox.Parent = MainFrame
    RenameBox.BackgroundColor3 = colors.bg
    RenameBox.BorderColor3 = colors.border
    RenameBox.BorderSizePixel = 1
    RenameBox.Size = UDim2.new(0, 200, 0, 24)
    RenameBox.Visible = false
    
    local MoveBox = Instance.new("TextBox")
    MoveBox.Parent = MainFrame
    MoveBox.BackgroundColor3 = colors.bg
    MoveBox.BorderColor3 = colors.border
    MoveBox.BorderSizePixel = 1
    MoveBox.Size = UDim2.new(0, 200, 0, 24)
    MoveBox.Visible = false
    MoveBox.PlaceholderText = "Target parent name..."
    
    local PropNameBox = Instance.new("TextBox")
    PropNameBox.Parent = MainFrame
    PropNameBox.BackgroundColor3 = colors.bg
    PropNameBox.BorderColor3 = colors.border
    PropNameBox.BorderSizePixel = 1
    PropNameBox.Size = UDim2.new(0, 150, 0, 24)
    PropNameBox.Visible = false
    PropNameBox.PlaceholderText = "Property name..."
    
    local PropValueBox = Instance.new("TextBox")
    PropValueBox.Parent = MainFrame
    PropValueBox.BackgroundColor3 = colors.bg
    PropValueBox.BorderColor3 = colors.border
    PropValueBox.BorderSizePixel = 1
    PropValueBox.Size = UDim2.new(0, 150, 0, 24)
    PropValueBox.Visible = false
    PropValueBox.PlaceholderText = "New value..."
    
    local function updateStatus(msg, isError)
        StatusText.Text = msg
        if isError then
            StatusText.TextColor3 = colors.error
        else
            StatusText.TextColor3 = colors.textDim
        end
        task.wait(2)
        StatusText.TextColor3 = colors.textDim
        StatusText.Text = "Ready | " .. (#allObjectsList > 0 and #allObjectsList .. " objects loaded" or "Click SCAN ALL to load objects")
    end
    
    local function renderExplorerTree()
        for _, child in ipairs(ExplorerList:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        
        local function renderNode(node, depth, yOffset)
            local btn = Instance.new("TextButton")
            btn.Parent = ExplorerList
            btn.BackgroundColor3 = colors.bg
            btn.BorderColor3 = colors.border
            btn.BorderSizePixel = 1
            btn.Size = UDim2.new(1, -5, 0, 22)
            btn.Position = UDim2.new(0, 2, 0, yOffset)
            local prefix = string.rep("  ", depth)
            if #node.children > 0 then
                prefix = prefix .. (node.expanded and "▼ " or "▶ ")
            else
                prefix = prefix .. "  "
            end
            btn.Text = prefix .. node.name .. " (" .. node.class .. ")"
            btn.TextColor3 = colors.text
            btn.TextSize = 10
            btn.TextXAlignment = Enum.TextXAlignment.Left
            
            btn.MouseButton1Click:Connect(function()
                selectedObject = node.obj
                node.expanded = not node.expanded
                expandedNodes[node.obj] = node.expanded
                renderExplorerTree()
                renderProperties(node.obj)
                updateStatus("Selected: " .. node.name)
            end)
            
            local newY = yOffset + 24
            
            if node.expanded then
                for _, child in ipairs(node.children) do
                    newY = renderNode(child, depth + 1, newY)
                end
            end
            
            return newY
        end
        
        local yPos = 0
        for _, root in ipairs(objectTree) do
            yPos = renderNode(root, 0, yPos)
        end
        
        ExplorerList.CanvasSize = UDim2.new(0, 0, 0, yPos + 10)
    end
    
    local function renderResults(results)
        for _, child in ipairs(ResultsList:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        
        local yOffset = 0
        for _, node in ipairs(results) do
            local btn = Instance.new("TextButton")
            btn.Parent = ResultsList
            btn.BackgroundColor3 = colors.bg
            btn.BorderColor3 = colors.border
            btn.BorderSizePixel = 1
            btn.Size = UDim2.new(1, -5, 0, 22)
            btn.Position = UDim2.new(0, 2, 0, yOffset)
            btn.Text = node.name .. " (" .. node.class .. ")"
            btn.TextColor3 = colors.text
            btn.TextSize = 10
            btn.TextXAlignment = Enum.TextXAlignment.Left
            
            btn.MouseButton1Click:Connect(function()
                selectedObject = node.obj
                renderProperties(node.obj)
                updateStatus("Selected: " .. node.name)
            end)
            
            yOffset = yOffset + 24
        end
        
        ResultsList.CanvasSize = UDim2.new(0, 0, 0, yOffset + 10)
    end
    
    local function renderProperties(obj)
        for _, child in ipairs(PropsList:GetChildren()) do
            if child:IsA("TextButton") then
                child:Destroy()
            end
        end
        
        if not obj then return end
        
        local yOffset = 0
        local props = {}
        
        table.insert(props, {"Name", obj.Name, "string"})
        table.insert(props, {"ClassName", obj.ClassName, "string"})
        table.insert(props, {"Parent", obj.Parent and obj.Parent.Name or "nil", "string"})
        table.insert(props, {"Archivable", tostring(obj.Archivable), "bool"})
        
        if obj:IsA("BasePart") then
            table.insert(props, {"Position", string.format("%.2f, %.2f, %.2f", obj.Position.X, obj.Position.Y, obj.Position.Z), "Vector3"})
            table.insert(props, {"Size", string.format("%.2f, %.2f, %.2f", obj.Size.X, obj.Size.Y, obj.Size.Z), "Vector3"})
            table.insert(props, {"Anchored", tostring(obj.Anchored), "bool"})
        end
        
        if obj:IsA("NumberValue") or obj:IsA("IntValue") then
            table.insert(props, {"Value", tostring(obj.Value), "number"})
        elseif obj:IsA("StringValue") then
            table.insert(props, {"Value", obj.Value, "string"})
        elseif obj:IsA("BoolValue") then
            table.insert(props, {"Value", tostring(obj.Value), "bool"})
        end
        
        if obj:IsA("LocalScript") or obj:IsA("ModuleScript") or obj:IsA("Script") then
            table.insert(props, {"Script", "[Click VIEW SCRIPT to see source]", "script"})
        end
        
        for _, prop in ipairs(props) do
            local nameBtn = Instance.new("TextButton")
            nameBtn.Parent = PropsList
            nameBtn.BackgroundColor3 = colors.bg
            nameBtn.BorderColor3 = colors.border
            nameBtn.BorderSizePixel = 1
            nameBtn.Size = UDim2.new(0.35, -3, 0, 20)
            nameBtn.Position = UDim2.new(0, 2, 0, yOffset)
            nameBtn.Text = prop[1] .. ":"
            nameBtn.TextColor3 = colors.textDim
            nameBtn.TextSize = 10
            nameBtn.TextXAlignment = Enum.TextXAlignment.Right
            
            local valBtn = Instance.new("TextButton")
            valBtn.Parent = PropsList
            valBtn.BackgroundColor3 = colors.bg
            valBtn.BorderColor3 = colors.border
            valBtn.BorderSizePixel = 1
            valBtn.Size = UDim2.new(0.65, -3, 0, 20)
            valBtn.Position = UDim2.new(0.35, 2, 0, yOffset)
            valBtn.Text = prop[2]
            valBtn.TextColor3 = colors.text
            valBtn.TextSize = 10
            valBtn.TextXAlignment = Enum.TextXAlignment.Left
            
            yOffset = yOffset + 22
        end
        
        PropsList.CanvasSize = UDim2.new(0, 0, 0, yOffset + 10)
    end
    
    local function refreshAll()
        updateStatus("Building object tree...")
        local count = buildFullTree()
        renderExplorerTree()
        ObjectCountLabel.Text = "Objects: " .. count
        updateStatus("Loaded " .. count .. " objects")
    end
    
    local function copyObject(obj)
        clipboard = obj:Clone()
        return true
    end
    
    local function pasteObject(parent)
        if clipboard then
            local newObj = clipboard:Clone()
            newObj.Parent = parent
            return newObj
        end
        return nil
    end
    
    local function applyToObject(obj, action, value)
        if not obj then return false end
        
        if action == "Rename" then
            pcall(function() obj.Name = value end)
            return true
        elseif action == "Move" then
            local target = workspace:FindFirstChild(value) or game:FindFirstChild(value)
            if target then
                pcall(function() obj.Parent = target end)
                return true
            end
        elseif action == "Delete" then
            pcall(function() obj:Destroy() end)
            return true
        elseif action == "Clone" then
            local clone = obj:Clone()
            clone.Parent = obj.Parent
            return true
        elseif action == "SetProperty" then
            local propName, propValue = value[1], value[2]
            pcall(function() obj[propName] = propValue end)
            return true
        end
        return false
    end
    
    ScanAllBtn.MouseButton1Click:Connect(function()
        refreshAll()
    end)
    
    ScanBtn.MouseButton1Click:Connect(function()
        local searchTerm = SearchBox.Text
        local searchType = SearchTypeBox.Text
        
        if searchTerm == "" then
            updateStatus("ERROR: Enter search term", true)
            return
        end
        
        if #allObjectsList == 0 then
            updateStatus("ERROR: Click SCAN ALL first", true)
            return
        end
        
        updateStatus("Scanning for: " .. searchTerm)
        local results = searchObjects(searchTerm, searchType)
        renderResults(results)
        updateStatus("Found " .. #results .. " objects")
    end)
    
    ExportBtn.MouseButton1Click:Connect(function()
        if #allObjectsList == 0 then
            updateStatus("ERROR: Click SCAN ALL first", true)
            return
        end
        local json = exportToJSON()
        updateStatus("Exported " .. #allObjectsList .. " objects to clipboard")
    end)
    
    RefreshBtn.MouseButton1Click:Connect(function()
        refreshAll()
    end)
    
    CopyBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            copyObject(selectedObject)
            updateStatus("Copied: " .. selectedObject.Name)
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    PasteBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            local newObj = pasteObject(selectedObject)
            if newObj then
                refreshAll()
                updateStatus("Pasted as: " .. newObj.Name)
            else
                updateStatus("ERROR: Nothing to paste", true)
            end
        else
            updateStatus("ERROR: Select target parent", true)
        end
    end)
    
    DeleteBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            local name = selectedObject.Name
            if applyToObject(selectedObject, "Delete") then
                selectedObject = nil
                refreshAll()
                updateStatus("Deleted: " .. name)
            end
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    RenameBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            RenameBox.Text = selectedObject.Name
            RenameBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 400, 0, MainFrame.AbsolutePosition.Y + 300)
            RenameBox.Visible = true
            RenameBox:CaptureFocus()
            
            local focusConnection
            focusConnection = RenameBox.FocusLost:Connect(function()
                if RenameBox.Text ~= "" and RenameBox.Text ~= selectedObject.Name then
                    applyToObject(selectedObject, "Rename", RenameBox.Text)
                    refreshAll()
                    updateStatus("Renamed to: " .. RenameBox.Text)
                end
                RenameBox.Visible = false
                focusConnection:Disconnect()
            end)
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    ViewScriptBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            viewScript(selectedObject)
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    MoveBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            MoveBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 400, 0, MainFrame.AbsolutePosition.Y + 300)
            MoveBox.Visible = true
            MoveBox:CaptureFocus()
            
            local focusConnection
            focusConnection = MoveBox.FocusLost:Connect(function()
                if MoveBox.Text ~= "" then
                    if applyToObject(selectedObject, "Move", MoveBox.Text) then
                        refreshAll()
                        updateStatus("Moved to: " .. MoveBox.Text)
                    else
                        updateStatus("ERROR: Target not found", true)
                    end
                end
                MoveBox.Visible = false
                focusConnection:Disconnect()
            end)
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    ApplyPropBtn.MouseButton1Click:Connect(function()
        if selectedObject then
            PropNameBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 200, 0, MainFrame.AbsolutePosition.Y + 250)
            PropValueBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 360, 0, MainFrame.AbsolutePosition.Y + 250)
            PropNameBox.Visible = true
            PropValueBox.Visible = true
            PropNameBox:CaptureFocus()
            
            local function applyProperty()
                local propName = PropNameBox.Text
                local propValue = PropValueBox.Text
                
                if propName ~= "" then
                    local converted
                    if propValue:match("^%d+$") then
                        converted = tonumber(propValue)
                    elseif propValue == "true" then
                        converted = true
                    elseif propValue == "false" then
                        converted = false
                    elseif propValue:match("^%d+%.%d+%.%d+$") then
                        local parts = {propValue:match("([^,]+),([^,]+),([^,]+)")}
                        if #parts == 3 then
                            converted = Vector3.new(tonumber(parts[1]), tonumber(parts[2]), tonumber(parts[3]))
                        end
                    else
                        converted = propValue
                    end
                    
                    if applyToObject(selectedObject, "SetProperty", {propName, converted}) then
                        refreshAll()
                        updateStatus("Property set: " .. propName .. " = " .. propValue)
                    else
                        updateStatus("ERROR: Failed to set property", true)
                    end
                end
                PropNameBox.Visible = false
                PropValueBox.Visible = false
            end
            
            local focusConnection1, focusConnection2
            focusConnection1 = PropNameBox.FocusLost:Connect(applyProperty)
            focusConnection2 = PropValueBox.FocusLost:Connect(applyProperty)
        else
            updateStatus("ERROR: No object selected", true)
        end
    end)
    
    local function addHover(btn)
        local orig = btn.BackgroundColor3
        btn.MouseEnter:Connect(function()
            btn.BackgroundColor3 = colors.highlight
        end)
        btn.MouseLeave:Connect(function()
            btn.BackgroundColor3 = orig
        end)
    end
    
    local buttons = {ScanBtn, ScanAllBtn, ExportBtn, RefreshBtn, CopyBtn, PasteBtn, DeleteBtn, RenameBtn, ViewScriptBtn, MoveBtn, ApplyPropBtn}
    for _, btn in ipairs(buttons) do
        addHover(btn)
    end
    
    updateStatus("Roblox Engine loaded | Click SCAN ALL to load object tree")
end)()