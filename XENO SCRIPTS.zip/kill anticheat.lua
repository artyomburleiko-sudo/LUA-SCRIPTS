--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
pcall(function()
loadstring(game:HttpGet("https://raw.githubusercontent.com/hm5650/ACR/refs/heads/main/Acr", true))()
end)