--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
local Players = game:GetService("Players")
local player = Players.LocalPlayer

local HEADLESS_MESH_ID = "rbxassetid://1095708"     -- Tiny invisible headless mesh
local KORBLOX_MESH_ID = "rbxassetid://101851696"   -- Korblox right leg mesh

local GREY_COLOR = Color3.fromRGB(128, 128, 128)   -- Medium grey

local function applyHeadless(head)
    if not head then return end

    head.Transparency = 1
    head.CanCollide = false

    local faceDecal = head:FindFirstChild("face")
    if faceDecal and faceDecal:IsA("Decal") then
        faceDecal:Destroy()
    end

    for _, child in ipairs(head:GetChildren()) do
        if child:IsA("SpecialMesh") or child:IsA("CharacterMesh") then
            child:Destroy()
        end
    end

    local mesh = Instance.new("SpecialMesh")
    mesh.MeshType = Enum.MeshType.FileMesh
    mesh.MeshId = HEADLESS_MESH_ID
    mesh.Scale = Vector3.new(0.001, 0.001, 0.001)
    mesh.Parent = head

    head:GetPropertyChangedSignal("Transparency"):Connect(function()
        if head.Transparency ~= 1 then
            head.Transparency = 1
        end
    end)
end

local function applyKorbloxLeg(character)
    local rightLeg = character:FindFirstChild("Right Leg") or character:FindFirstChild("RightLeg")
    if not rightLeg then
        warn("Right Leg not found!")
        return
    end

    -- Remove existing meshes
    for _, child in ipairs(rightLeg:GetChildren()) do
        if child:IsA("SpecialMesh") or child:IsA("CharacterMesh") then
            child:Destroy()
        end
    end

    -- Set the leg color to grey
    rightLeg.BrickColor = BrickColor.new(GREY_COLOR)

    -- Add Korblox mesh
    local korbloxMesh = Instance.new("SpecialMesh")
    korbloxMesh.MeshType = Enum.MeshType.FileMesh
    korbloxMesh.MeshId = KORBLOX_MESH_ID
    korbloxMesh.Scale = Vector3.new(1, 1, 1)
    korbloxMesh.Parent = rightLeg
end

player.CharacterAdded:Connect(function(character)
    local head = character:WaitForChild("Head")
    applyHeadless(head)
    applyKorbloxLeg(character)
end)

if player.Character then
    local head = player.Character:FindFirstChild("Head")
    if head then
        applyHeadless(head)
    end
    applyKorbloxLeg(player.Character)
end
