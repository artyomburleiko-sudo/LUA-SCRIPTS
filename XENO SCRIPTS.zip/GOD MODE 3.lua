-- Made by bacon hacks

local Tutorial = Instance.new("ScreenGui")
local Open = Instance.new("Frame")
local OpenGui = Instance.new("TextButton")
local GuiFrame = Instance.new("Frame")
local GodPlr = Instance.new("TextButton")
local p = game.Players.LocalPlayer

Tutorial.Name = "Tutorial"
Tutorial.Parent = game.CoreGui

Open.Name = "Open"
Open.Parent = Tutorial
Open.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
Open.BackgroundTransparency = 0.34999999403954
Open.Position = UDim2.new(0, 0, 0.520884514, 0)
Open.Size = UDim2.new(0, 135, 0, 46)

OpenGui.Name = "OpenGui"
OpenGui.Parent = Open
OpenGui.BackgroundColor3 = Color3.new(1, 1, 1)
OpenGui.BackgroundTransparency = 1
OpenGui.Size = UDim2.new(0, 135, 0, 46)
OpenGui.Font = Enum.Font.SourceSans
OpenGui.Text = "Open"
OpenGui.TextColor3 = Color3.new(0, 0, 0)
OpenGui.TextSize = 50

GuiFrame.Name = "GuiFrame"
GuiFrame.Parent = Tutorial
GuiFrame.BackgroundColor3 = Color3.new(1, 1, 1)
GuiFrame.BackgroundTransparency = 0.5
GuiFrame.Position = UDim2.new(0.440088749, 0, 0.156019658, 0)
GuiFrame.Size = UDim2.new(0, 486, 0, 391)
GuiFrame.Visible = false

GodPlr.Name = "GodPlr"
GodPlr.Parent = GuiFrame
GodPlr.BackgroundColor3 = Color3.new(1, 1, 1)
GodPlr.Position = UDim2.new(0.294238687, 0, 0.0843990073, 0)
GodPlr.Size = UDim2.new(0, 200, 0, 50)
GodPlr.Font = Enum.Font.SourceSans
GodPlr.Text = "InfHealth"
GodPlr.TextColor3 = Color3.new(0, 1, 1)
GodPlr.TextSize = 50
GodPlr.TextStrokeColor3 = Color3.new(0, 1, 1)

GodPlr.MouseButton1Click:connect(function()
	p.Character.Humanoid.MaxHealth = math.huge
end)

OpenGui.MouseButton1Click:connect(function()
	game.CoreGui.Tutorial.Open.Visible = false
	game.CoreGui.Tutorial.GuiFrame.Visible = true
end)