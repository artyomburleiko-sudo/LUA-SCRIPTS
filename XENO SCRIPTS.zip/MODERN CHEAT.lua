--[[
    Современный GUI скрипт для Roblox Player
    Исполнитель: Ваш исполнитель
    Версия: 2.4
]]

-- Инициализация основных сервисов
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local CoreGui = game:GetService("CoreGui")
local LocalPlayer = Players.LocalPlayer
local Camera = workspace.CurrentCamera
local Mouse = LocalPlayer:GetMouse()
local VirtualUser = game:GetService("VirtualUser")

-- Защита от повторного запуска
if getgenv().ModernGUI_Loaded then
    return
end
getgenv().ModernGUI_Loaded = true

-- Переменные для функций
local ESPEnabled = false
local AimbotEnabled = false
local NoclipEnabled = false
local FlyEnabled = false
local SpinBotEnabled = false
local ChamsEnabled = false
local AntiKickEnabled = false
local SpeedEnabled = false
local JumpPowerEnabled = false
local MenuMinimized = false

local ESPObjects = {}
local FlyConnection = nil
local NoclipConnection = nil
local SpinBotConnection = nil
local AimbotConnection = nil
local OriginalMethods = {}
local SpeedValue = 16
local JumpValue = 50

-- Создание главного GUI
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "ModernGUI"
ScreenGui.Parent = CoreGui
ScreenGui.Enabled = true
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

-- Затемняющий фон (полупрозрачный черный)
local BackgroundOverlay = Instance.new("Frame")
BackgroundOverlay.Name = "BackgroundOverlay"
BackgroundOverlay.Size = UDim2.new(1, 0, 1, 0)
BackgroundOverlay.Position = UDim2.new(0, 0, 0, 0)
BackgroundOverlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
BackgroundOverlay.BackgroundTransparency = 0.5
BackgroundOverlay.BorderSizePixel = 0
BackgroundOverlay.Parent = ScreenGui
BackgroundOverlay.Visible = true
BackgroundOverlay.Active = true

-- Главное меню
local MainFrame = Instance.new("Frame")
MainFrame.Name = "MainFrame"
MainFrame.Size = UDim2.new(0, 350, 0, 500)
MainFrame.Position = UDim2.new(0.5, -175, 0.5, -250)
MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 40)
MainFrame.BackgroundTransparency = 0
MainFrame.BorderSizePixel = 0
MainFrame.Parent = ScreenGui
MainFrame.Active = true
MainFrame.Draggable = true

-- Создание эффекта стекла
local GlassEffect = Instance.new("Frame")
GlassEffect.Name = "GlassEffect"
GlassEffect.Size = UDim2.new(1, 0, 1, 0)
GlassEffect.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
GlassEffect.BackgroundTransparency = 0.95
GlassEffect.BorderSizePixel = 0
GlassEffect.Parent = MainFrame

-- Скругленные углы
local UICorner = Instance.new("UICorner")
UICorner.CornerRadius = UDim.new(0, 15)
UICorner.Parent = MainFrame

-- Заголовок
local Title = Instance.new("TextLabel")
Title.Name = "Title"
Title.Size = UDim2.new(1, 0, 0, 50)
Title.Position = UDim2.new(0, 0, 0, 0)
Title.BackgroundTransparency = 1
Title.Text = "MODERN CHEAT"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.TextScaled = true
Title.Font = Enum.Font.GothamBold
Title.Parent = MainFrame

-- Верхняя панель управления
local TopBar = Instance.new("Frame")
TopBar.Name = "TopBar"
TopBar.Size = UDim2.new(1, 0, 0, 50)
TopBar.BackgroundTransparency = 1
TopBar.Parent = MainFrame

-- Кнопка сворачивания
local MinimizeButton = Instance.new("ImageButton")
MinimizeButton.Name = "MinimizeButton"
MinimizeButton.Size = UDim2.new(0, 30, 0, 30)
MinimizeButton.Position = UDim2.new(1, -80, 0, 10)
MinimizeButton.BackgroundTransparency = 1
MinimizeButton.Image = "rbxassetid://3926305904"
MinimizeButton.ImageColor3 = Color3.fromRGB(255, 255, 0)
MinimizeButton.Parent = TopBar

-- Кнопка закрытия
local CloseButton = Instance.new("ImageButton")
CloseButton.Name = "CloseButton"
CloseButton.Size = UDim2.new(0, 30, 0, 30)
CloseButton.Position = UDim2.new(1, -40, 0, 10)
CloseButton.BackgroundTransparency = 1
CloseButton.Image = "rbxassetid://3926305904"
CloseButton.ImageColor3 = Color3.fromRGB(255, 100, 100)
CloseButton.Parent = TopBar

-- Контейнер для кнопок
local ButtonContainer = Instance.new("ScrollingFrame")
ButtonContainer.Name = "ButtonContainer"
ButtonContainer.Size = UDim2.new(1, -20, 1, -80)
ButtonContainer.Position = UDim2.new(0, 10, 0, 60)
ButtonContainer.BackgroundTransparency = 1
ButtonContainer.BorderSizePixel = 0
ButtonContainer.ScrollBarThickness = 5
ButtonContainer.ScrollBarImageColor3 = Color3.fromRGB(100, 100, 255)
ButtonContainer.CanvasSize = UDim2.new(0, 0, 0, 0)
ButtonContainer.AutomaticCanvasSize = Enum.AutomaticSize.Y
ButtonContainer.Parent = MainFrame
ButtonContainer.Visible = true

-- UI Список
local UIListLayout = Instance.new("UIListLayout")
UIListLayout.Padding = UDim.new(0, 8)
UIListLayout.HorizontalAlignment = Enum.HorizontalAlignment.Center
UIListLayout.SortOrder = Enum.SortOrder.LayoutOrder
UIListLayout.Parent = ButtonContainer

-- Функция создания кнопки
local function CreateButton(name, description, callback, order)
    local ButtonFrame = Instance.new("Frame")
    ButtonFrame.Name = name .. "Frame"
    ButtonFrame.Size = UDim2.new(1, 0, 0, 60)
    ButtonFrame.BackgroundTransparency = 1
    ButtonFrame.LayoutOrder = order
    ButtonFrame.Parent = ButtonContainer
    
    local Button = Instance.new("TextButton")
    Button.Name = name .. "Button"
    Button.Size = UDim2.new(1, -10, 1, -10)
    Button.Position = UDim2.new(0, 5, 0, 5)
    Button.BackgroundColor3 = Color3.fromRGB(40, 40, 50)
    Button.Text = ""
    Button.AutoButtonColor = false
    Button.Parent = ButtonFrame
    
    local ButtonCorner = Instance.new("UICorner")
    ButtonCorner.CornerRadius = UDim.new(0, 10)
    ButtonCorner.Parent = Button
    
    local TitleLabel = Instance.new("TextLabel")
    TitleLabel.Size = UDim2.new(1, -50, 0, 25)
    TitleLabel.Position = UDim2.new(0, 10, 0, 5)
    TitleLabel.BackgroundTransparency = 1
    TitleLabel.Text = name
    TitleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
    TitleLabel.TextXAlignment = Enum.TextXAlignment.Left
    TitleLabel.Font = Enum.Font.GothamSemibold
    TitleLabel.TextSize = 16
    TitleLabel.Parent = Button
    
    local DescLabel = Instance.new("TextLabel")
    DescLabel.Size = UDim2.new(1, -50, 0, 20)
    DescLabel.Position = UDim2.new(0, 10, 0, 30)
    DescLabel.BackgroundTransparency = 1
    DescLabel.Text = description
    DescLabel.TextColor3 = Color3.fromRGB(180, 180, 180)
    DescLabel.TextXAlignment = Enum.TextXAlignment.Left
    DescLabel.Font = Enum.Font.Gotham
    DescLabel.TextSize = 12
    DescLabel.Parent = Button
    
    local ToggleIndicator = Instance.new("Frame")
    ToggleIndicator.Name = "ToggleIndicator"
    ToggleIndicator.Size = UDim2.new(0, 20, 0, 20)
    ToggleIndicator.Position = UDim2.new(1, -30, 0.5, -10)
    ToggleIndicator.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
    ToggleIndicator.Parent = Button
    
    local IndicatorCorner = Instance.new("UICorner")
    IndicatorCorner.CornerRadius = UDim.new(1, 0)
    IndicatorCorner.Parent = ToggleIndicator
    
    local isEnabled = false
    
    local function UpdateIndicator()
        ToggleIndicator.BackgroundColor3 = isEnabled and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 0, 0)
    end
    
    Button.MouseButton1Click:Connect(function()
        isEnabled = callback()
        UpdateIndicator()
    end)
    
    Button.MouseEnter:Connect(function()
        TweenService:Create(Button, TweenInfo.new(0.3), {BackgroundColor3 = Color3.fromRGB(50, 50, 60)}):Play()
    end)
    
    Button.MouseLeave:Connect(function()
        TweenService:Create(Button, TweenInfo.new(0.3), {BackgroundColor3 = Color3.fromRGB(40, 40, 50)}):Play()
    end)
    
    UpdateIndicator()
    
    return Button
end

-- ESP функция
local function ToggleESP()
    ESPEnabled = not ESPEnabled
    
    if ESPEnabled then
        local function CreateESP(player)
            if player == LocalPlayer then return end
            
            local function AddESP(character)
                if not character then return end
                
                local humanoid = character:FindFirstChild("Humanoid")
                local head = character:FindFirstChild("Head")
                
                if humanoid and head then
                    -- Бокс
                    local box = Instance.new("BoxHandleAdornment")
                    box.Name = "ESP_Box"
                    box.Size = Vector3.new(4, 5, 2)
                    box.AlwaysOnTop = true
                    box.ZIndex = 5
                    box.Adornee = character
                    box.Color3 = player.Team and player.TeamColor.Color or Color3.fromRGB(255, 255, 255)
                    box.Transparency = 0.5
                    box.Parent = character
                    
                    -- Никнейм
                    local billboard = Instance.new("BillboardGui")
                    billboard.Name = "ESP_Name"
                    billboard.Size = UDim2.new(0, 100, 0, 30)
                    billboard.AlwaysOnTop = true
                    billboard.StudsOffset = Vector3.new(0, 3, 0)
                    billboard.Parent = head
                    
                    local nameLabel = Instance.new("TextLabel")
                    nameLabel.Size = UDim2.new(1, 0, 1, 0)
                    nameLabel.BackgroundTransparency = 1
                    nameLabel.Text = player.Name
                    nameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
                    nameLabel.TextScaled = true
                    nameLabel.Font = Enum.Font.GothamBold
                    nameLabel.Parent = billboard
                    
                    table.insert(ESPObjects, {box, billboard, player})
                end
            end
            
            if player.Character then
                AddESP(player.Character)
            end
            
            player.CharacterAdded:Connect(function(character)
                wait(0.1)
                AddESP(character)
            end)
        end
        
        for _, player in ipairs(Players:GetPlayers()) do
            CreateESP(player)
        end
        
        Players.PlayerAdded:Connect(CreateESP)
        
        Players.PlayerRemoving:Connect(function(player)
            for i = #ESPObjects, 1, -1 do
                if ESPObjects[i][3] == player then
                    if ESPObjects[i][1] and ESPObjects[i][1].Parent then
                        ESPObjects[i][1]:Destroy()
                    end
                    if ESPObjects[i][2] and ESPObjects[i][2].Parent then
                        ESPObjects[i][2]:Destroy()
                    end
                    table.remove(ESPObjects, i)
                end
            end
        end)
    else
        for _, obj in ipairs(ESPObjects) do
            if obj[1] and obj[1].Parent then
                obj[1]:Destroy()
            end
            if obj[2] and obj[2].Parent then
                obj[2]:Destroy()
            end
        end
        ESPObjects = {}
    end
    
    return ESPEnabled
end

-- Aimbot функция
local function ToggleAimbot()
    AimbotEnabled = not AimbotEnabled
    
    if AimbotEnabled then
        if AimbotConnection then
            AimbotConnection:Disconnect()
        end
        
        AimbotConnection = RunService.RenderStepped:Connect(function()
            if not AimbotEnabled then return end
            
            local closestPlayer = nil
            local shortestDistance = math.huge
            local targetPosition = nil
            
            -- Поиск ближайшего игрока к прицелу
            for _, player in ipairs(Players:GetPlayers()) do
                if player ~= LocalPlayer and player.Character and player.Character:FindFirstChild("Humanoid") and player.Character.Humanoid.Health > 0 then
                    local head = player.Character:FindFirstChild("Head")
                    if head then
                        local screenPoint, onScreen = Camera:WorldToViewportPoint(head.Position)
                        if onScreen then
                            local distance = (Vector2.new(Mouse.X, Mouse.Y) - Vector2.new(screenPoint.X, screenPoint.Y)).Magnitude
                            if distance < shortestDistance and distance < 300 then
                                shortestDistance = distance
                                closestPlayer = player
                                targetPosition = head.Position
                            end
                        end
                    end
                end
            end
            
            -- Наведение на цель
            if closestPlayer and targetPosition then
                -- Проверка видимости
                local ray = Ray.new(Camera.CFrame.Position, (targetPosition - Camera.CFrame.Position).Unit * 1000)
                local hit, position = workspace:FindPartOnRay(ray, LocalPlayer.Character)
                
                if hit and hit:IsDescendantOf(closestPlayer.Character) then
                    -- Плавное наведение
                    local targetCFrame = CFrame.new(Camera.CFrame.Position, targetPosition)
                    Camera.CFrame = Camera.CFrame:Lerp(targetCFrame, 0.3)
                end
            end
        end)
    else
        if AimbotConnection then
            AimbotConnection:Disconnect()
            AimbotConnection = nil
        end
    end
    
    return AimbotEnabled
end

-- Noclip функция
local function ToggleNoclip()
    NoclipEnabled = not NoclipEnabled
    
    if NoclipEnabled then
        NoclipConnection = RunService.Stepped:Connect(function()
            if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Humanoid") then
                for _, part in ipairs(LocalPlayer.Character:GetDescendants()) do
                    if part:IsA("BasePart") then
                        part.CanCollide = false
                    end
                end
            end
        end)
    else
        if NoclipConnection then
            NoclipConnection:Disconnect()
            NoclipConnection = nil
        end
    end
    
    return NoclipEnabled
end

-- Fly функция
local function ToggleFly()
    FlyEnabled = not FlyEnabled
    
    if FlyEnabled then
        local flySpeed = 50
        local bodyVelocity = Instance.new("BodyVelocity")
        bodyVelocity.Velocity = Vector3.new(0, 0, 0)
        bodyVelocity.MaxForce = Vector3.new(10000, 10000, 10000)
        
        FlyConnection = RunService.Heartbeat:Connect(function()
            if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local rootPart = LocalPlayer.Character.HumanoidRootPart
                
                if not bodyVelocity.Parent then
                    bodyVelocity.Parent = rootPart
                end
                
                local moveDirection = Vector3.new(0, 0, 0)
                
                if UserInputService:IsKeyDown(Enum.KeyCode.W) then
                    moveDirection = moveDirection + Camera.CFrame.LookVector
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.S) then
                    moveDirection = moveDirection - Camera.CFrame.LookVector
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.A) then
                    moveDirection = moveDirection - Camera.CFrame.RightVector
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.D) then
                    moveDirection = moveDirection + Camera.CFrame.RightVector
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.Space) then
                    moveDirection = moveDirection + Vector3.new(0, 1, 0)
                end
                if UserInputService:IsKeyDown(Enum.KeyCode.LeftControl) then
                    moveDirection = moveDirection - Vector3.new(0, 1, 0)
                end
                
                if moveDirection.Magnitude > 0 then
                    bodyVelocity.Velocity = moveDirection.Unit * flySpeed
                else
                    bodyVelocity.Velocity = Vector3.new(0, 0, 0)
                end
            end
        end)
    else
        if FlyConnection then
            FlyConnection:Disconnect()
            FlyConnection = nil
            
            if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local bodyVelocity = LocalPlayer.Character.HumanoidRootPart:FindFirstChildOfClass("BodyVelocity")
                if bodyVelocity then
                    bodyVelocity:Destroy()
                end
            end
        end
    end
    
    return FlyEnabled
end

-- Spin Bot функция
local function ToggleSpinBot()
    SpinBotEnabled = not SpinBotEnabled
    
    if SpinBotEnabled then
        SpinBotConnection = RunService.Heartbeat:Connect(function()
            if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local rootPart = LocalPlayer.Character.HumanoidRootPart
                rootPart.CFrame = rootPart.CFrame * CFrame.Angles(0, math.rad(15), 0)
            end
        end)
    else
        if SpinBotConnection then
            SpinBotConnection:Disconnect()
            SpinBotConnection = nil
        end
    end
    
    return SpinBotEnabled
end

-- Chams функция
local function ToggleChams()
    ChamsEnabled = not ChamsEnabled
    
    if ChamsEnabled then
        local function ApplyChams(character)
            if not character then return end
            
            -- Удаляем старые чамсы
            for _, oldHighlight in ipairs(character:GetDescendants()) do
                if oldHighlight.Name == "Chams_Highlight" then
                    oldHighlight:Destroy()
                end
            end
            
            -- Добавляем новые чамсы
            for _, part in ipairs(character:GetDescendants()) do
                if part:IsA("BasePart") and part ~= character:FindFirstChild("HumanoidRootPart") then
                    local highlight = Instance.new("Highlight")
                    highlight.Name = "Chams_Highlight"
                    highlight.Adornee = part
                    highlight.FillColor = Color3.fromRGB(0, 255, 0)
                    highlight.OutlineColor = Color3.fromRGB(255, 255, 255)
                    highlight.FillTransparency = 0.3
                    highlight.OutlineTransparency = 0
                    highlight.DepthMode = Enum.HighlightDepthMode.AlwaysOnTop
                    highlight.Parent = part
                end
            end
        end
        
        for _, player in ipairs(Players:GetPlayers()) do
            if player ~= LocalPlayer then
                if player.Character then
                    ApplyChams(player.Character)
                end
                
                player.CharacterAdded:Connect(ApplyChams)
            end
        end
    else
        for _, player in ipairs(Players:GetPlayers()) do
            if player.Character then
                for _, highlight in ipairs(player.Character:GetDescendants()) do
                    if highlight.Name == "Chams_Highlight" then
                        highlight:Destroy()
                    end
                end
            end
        end
    end
    
    return ChamsEnabled
end

-- AntiKick функция
local function ToggleAntiKick()
    AntiKickEnabled = not AntiKickEnabled
    
    if AntiKickEnabled then
        -- Анти-афк
        LocalPlayer.Idled:Connect(function()
            VirtualUser:CaptureController()
            VirtualUser:ClickButton2(Vector2.new())
        end)
        
        -- Перехват кика (если доступно)
        if hookfunction then
            local oldkick = hookfunction(game.Players.LocalPlayer.Kick, function() 
                if not AntiKickEnabled then
                    return oldkick()
                end
                return nil
            end)
        end
    end
    
    return AntiKickEnabled
end

-- Speed X2 функция
local function ToggleSpeed()
    SpeedEnabled = not SpeedEnabled
    
    local function UpdateSpeed()
        if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Humanoid") then
            local humanoid = LocalPlayer.Character.Humanoid
            humanoid.WalkSpeed = SpeedEnabled and 32 or 16
        end
    end
    
    UpdateSpeed()
    
    -- Обновляем при смене персонажа
    LocalPlayer.CharacterAdded:Connect(function()
        wait(0.5)
        UpdateSpeed()
    end)
    
    return SpeedEnabled
end

-- JumpPower X2 функция
local function ToggleJumpPower()
    JumpPowerEnabled = not JumpPowerEnabled
    
    local function UpdateJumpPower()
        if LocalPlayer.Character and LocalPlayer.Character:FindFirstChild("Humanoid") then
            local humanoid = LocalPlayer.Character.Humanoid
            humanoid.JumpPower = JumpPowerEnabled and 100 or 50
            humanoid.JumpHeight = JumpPowerEnabled and 14.4 or 7.2
        end
    end
    
    UpdateJumpPower()
    
    -- Обновляем при смене персонажа
    LocalPlayer.CharacterAdded:Connect(function()
        wait(0.5)
        UpdateJumpPower()
    end)
    
    return JumpPowerEnabled
end

-- Функция сворачивания/разворачивания
local function ToggleMinimize()
    MenuMinimized = not MenuMinimized
    
    local targetSize = MenuMinimized and UDim2.new(0, 350, 0, 50) or UDim2.new(0, 350, 0, 500)
    local targetPosition = MenuMinimized and UDim2.new(0.5, -175, 0, 10) or UDim2.new(0.5, -175, 0.5, -250)
    
    -- Анимация сворачивания
    TweenService:Create(MainFrame, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        Size = targetSize,
        Position = targetPosition
    }):Play()
    
    -- Прячем контейнер с кнопками
    ButtonContainer.Visible = not MenuMinimized
    
    -- Меняем иконку кнопки
    MinimizeButton.ImageColor3 = MenuMinimized and Color3.fromRGB(0, 255, 0) or Color3.fromRGB(255, 255, 0)
    
    -- Показываем/скрываем затемнение фона
    BackgroundOverlay.Visible = not MenuMinimized
end

-- Обработчики кнопок
MinimizeButton.MouseButton1Click:Connect(ToggleMinimize)

CloseButton.MouseButton1Click:Connect(function()
    TweenService:Create(MainFrame, TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out), {
        Position = UDim2.new(0.5, -175, 1.5, 0)
    }):Play()
    wait(0.3)
    ScreenGui.Enabled = false
    BackgroundOverlay.Visible = false
end)

-- Создание кнопок
CreateButton("ESP", "Показывает игроков через стены", ToggleESP, 1)
CreateButton("AIMBOT", "Автонаведение на игроков", ToggleAimbot, 2)
CreateButton("NOCLIP", "Прохождение сквозь стены", ToggleNoclip, 3)
CreateButton("FLY", "Режим полета (WASD + Space/Ctrl)", ToggleFly, 4)
CreateButton("SPIN BOT", "Вращение персонажа", ToggleSpinBot, 5)
CreateButton("CHAMS", "Подсветка игроков", ToggleChams, 6)
CreateButton("ANTI KICK", "Защита от кика и анти-афк", ToggleAntiKick, 7)
CreateButton("SPEED X2", "Удвоенная скорость бега", ToggleSpeed, 8)
CreateButton("JUMP X2", "Удвоенная сила прыжка", ToggleJumpPower, 9)

-- Функция открытия/закрытия меню по клавише
UserInputService.InputBegan:Connect(function(input, gameProcessed)
    if not gameProcessed and input.KeyCode == Enum.KeyCode.RightShift then
        ScreenGui.Enabled = not ScreenGui.Enabled
        if ScreenGui.Enabled then
            MainFrame.Position = UDim2.new(0.5, -175, 0.5, -250)
            MainFrame.Size = UDim2.new(0, 350, 0, 500)
            ButtonContainer.Visible = true
            MenuMinimized = false
            MinimizeButton.ImageColor3 = Color3.fromRGB(255, 255, 0)
            BackgroundOverlay.Visible = true
        else
            BackgroundOverlay.Visible = false
        end
    end
end)

-- Убираем сообщение в чате
-- Просто ничего не выводим

print("Modern GUI v2.4 успешно загружен!")