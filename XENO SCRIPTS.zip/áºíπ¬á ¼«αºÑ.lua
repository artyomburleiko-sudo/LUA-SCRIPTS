-- Скрипт для Roblox Player (Server Script)
-- Помести в StarterGui

local Players = game:GetService("Players")
local player = Players.LocalPlayer
-- Если это серверный скрипт в StarterGui, он будет выполняться для каждого игрока.
-- ВАЖНО: Этот код должен быть либо в LocalScript (для локальных эффектов), либо в обычном скрипте.
-- Так как мы двигаем персонажа, лучше использовать Обычный скрипт (Server Script) в StarterGui.

-- Функция для создания GUI
local function createGUI()
    -- Проверяем, есть ли уже такой GUI
    local existingGui = player:FindFirstChild("PlayerGui"):FindFirstChild("MorseGUI")
    if existingGui then
        existingGui:Destroy()
    end

    -- Создаем основной экран
    local screenGui = Instance.new("ScreenGui")
    screenGui.Name = "MorseGUI"
    screenGui.Parent = player:WaitForChild("PlayerGui")

    -- Создаем главный фрейм (окошко)
    local mainFrame = Instance.new("Frame")
    mainFrame.Size = UDim2.new(0, 300, 0, 150)
    mainFrame.Position = UDim2.new(0.5, -150, 0.5, -75) -- Центрируем
    mainFrame.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
    mainFrame.BorderSizePixel = 2
    mainFrame.Active = true
    mainFrame.Draggable = true -- Можно перетаскивать мышкой
    mainFrame.Parent = screenGui

    -- Делаем закругленные углы
    local corner = Instance.new("UICorner")
    corner.CornerRadius = UDim.new(0, 8)
    corner.Parent = mainFrame

    -- Заголовок
    local title = Instance.new("TextLabel")
    title.Size = UDim2.new(1, 0, 0, 30)
    title.BackgroundTransparency = 1
    title.Text = "Азбука Морзе (Движения)"
    title.TextColor3 = Color3.fromRGB(255, 255, 255)
    title.TextScaled = true
    title.Font = Enum.Font.GothamBold
    title.Parent = mainFrame

    -- Поле ввода
    local textBox = Instance.new("TextBox")
    textBox.Size = UDim2.new(1, -20, 0, 40)
    textBox.Position = UDim2.new(0, 10, 0, 40)
    textBox.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
    textBox.TextColor3 = Color3.fromRGB(255, 255, 255)
    textBox.PlaceholderText = "Введи слово..."
    textBox.Text = ""
    textBox.ClearTextOnFocus = false
    textBox.Parent = mainFrame

    -- Закругление для поля ввода
    local boxCorner = Instance.new("UICorner")
    boxCorner.CornerRadius = UDim.new(0, 5)
    boxCorner.Parent = textBox

    -- Кнопка
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(0, 150, 0, 40)
    button.Position = UDim2.new(0.5, -75, 1, -50) -- Центрируем по горизонтали, отступ снизу
    button.BackgroundColor3 = Color3.fromRGB(0, 120, 255)
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.Text = "Send"
    button.Font = Enum.Font.Gotham
    button.TextScaled = true
    button.Parent = mainFrame

    -- Закругление для кнопки
    local buttonCorner = Instance.new("UICorner")
    buttonCorner.CornerRadius = UDim.new(0, 5)
    buttonCorner.Parent = button

    return textBox, button
end

-- Функция для "подачи сигнала" движением
local function performMorseAction(character, symbol)
    local humanoid = character:FindFirstChildOfClass("Humanoid")
    local rootPart = character:FindFirstChild("HumanoidRootPart")

    if not humanoid or not rootPart then
        warn("Нет Humanoid или RootPart")
        return
    end

    -- Останавливаем предыдущие действия
    humanoid:MoveTo(rootPart.Position) -- Просто чтобы сбросить путь

    -- Определяем длительность движения
    local duration = 0
    if symbol == "." then
        duration = 0.3 -- Короткий сигнал (точка)
        print("Точка (.) - короткое движение")
    elseif symbol == "-" then
        duration = 0.8 -- Длинный сигнал (тире)
        print("Тире (-) - длинное движение")
    else
        return -- Игнорируем пробелы и прочие символы
    end

    -- Запоминаем текущую позицию
    local startPos = rootPart.Position

    -- Двигаемся вперед (имитация сигнала)
    local targetPos = startPos + character.HumanoidRootPart.CFrame.LookVector * 5 -- На 5 студий вперед
    humanoid:MoveTo(targetPos)

    -- Ждем, пока персонаж дойдет (или пока не пройдет время)
    -- Но мы не можем просто ждать в серверном скрипте, если хотим, чтобы движение было плавным.
    -- Используем delay для следующего шага, но для анимации сигнала оставим Wait.

    -- Ждем половину времени "сигнала", чтобы было похоже на импульс
    task.wait(duration)

    -- Возвращаемся назад
    humanoid:MoveTo(startPos)
    task.wait(duration) -- Ждем возвращения
end

-- Функция для обработки текста и выполнения движений
local function processMorseCode(character, inputText)
    if not character or not character:IsA("Model") then return end
    if not inputText or inputText == "" then return end

    -- Простейший словарь (можно расширить)
    local morseAlphabet = {
        ["A"] = ".-", ["B"] = "-...", ["C"] = "-.-.", ["D"] = "-..",
        ["E"] = ".", ["F"] = "..-.", ["G"] = "--.", ["H"] = "....",
        ["I"] = "..", ["J"] = ".---", ["K"] = "-.-", ["L"] = ".-..",
        ["M"] = "--", ["N"] = "-.", ["O"] = "---", ["P"] = ".--.",
        ["Q"] = "--.-", ["R"] = ".-.", ["S"] = "...", ["T"] = "-",
        ["U"] = "..-", ["V"] = "...-", ["W"] = ".--", ["X"] = "-..-",
        ["Y"] = "-.--", ["Z"] = "--..",
        ["1"] = ".----", ["2"] = "..---", ["3"] = "...--", ["4"] = "....-",
        ["5"] = ".....", ["6"] = "-....", ["7"] = "--...", ["8"] = "---..",
        ["9"] = "----.", ["0"] = "-----",
        [" "] = " " -- Пробел для разделения слов
    }

    -- Переводим текст в верхний регистр
    local upperText = string.upper(inputText)

    -- Собираем последовательность сигналов
    local morseSequence = ""
    for i = 1, #upperText do
        local char = string.sub(upperText, i, i)
        local code = morseAlphabet[char]
        if code then
            morseSequence = morseSequence .. code
            if char ~= " " then
                morseSequence = morseSequence .. "|" -- Добавляем разделитель между буквами
            end
        end
    end

    print("Последовательность Морзе: " .. morseSequence)

    -- Проходим по символам и выполняем движения
    for i = 1, #morseSequence do
        local symbol = string.sub(morseSequence, i, i)

        if symbol == "." or symbol == "-" then
            performMorseAction(character, symbol)
        elseif symbol == "|" then
            -- Пауза между буквами
            task.wait(0.5)
        elseif symbol == " " then
            -- Пауза между словами
            task.wait(1.0)
        end
    end
end

-- Основная логика при нажатии кнопки
local function setup()
    local textBox, button = createGUI()

    button.MouseButton1Click:Connect(function()
        local input = textBox.Text
        if input and input ~= "" then
            print("Отправлено слово: " .. input)

            -- Получаем актуального персонажа
            local character = player.Character
            if character and character:FindFirstChildOfClass("Humanoid") then
                -- Запускаем асинхронно, чтобы не зависал GUI
                task.spawn(processMorseCode, character, input)
            else
                warn("Персонаж не найден или не заспавнен!")
                -- Можно попробовать подождать персонажа
                player.CharacterAdded:Connect(function(newChar)
                    task.wait(1) -- Даем время загрузиться
                    task.spawn(processMorseCode, newChar, input)
                end)
            end
        else
            print("Введи текст!")
        end
    end)
end

-- Ждем появления игрока и запускаем настройку
-- Так как скрипт в StarterGui, игрок уже должен быть.
-- Но на всякий случай используем WaitForChild
player = Players.LocalPlayer
if player then
    setup()
else
    Players.PlayerAdded:Connect(function(plr)
        player = plr
        setup()
    end)
end