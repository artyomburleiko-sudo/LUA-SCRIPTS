local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")

local function enableGodMode()
    humanoid.MaxHealth = math.huge
    humanoid.Health = math.huge
    
    local connection
    connection = humanoid:GetPropertyChangedSignal("Health"):Connect(function()
        if humanoid.Health <= 0 then
            humanoid.Health = math.huge
        end
    end)
    
    humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
    humanoid.BreakJointsOnDeath = false
    
    player.CharacterAdded:Connect(function(newChar)
        character = newChar
        humanoid = character:WaitForChild("Humanoid")
        enableGodMode()
    end)
end

enableGodMode()

local screenGui = Instance.new("ScreenGui")
screenGui.Name = "GodModeGUI"
screenGui.Parent = game:GetService("CoreGui")

local frame = Instance.new("Frame")
frame.Size = UDim2.new(0, 150, 0, 50)
frame.Position = UDim2.new(0, 10, 0, 10)
frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
frame.BackgroundTransparency = 0.5
frame.BorderSizePixel = 0
frame.Parent = screenGui

local button = Instance.new("TextButton")
button.Size = UDim2.new(0, 140, 0, 40)
button.Position = UDim2.new(0, 5, 0, 5)
button.Text = "Бессмертие: ВКЛ"
button.TextColor3 = Color3.fromRGB(255, 255, 255)
button.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
button.BorderSizePixel = 0
button.Parent = frame

local enabled = true

button.MouseButton1Click:Connect(function()
    if enabled then
        enabled = false
        button.Text = "Бессмертие: ВЫКЛ"
        button.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
        humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
        humanoid.BreakJointsOnDeath = true
    else
        enabled = true
        button.Text = "Бессмертие: ВКЛ"
        button.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
        humanoid.MaxHealth = math.huge
        humanoid.Health = math.huge
        humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
        humanoid.BreakJointsOnDeath = false
    end
end)