-- Получаем персонажа текущего игрока
local player = game:GetService("Players").LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()

-- Создаём ForceField как новый объект
local forceField = Instance.new("ForceField")

-- Устанавливаем родителя — персонажа игрока
forceField.Parent = character

-- (Необязательно) Можно скрыть визуальный эффект, если нужно
-- forceField.Visible = false

-- Сообщение в консоль, чтобы убедиться, что скрипт сработал
print("ForceField активирован для", player.Name)