(function()
    local Players = game:GetService("Players")
    local LocalPlayer = Players.LocalPlayer
    local UserInputService = game:GetService("UserInputService")
    local RunService = game:GetService("RunService")
    local HttpService = game:GetService("HttpService")

    local colors = {
        bg = Color3.fromRGB(240, 240, 240),
        panel = Color3.fromRGB(245, 245, 245),
        border = Color3.fromRGB(0, 0, 0),
        text = Color3.fromRGB(0, 0, 0),
        textDim = Color3.fromRGB(80, 80, 80),
        highlight = Color3.fromRGB(210, 210, 210),
        title = Color3.fromRGB(220, 220, 220),
        button = Color3.fromRGB(235, 235, 235),
        success = Color3.fromRGB(100, 150, 100),
        warning = Color3.fromRGB(200, 150, 50),
        selected = Color3.fromRGB(180, 180, 255),
        error = Color3.fromRGB(200, 100, 100),
        explorer = Color3.fromRGB(250, 250, 250),
        scriptBg = Color3.fromRGB(30, 30, 35),
        memoryBg = Color3.fromRGB(20, 20, 25)
    }

    local injectionType = "Internal"
    local hasExternalAPI = false
    local externalAPIs = {}
    
    local function detectInjectionType()
        if syn and syn.crypt and syn.crypt.readprocessmemory then
            injectionType = "External"
            hasExternalAPI = true
            externalAPIs.syn = true
        elseif sw and sw.memory and sw.memory.read then
            injectionType = "External"
            hasExternalAPI = true
            externalAPIs.sw = true
        elseif krnl and krnl.read_memory then
            injectionType = "External"
            hasExternalAPI = true
            externalAPIs.krnl = true
        elseif getmemory and type(getmemory) == "function" then
            injectionType = "External"
            hasExternalAPI = true
            externalAPIs.generic = true
        elseif readProcessMemory and writeProcessMemory then
            injectionType = "External"
            hasExternalAPI = true
            externalAPIs.winapi = true
        end
        return injectionType, hasExternalAPI
    end
    
    local objectTree = {}
    local selectedObject = nil
    local clipboard = nil
    local expandedNodes = {}
    local allObjectsList = {}
    
    local function buildFullTree()
        objectTree = {}
        allObjectsList = {}
        local function scan(obj, parent, depth)
            if depth > 15 then return end
            local node = {
                obj = obj,
                name = obj.Name,
                class = obj.ClassName,
                children = {},
                parent = parent,
                expanded = expandedNodes[obj] or false,
                path = ""
            }
            local pathParts = {}
            local current = obj
            while current do
                table.insert(pathParts, 1, current.Name)
                current = current.Parent
            end
            node.path = table.concat(pathParts, "/")
            table.insert(allObjectsList, node)
            
            if parent then
                table.insert(parent.children, node)
            else
                table.insert(objectTree, node)
            end
            
            for _, child in ipairs(obj:GetChildren()) do
                scan(child, node, (depth or 0) + 1)
            end
        end
        for _, obj in ipairs(game:GetChildren()) do
            scan(obj, nil, 0)
        end
        return #allObjectsList
    end
    
    local function searchObjects(searchTerm, searchType)
        local results = {}
        local searchLower = searchTerm:lower()
        
        for _, node in ipairs(allObjectsList) do
            if searchType == "Name" and node.name:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Class" and node.class:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Path" and node.path:lower():find(searchLower, 1, true) then
                table.insert(results, node)
            elseif searchType == "Both" then
                if node.name:lower():find(searchLower, 1, true) or node.class:lower():find(searchLower, 1, true) then
                    table.insert(results, node)
                end
            end
        end
        
        return results
    end
    
    local function exportToJSON()
        local exportData = {
            gameName = game.Name,
            placeId = game.PlaceId,
            timestamp = os.date("%Y-%m-%d %H:%M:%S"),
            injectionType = injectionType,
            objects = {}
        }
        
        for _, node in ipairs(allObjectsList) do
            local objData = {
                name = node.name,
                className = node.class,
                path = node.path,
                properties = {}
            }
            
            pcall(function()
                objData.properties.Archivable = node.obj.Archivable
            end)
            if node.obj:IsA("BasePart") then
                pcall(function()
                    objData.properties.Position = {node.obj.Position.X, node.obj.Position.Y, node.obj.Position.Z}
                    objData.properties.Size = {node.obj.Size.X, node.obj.Size.Y, node.obj.Size.Z}
                end)
            end
            if node.obj:IsA("NumberValue") or node.obj:IsA("IntValue") then
                pcall(function()
                    objData.properties.Value = node.obj.Value
                end)
            elseif node.obj:IsA("StringValue") then
                pcall(function()
                    objData.properties.Value = node.obj.Value
                end)
            end
            
            table.insert(exportData.objects, objData)
        end
        
        local json = HttpService:JSONEncode(exportData)
        setclipboard(json)
        return json
    end
    
    local scriptWindow = nil
    local scriptEditor = nil
    local currentScript = nil
    
    local function createScriptEditor()
        scriptWindow = Instance.new("Frame")
        scriptWindow.Parent = ScreenGui
        scriptWindow.BackgroundColor3 = colors.scriptBg
        scriptWindow.BorderColor3 = colors.border
        scriptWindow.BorderSizePixel = 2
        scriptWindow.Position = UDim2.new(0, 200, 0, 100)
        scriptWindow.Size = UDim2.new(0, 700, 0, 500)
        scriptWindow.Visible = false
        scriptWindow.Active = true
        scriptWindow.Draggable = true
        
        local titleBar = Instance.new("Frame")
        titleBar.Parent = scriptWindow
        titleBar.BackgroundColor3 = colors.title
        titleBar.BorderColor3 = colors.border
        titleBar.BorderSizePixel = 1
        titleBar.Size = UDim2.new(1, 0, 0, 28)
        
        local titleText = Instance.new("TextLabel")
        titleText.Parent = titleBar
        titleText.BackgroundTransparency = 1
        titleText.Position = UDim2.new(0, 8, 0, 0)
        titleText.Size = UDim2.new(0, 300, 1, 0)
        titleText.Text = "Script Editor"
        titleText.TextColor3 = colors.text
        
        local closeScript = Instance.new("TextButton")
        closeScript.Parent = titleBar
        closeScript.BackgroundColor3 = colors.title
        closeScript.BorderColor3 = colors.border
        closeScript.BorderSizePixel = 1
        closeScript.Position = UDim2.new(1, -28, 0, 0)
        closeScript.Size = UDim2.new(0, 27, 1, 0)
        closeScript.Text = "X"
        closeScript.MouseButton1Click:Connect(function()
            scriptWindow.Visible = false
        end)
        
        local editorFrame = Instance.new("Frame")
        editorFrame.Parent = scriptWindow
        editorFrame.BackgroundColor3 = colors.bg
        editorFrame.BorderColor3 = colors.border
        editorFrame.BorderSizePixel = 1
        editorFrame.Position = UDim2.new(0, 5, 0, 33)
        editorFrame.Size = UDim2.new(1, -10, 1, -68)
        
        scriptEditor = Instance.new("TextBox")
        scriptEditor.Parent = editorFrame
        scriptEditor.BackgroundColor3 = colors.bg
        scriptEditor.BorderColor3 = colors.border
        scriptEditor.BorderSizePixel = 1
        scriptEditor.Size = UDim2.new(1, -10, 1, -10)
        scriptEditor.Position = UDim2.new(0, 5, 0, 5)
        scriptEditor.Text = ""
        scriptEditor.TextColor3 = colors.text
        scriptEditor.TextSize = 12
        scriptEditor.Font = Enum.Font.Code
        scriptEditor.MultiLine = true
        scriptEditor.TextXAlignment = Enum.TextXAlignment.Left
        scriptEditor.TextYAlignment = Enum.TextYAlignment.Top
        scriptEditor.ClearTextOnFocus = false
        
        local saveBtn = Instance.new("TextButton")
        saveBtn.Parent = scriptWindow
        saveBtn.BackgroundColor3 = colors.button
        saveBtn.BorderColor3 = colors.border
        saveBtn.BorderSizePixel = 1
        saveBtn.Position = UDim2.new(1, -85, 1, -30)
        saveBtn.Size = UDim2.new(0, 80, 0, 26)
        saveBtn.Text = "SAVE"
        
        local executeBtn = Instance.new("TextButton")
        executeBtn.Parent = scriptWindow
        executeBtn.BackgroundColor3 = colors.button
        executeBtn.BorderColor3 = colors.border
        executeBtn.BorderSizePixel = 1
        executeBtn.Position = UDim2.new(1, -170, 1, -30)
        executeBtn.Size = UDim2.new(0, 80, 0, 26)
        executeBtn.Text = "EXECUTE"
        
        saveBtn.MouseButton1Click:Connect(function()
            if currentScript and scriptEditor.Text then
                pcall(function()
                    if currentScript:IsA("LocalScript") or currentScript:IsA("ModuleScript") or currentScript:IsA("Script") then
                        currentScript.Source = scriptEditor.Text
                        updateStatus("Script saved: " .. currentScript.Name)
                    end
                end)
            end
        end)
        
        executeBtn.MouseButton1Click:Connect(function()
            local code = scriptEditor.Text
            if code and code ~= "" then
                local success, err = pcall(loadstring, code)
                if success then
                    pcall(success)
                    updateStatus("Script executed")
                else
                    updateStatus("Error: " .. tostring(err), true)
                end
            end
        end)
        
        return scriptWindow
    end
    
    local function viewScript(obj)
        if not scriptWindow then
            createScriptEditor()
        end
        if obj:IsA("LocalScript") or obj:IsA("ModuleScript") or obj:IsA("Script") then
            currentScript = obj
            local source = ""
            pcall(function()
                source = obj.Source
            end)
            scriptEditor.Text = source or "-- Unable to read script source"
            scriptWindow.Visible = true
            updateStatus("Viewing script: " .. obj.Name)
        else
            updateStatus("Not a script: " .. obj.ClassName, true)
        end
    end
    
    local function buildExecutorUI(container)
        local editorFrame = Instance.new("Frame")
        editorFrame.Parent = container
        editorFrame.BackgroundColor3 = colors.scriptBg
        editorFrame.BorderColor3 = colors.border
        editorFrame.BorderSizePixel = 1
        editorFrame.Position = UDim2.new(0, 5, 0, 5)
        editorFrame.Size = UDim2.new(1, -10, 1, -58)
        
        local executorEditor = Instance.new("TextBox")
        executorEditor.Parent = editorFrame
        executorEditor.BackgroundColor3 = colors.scriptBg
        executorEditor.BorderColor3 = colors.border
        executorEditor.BorderSizePixel = 1
        executorEditor.Size = UDim2.new(1, -10, 1, -10)
        executorEditor.Position = UDim2.new(0, 5, 0, 5)
        executorEditor.Text = "-- Roblox Engine Executor\n-- Enter your Lua script here\n\nprint(\"Hello from Roblox Engine!\")\n\n-- Examples:\n-- game.Players.LocalPlayer.Character.Humanoid.WalkSpeed = 50"
        executorEditor.TextColor3 = colors.text
        executorEditor.TextSize = 12
        executorEditor.Font = Enum.Font.Code
        executorEditor.MultiLine = true
        executorEditor.TextXAlignment = Enum.TextXAlignment.Left
        executorEditor.TextYAlignment = Enum.TextYAlignment.Top
        executorEditor.ClearTextOnFocus = false
        
        local buttonBar = Instance.new("Frame")
        buttonBar.Parent = container
        buttonBar.BackgroundColor3 = colors.panel
        buttonBar.BorderColor3 = colors.border
        buttonBar.BorderSizePixel = 1
        buttonBar.Position = UDim2.new(0, 5, 1, -48)
        buttonBar.Size = UDim2.new(1, -10, 0, 42)
        
        local runBtn = Instance.new("TextButton")
        runBtn.Parent = buttonBar
        runBtn.BackgroundColor3 = colors.success
        runBtn.BorderColor3 = colors.border
        runBtn.BorderSizePixel = 1
        runBtn.Position = UDim2.new(1, -170, 0, 6)
        runBtn.Size = UDim2.new(0, 80, 0, 30)
        runBtn.Text = "RUN"
        
        local clearBtn = Instance.new("TextButton")
        clearBtn.Parent = buttonBar
        clearBtn.BackgroundColor3 = colors.button
        clearBtn.BorderColor3 = colors.border
        clearBtn.BorderSizePixel = 1
        clearBtn.Position = UDim2.new(1, -255, 0, 6)
        clearBtn.Size = UDim2.new(0, 80, 0, 30)
        clearBtn.Text = "CLEAR"
        
        local outputFrame = Instance.new("Frame")
        outputFrame.Parent = container
        outputFrame.BackgroundColor3 = colors.memoryBg
        outputFrame.BorderColor3 = colors.border
        outputFrame.BorderSizePixel = 1
        outputFrame.Position = UDim2.new(0, 5, 1, -92)
        outputFrame.Size = UDim2.new(1, -10, 0, 38)
        
        local outputText = Instance.new("TextLabel")
        outputText.Parent = outputFrame
        outputText.BackgroundTransparency = 1
        outputText.Position = UDim2.new(0, 5, 0, 2)
        outputText.Size = UDim2.new(1, -10, 1, -4)
        outputText.Text = "Ready"
        outputText.TextColor3 = colors.textDim
        outputText.TextSize = 10
        outputText.TextXAlignment = Enum.TextXAlignment.Left
        outputText.TextYAlignment = Enum.TextYAlignment.Top
        outputText.TextWrapped = true
        
        runBtn.MouseButton1Click:Connect(function()
            local code = executorEditor.Text
            if code and code ~= "" then
                outputText.Text = "Executing...\n"
                local success, err = pcall(loadstring, code)
                if success then
                    local results = {pcall(success)}
                    if results[1] then
                        outputText.Text = "✓ Executed successfully"
                        if results[2] then
                            outputText.Text = outputText.Text .. "\nReturn: " .. tostring(results[2])
                        end
                    else
                        outputText.Text = "✗ Error: " .. tostring(results[2])
                    end
                else
                    outputText.Text = "✗ Load Error: " .. tostring(err)
                end
                updateStatus("Script executed")
            end
        end)
        
        clearBtn.MouseButton1Click:Connect(function()
            executorEditor.Text = ""
            outputText.Text = "Cleared"
            updateStatus("Editor cleared")
        end)
    end
    
    local function buildMemoryUI(container)
        local statusPanel = Instance.new("Frame")
        statusPanel.Parent = container
        statusPanel.BackgroundColor3 = injectionType == "External" and colors.success or colors.warning
        statusPanel.BorderColor3 = colors.border
        statusPanel.BorderSizePixel = 1
        statusPanel.Position = UDim2.new(0, 5, 0, 5)
        statusPanel.Size = UDim2.new(1, -10, 0, 32)
        
        local statusText = Instance.new("TextLabel")
        statusText.Parent = statusPanel
        statusText.BackgroundTransparency = 1
        statusText.Size = UDim2.new(1, 0, 1, 0)
        statusText.Text = injectionType == "External" and "✓ EXTERNAL MODE ACTIVE - Full memory scan available" or "⚠ INTERNAL MODE - Only Lua memory scan (getgc)"
        statusText.TextColor3 = Color3.fromRGB(255, 255, 255)
        statusText.TextSize = 11
        statusText.TextWrapped = true
        
        local searchPanel = Instance.new("Frame")
        searchPanel.Parent = container
        searchPanel.BackgroundColor3 = colors.panel
        searchPanel.BorderColor3 = colors.border
        searchPanel.BorderSizePixel = 1
        searchPanel.Position = UDim2.new(0, 5, 0, 42)
        searchPanel.Size = UDim2.new(1, -10, 0, 85)
        
        local valueLabel = Instance.new("TextLabel")
        valueLabel.Parent = searchPanel
        valueLabel.BackgroundTransparency = 1
        valueLabel.Position = UDim2.new(0, 10, 0, 12)
        valueLabel.Size = UDim2.new(0, 50, 0, 20)
        valueLabel.Text = "Value:"
        
        local searchValueBox = Instance.new("TextBox")
        searchValueBox.Parent = searchPanel
        searchValueBox.BackgroundColor3 = colors.bg
        searchValueBox.BorderColor3 = colors.border
        searchValueBox.BorderSizePixel = 1
        searchValueBox.Position = UDim2.new(0, 60, 0, 10)
        searchValueBox.Size = UDim2.new(0, 120, 0, 24)
        searchValueBox.Text = "100"
        
        local typeLabel = Instance.new("TextLabel")
        typeLabel.Parent = searchPanel
        typeLabel.BackgroundTransparency = 1
        typeLabel.Position = UDim2.new(0, 190, 0, 12)
        typeLabel.Size = UDim2.new(0, 50, 0, 20)
        typeLabel.Text = "Type:"
        
        local typeBox = Instance.new("TextBox")
        typeBox.Parent = searchPanel
        typeBox.BackgroundColor3 = colors.bg
        typeBox.BorderColor3 = colors.border
        typeBox.BorderSizePixel = 1
        typeBox.Position = UDim2.new(0, 240, 0, 10)
        typeBox.Size = UDim2.new(0, 80, 0, 24)
        typeBox.Text = "number"
        
        local scanMemBtn = Instance.new("TextButton")
        scanMemBtn.Parent = searchPanel
        scanMemBtn.BackgroundColor3 = colors.button
        scanMemBtn.BorderColor3 = colors.border
        scanMemBtn.BorderSizePixel = 1
        scanMemBtn.Position = UDim2.new(0, 330, 0, 10)
        scanMemBtn.Size = UDim2.new(0, 80, 0, 24)
        scanMemBtn.Text = "SCAN"
        
        local scanAllMemBtn = Instance.new("TextButton")
        scanAllMemBtn.Parent = searchPanel
        scanAllMemBtn.BackgroundColor3 = colors.success
        scanAllMemBtn.BorderColor3 = colors.border
        scanAllMemBtn.BorderSizePixel = 1
        scanAllMemBtn.Position = UDim2.new(0, 420, 0, 10)
        scanAllMemBtn.Size = UDim2.new(0, 90, 0, 24)
        scanAllMemBtn.Text = "SCAN ALL"
        
        local noticeLabel = Instance.new("TextLabel")
        noticeLabel.Parent = searchPanel
        noticeLabel.BackgroundTransparency = 1
        noticeLabel.Position = UDim2.new(0, 10, 0, 45)
        noticeLabel.Size = UDim2.new(1, -20, 0, 30)
        if injectionType == "External" then
            noticeLabel.Text = "External mode: Scanning process memory of RobloxPlayerBeta.exe"
        else
            noticeLabel.Text = "Internal mode: Scanning Lua memory (getgc). For full process memory, use external injector."
        end
        noticeLabel.TextColor3 = injectionType == "External" and colors.success or colors.warning
        noticeLabel.TextSize = 9
        noticeLabel.TextWrapped = true
        
        local resultsPanel = Instance.new("Frame")
        resultsPanel.Parent = container
        resultsPanel.BackgroundColor3 = colors.panel
        resultsPanel.BorderColor3 = colors.border
        resultsPanel.BorderSizePixel = 1
        resultsPanel.Position = UDim2.new(0, 5, 0, 132)
        resultsPanel.Size = UDim2.new(1, -10, 1, -142)
        
        local resultsTitle = Instance.new("TextLabel")
        resultsTitle.Parent = resultsPanel
        resultsTitle.BackgroundTransparency = 1
        resultsTitle.Position = UDim2.new(0, 5, 0, 5)
        resultsTitle.Size = UDim2.new(1, -10, 0, 20)
        resultsTitle.Text = injectionType == "External" and "Found Addresses (Process Memory):" or "Found Values (Lua GC):"
        resultsTitle.TextXAlignment = Enum.TextXAlignment.Left
        
        local memoryResultsList = Instance.new("ScrollingFrame")
        memoryResultsList.Parent = resultsPanel
        memoryResultsList.BackgroundColor3 = colors.bg
        memoryResultsList.BorderColor3 = colors.border
        memoryResultsList.BorderSizePixel = 1
        memoryResultsList.Position = UDim2.new(0, 5, 0, 28)
        memoryResultsList.Size = UDim2.new(1, -10, 1, -38)
        memoryResultsList.ScrollBarThickness = 10
        
        local currentMemorySearch = {}
        
        local function internalMemoryScan(searchVal)
            local results = {}
            if getgc then
                local gc = getgc()
                for i, obj in ipairs(gc) do
                    if searchVal == "" or searchVal == "all" then
                        table.insert(results, {address = tostring(i), value = obj, type = type(obj), source = "Lua GC"})
                    elseif type(obj) == "number" and tostring(obj) == searchVal then
                        table.insert(results, {address = tostring(i), value = obj, type = "number", source = "Lua GC"})
                    elseif type(obj) == "string" and obj == searchVal then
                        table.insert(results, {address = tostring(i), value = obj, type = "string", source = "Lua GC"})
                    end
                end
            end
            return results
        end
        
        local function updateMemoryResults()
            for _, child in ipairs(memoryResultsList:GetChildren()) do
                if child:IsA("TextButton") then
                    child:Destroy()
                end
            end
            
            local yOffset = 0
            for _, result in ipairs(currentMemorySearch) do
                local btn = Instance.new("TextButton")
                btn.Parent = memoryResultsList
                btn.BackgroundColor3 = colors.bg
                btn.BorderColor3 = colors.border
                btn.BorderSizePixel = 1
                btn.Size = UDim2.new(1, -5, 0, 28)
                btn.Position = UDim2.new(0, 2, 0, yOffset)
                btn.Text = string.format("Value: %s | Type: %s | Source: %s", tostring(result.value), result.type or "unknown", result.source or "Lua GC")
                btn.TextColor3 = colors.text
                btn.TextSize = 10
                btn.TextXAlignment = Enum.TextXAlignment.Left
                yOffset = yOffset + 30
            end
            
            memoryResultsList.CanvasSize = UDim2.new(0, 0, 0, yOffset + 10)
        end
        
        scanMemBtn.MouseButton1Click:Connect(function()
            local searchVal = searchValueBox.Text
            if searchVal == "" then
                updateStatus("ERROR: Enter search value", true)
                return
            end
            updateStatus("Scanning memory for: " .. searchVal)
            local results = internalMemoryScan(searchVal)
            currentMemorySearch = results
            updateMemoryResults()
            updateStatus("Found " .. #results .. " results")
        end)
        
        scanAllMemBtn.MouseButton1Click:Connect(function()
            updateStatus("Full memory scan in progress...")
            local results = internalMemoryScan("all")
            currentMemorySearch = results
            updateMemoryResults()
            updateStatus("Found " .. #results .. " memory locations")
        end)
    end
    
    local ScreenGui = Instance.new("ScreenGui")
    ScreenGui.Name = "RobloxEngine"
    ScreenGui.Parent = LocalPlayer:WaitForChild("PlayerGui")
    ScreenGui.ResetOnSpawn = false
    
    local MainFrame = Instance.new("Frame")
    MainFrame.Parent = ScreenGui
    MainFrame.BackgroundColor3 = colors.bg
    MainFrame.BorderColor3 = colors.border
    MainFrame.BorderSizePixel = 2
    MainFrame.Position = UDim2.new(0, 100, 0, 50)
    MainFrame.Size = UDim2.new(0, 1100, 0, 700)
    MainFrame.Active = true
    MainFrame.Draggable = true
    
    local TitleBar = Instance.new("Frame")
    TitleBar.Parent = MainFrame
    TitleBar.BackgroundColor3 = colors.title
    TitleBar.BorderColor3 = colors.border
    TitleBar.BorderSizePixel = 1
    TitleBar.Size = UDim2.new(1, 0, 0, 28)
    
    local TitleText = Instance.new("TextLabel")
    TitleText.Parent = TitleBar
    TitleText.BackgroundTransparency = 1
    TitleText.Position = UDim2.new(0, 8, 0, 0)
    TitleText.Size = UDim2.new(0, 300, 1, 0)
    TitleText.Text = "Roblox Engine 3.1 - " .. injectionType .. " Mode"
    TitleText.TextColor3 = injectionType == "External" and colors.success or colors.text
    
    local CloseBtn = Instance.new("TextButton")
    CloseBtn.Parent = TitleBar
    CloseBtn.BackgroundColor3 = colors.title
    CloseBtn.BorderColor3 = colors.border
    CloseBtn.BorderSizePixel = 1
    CloseBtn.Position = UDim2.new(1, -28, 0, 0)
    CloseBtn.Size = UDim2.new(0, 27, 1, 0)
    CloseBtn.Text = "X"
    CloseBtn.MouseButton1Click:Connect(function()
        ScreenGui:Destroy()
    end)
    
    local MinBtn = Instance.new("TextButton")
    MinBtn.Parent = TitleBar
    MinBtn.BackgroundColor3 = colors.title
    MinBtn.BorderColor3 = colors.border
    MinBtn.BorderSizePixel = 1
    MinBtn.Position = UDim2.new(1, -56, 0, 0)
    MinBtn.Size = UDim2.new(0, 27, 1, 0)
    MinBtn.Text = "_"
    local minimized = false
    local originalSize = MainFrame.Size
    MinBtn.MouseButton1Click:Connect(function()
        minimized = not minimized
        if minimized then
            MainFrame.Size = UDim2.new(0, 1100, 0, 28)
        else
            MainFrame.Size = originalSize
        end
    end)
    
    local TabBar = Instance.new("Frame")
    TabBar.Parent = MainFrame
    TabBar.BackgroundColor3 = colors.panel
    TabBar.BorderColor3 = colors.border
    TabBar.BorderSizePixel = 1
    TabBar.Position = UDim2.new(0, 0, 0, 28)
    TabBar.Size = UDim2.new(1, 0, 0, 32)
    
    local ContentContainer = Instance.new("Frame")
    ContentContainer.Parent = MainFrame
    ContentContainer.BackgroundColor3 = colors.bg
    ContentContainer.BorderSizePixel = 0
    ContentContainer.Position = UDim2.new(0, 0, 0, 60)
    ContentContainer.Size = UDim2.new(1, 0, 1, -60)
    
    local ExplorerContent = Instance.new("Frame")
    ExplorerContent.Parent = ContentContainer
    ExplorerContent.BackgroundColor3 = colors.bg
    ExplorerContent.Size = UDim2.new(1, 0, 1, 0)
    ExplorerContent.Visible = true
    
    local ExecutorContent = Instance.new("Frame")
    ExecutorContent.Parent = ContentContainer
    ExecutorContent.BackgroundColor3 = colors.bg
    ExecutorContent.Size = UDim2.new(1, 0, 1, 0)
    ExecutorContent.Visible = false
    
    local MemoryContent = Instance.new("Frame")
    MemoryContent.Parent = ContentContainer
    MemoryContent.BackgroundColor3 = colors.bg
    MemoryContent.Size = UDim2.new(1, 0, 1, 0)
    MemoryContent.Visible = false
    
    local function buildExplorerUI()
        local ProcessPanel = Instance.new("Frame")
        ProcessPanel.Parent = ExplorerContent
        ProcessPanel.BackgroundColor3 = colors.panel
        ProcessPanel.BorderColor3 = colors.border
        ProcessPanel.BorderSizePixel = 1
        ProcessPanel.Position = UDim2.new(0, 5, 0, 5)
        ProcessPanel.Size = UDim2.new(1, -10, 0, 42)
        
        local ProcessLabel = Instance.new("TextLabel")
        ProcessLabel.Parent = ProcessPanel
        ProcessLabel.BackgroundTransparency = 1
        ProcessLabel.Position = UDim2.new(0, 10, 0, 11)
        ProcessLabel.Size = UDim2.new(0, 55, 0, 18)
        ProcessLabel.Text = "Process:"
        ProcessLabel.TextColor3 = colors.textDim
        
        local ProcessName = Instance.new("TextLabel")
        ProcessName.Parent = ProcessPanel
        ProcessName.BackgroundColor3 = colors.bg
        ProcessName.BorderColor3 = colors.border
        ProcessName.BorderSizePixel = 1
        ProcessName.Position = UDim2.new(0, 70, 0, 8)
        ProcessName.Size = UDim2.new(0, 200, 0, 24)
        ProcessName.Text = "RobloxPlayerBeta.exe"
        ProcessName.TextColor3 = colors.text
        
        local FEStatus = Instance.new("TextLabel")
        FEStatus.Parent = ProcessPanel
        FEStatus.BackgroundTransparency = 1
        FEStatus.Position = UDim2.new(0, 300, 0, 11)
        FEStatus.Size = UDim2.new(0, 220, 0, 18)
        local fe = pcall(function() return game:GetService("Workspace").FilteringEnabled end)
        FEStatus.Text = fe and "⚙ FE: " .. (fe and "ON" or "OFF") or "⚙ FE: Unknown"
        FEStatus.TextColor3 = colors.textDim
        
        local ExplorerToolBar = Instance.new("Frame")
        ExplorerToolBar.Parent = ExplorerContent
        ExplorerToolBar.BackgroundColor3 = colors.panel
        ExplorerToolBar.BorderColor3 = colors.border
        ExplorerToolBar.BorderSizePixel = 1
        ExplorerToolBar.Position = UDim2.new(0, 5, 0, 52)
        ExplorerToolBar.Size = UDim2.new(1, -10, 0, 36)
        
        local SearchLabel = Instance.new("TextLabel")
        SearchLabel.Parent = ExplorerToolBar
        SearchLabel.BackgroundTransparency = 1
        SearchLabel.Position = UDim2.new(0, 8, 0, 10)
        SearchLabel.Size = UDim2.new(0, 45, 0, 18)
        SearchLabel.Text = "Search:"
        
        local SearchBox = Instance.new("TextBox")
        SearchBox.Parent = ExplorerToolBar
        SearchBox.BackgroundColor3 = colors.bg
        SearchBox.BorderColor3 = colors.border
        SearchBox.BorderSizePixel = 1
        SearchBox.Position = UDim2.new(0, 55, 0, 7)
        SearchBox.Size = UDim2.new(0, 150, 0, 24)
        SearchBox.PlaceholderText = "Object name..."
        
        local SearchTypeBox = Instance.new("TextBox")
        SearchTypeBox.Parent = ExplorerToolBar
        SearchTypeBox.BackgroundColor3 = colors.bg
        SearchTypeBox.BorderColor3 = colors.border
        SearchTypeBox.BorderSizePixel = 1
        SearchTypeBox.Position = UDim2.new(0, 215, 0, 7)
        SearchTypeBox.Size = UDim2.new(0, 70, 0, 24)
        SearchTypeBox.Text = "Both"
        
        local ScanBtn = Instance.new("TextButton")
        ScanBtn.Parent = ExplorerToolBar
        ScanBtn.BackgroundColor3 = colors.button
        ScanBtn.BorderColor3 = colors.border
        ScanBtn.BorderSizePixel = 1
        ScanBtn.Position = UDim2.new(0, 295, 0, 7)
        ScanBtn.Size = UDim2.new(0, 80, 0, 24)
        ScanBtn.Text = "SCAN"
        
        local ScanAllBtn = Instance.new("TextButton")
        ScanAllBtn.Parent = ExplorerToolBar
        ScanAllBtn.BackgroundColor3 = colors.success
        ScanAllBtn.BorderColor3 = colors.border
        ScanAllBtn.BorderSizePixel = 1
        ScanAllBtn.Position = UDim2.new(0, 385, 0, 7)
        ScanAllBtn.Size = UDim2.new(0, 100, 0, 24)
        ScanAllBtn.Text = "SCAN ALL"
        
        local ExportBtn = Instance.new("TextButton")
        ExportBtn.Parent = ExplorerToolBar
        ExportBtn.BackgroundColor3 = colors.button
        ExportBtn.BorderColor3 = colors.border
        ExportBtn.BorderSizePixel = 1
        ExportBtn.Position = UDim2.new(0, 495, 0, 7)
        ExportBtn.Size = UDim2.new(0, 80, 0, 24)
        ExportBtn.Text = "EXPORT JSON"
        
        local RefreshBtn = Instance.new("TextButton")
        RefreshBtn.Parent = ExplorerToolBar
        RefreshBtn.BackgroundColor3 = colors.button
        RefreshBtn.BorderColor3 = colors.border
        RefreshBtn.BorderSizePixel = 1
        RefreshBtn.Position = UDim2.new(0, 585, 0, 7)
        RefreshBtn.Size = UDim2.new(0, 70, 0, 24)
        RefreshBtn.Text = "REFRESH"
        
        local ObjectCountLabel = Instance.new("TextLabel")
        ObjectCountLabel.Parent = ExplorerToolBar
        ObjectCountLabel.BackgroundTransparency = 1
        ObjectCountLabel.Position = UDim2.new(1, -150, 0, 10)
        ObjectCountLabel.Size = UDim2.new(0, 140, 0, 18)
        ObjectCountLabel.Text = "Objects: 0"
        ObjectCountLabel.TextColor3 = colors.textDim
        ObjectCountLabel.TextXAlignment = Enum.TextXAlignment.Right
        
        local Splitter = Instance.new("Frame")
        Splitter.Parent = ExplorerContent
        Splitter.BackgroundColor3 = colors.border
        Splitter.BorderSizePixel = 0
        Splitter.Position = UDim2.new(0, 320, 0, 93)
        Splitter.Size = UDim2.new(0, 1, 1, -103)
        
        local LeftPanel = Instance.new("Frame")
        LeftPanel.Parent = ExplorerContent
        LeftPanel.BackgroundColor3 = colors.explorer
        LeftPanel.BorderColor3 = colors.border
        LeftPanel.BorderSizePixel = 1
        LeftPanel.Position = UDim2.new(0, 5, 0, 93)
        LeftPanel.Size = UDim2.new(0, 310, 1, -103)
        
        local ExplorerTitle = Instance.new("TextLabel")
        ExplorerTitle.Parent = LeftPanel
        ExplorerTitle.BackgroundTransparency = 1
        ExplorerTitle.Position = UDim2.new(0, 5, 0, 5)
        ExplorerTitle.Size = UDim2.new(1, -10, 0, 20)
        ExplorerTitle.Text = "▸ Object Explorer"
        ExplorerTitle.TextXAlignment = Enum.TextXAlignment.Left
        
        local ExplorerList = Instance.new("ScrollingFrame")
        ExplorerList.Parent = LeftPanel
        ExplorerList.BackgroundColor3 = colors.bg
        ExplorerList.BorderColor3 = colors.border
        ExplorerList.BorderSizePixel = 1
        ExplorerList.Position = UDim2.new(0, 5, 0, 28)
        ExplorerList.Size = UDim2.new(1, -10, 1, -38)
        ExplorerList.ScrollBarThickness = 10
        
        local RightPanel = Instance.new("Frame")
        RightPanel.Parent = ExplorerContent
        RightPanel.BackgroundColor3 = colors.panel
        RightPanel.BorderColor3 = colors.border
        RightPanel.BorderSizePixel = 1
        RightPanel.Position = UDim2.new(0, 330, 0, 93)
        RightPanel.Size = UDim2.new(1, -340, 1, -103)
        
        local ResultsTitle = Instance.new("TextLabel")
        ResultsTitle.Parent = RightPanel
        ResultsTitle.BackgroundTransparency = 1
        ResultsTitle.Position = UDim2.new(0, 5, 0, 5)
        ResultsTitle.Size = UDim2.new(1, -10, 0, 20)
        ResultsTitle.Text = "▸ Search Results"
        ResultsTitle.TextXAlignment = Enum.TextXAlignment.Left
        
        local ResultsList = Instance.new("ScrollingFrame")
        ResultsList.Parent = RightPanel
        ResultsList.BackgroundColor3 = colors.bg
        ResultsList.BorderColor3 = colors.border
        ResultsList.BorderSizePixel = 1
        ResultsList.Position = UDim2.new(0, 5, 0, 28)
        ResultsList.Size = UDim2.new(1, -10, 0.5, -35)
        ResultsList.ScrollBarThickness = 10
        
        local PropsTitle = Instance.new("TextLabel")
        PropsTitle.Parent = RightPanel
        PropsTitle.BackgroundTransparency = 1
        PropsTitle.Position = UDim2.new(0, 5, 0, 0.5, 5)
        PropsTitle.Size = UDim2.new(1, -10, 0, 20)
        PropsTitle.Text = "▸ Object Properties"
        PropsTitle.TextXAlignment = Enum.TextXAlignment.Left
        
        local PropsList = Instance.new("ScrollingFrame")
        PropsList.Parent = RightPanel
        PropsList.BackgroundColor3 = colors.bg
        PropsList.BorderColor3 = colors.border
        PropsList.BorderSizePixel = 1
        PropsList.Position = UDim2.new(0, 5, 0, 0.5, 28)
        PropsList.Size = UDim2.new(1, -10, 0.45, -38)
        PropsList.ScrollBarThickness = 10
        
        local ActionBar = Instance.new("Frame")
        ActionBar.Parent = ExplorerContent
        ActionBar.BackgroundColor3 = colors.title
        ActionBar.BorderColor3 = colors.border
        ActionBar.BorderSizePixel = 1
        ActionBar.Position = UDim2.new(0, 0, 1, -42)
        ActionBar.Size = UDim2.new(1, 0, 0, 42)
        
        local CopyBtn = Instance.new("TextButton")
        CopyBtn.Parent = ActionBar
        CopyBtn.BackgroundColor3 = colors.button
        CopyBtn.BorderColor3 = colors.border
        CopyBtn.BorderSizePixel = 1
        CopyBtn.Position = UDim2.new(0, 5, 0, 6)
        CopyBtn.Size = UDim2.new(0, 70, 0, 30)
        CopyBtn.Text = "COPY"
        
        local PasteBtn = Instance.new("TextButton")
        PasteBtn.Parent = ActionBar
        PasteBtn.BackgroundColor3 = colors.button
        PasteBtn.BorderColor3 = colors.border
        PasteBtn.BorderSizePixel = 1
        PasteBtn.Position = UDim2.new(0, 80, 0, 6)
        PasteBtn.Size = UDim2.new(0, 70, 0, 30)
        PasteBtn.Text = "PASTE"
        
        local DeleteBtn = Instance.new("TextButton")
        DeleteBtn.Parent = ActionBar
        DeleteBtn.BackgroundColor3 = colors.button
        DeleteBtn.BorderColor3 = colors.border
        DeleteBtn.BorderSizePixel = 1
        DeleteBtn.Position = UDim2.new(0, 155, 0, 6)
        DeleteBtn.Size = UDim2.new(0, 70, 0, 30)
        DeleteBtn.Text = "DELETE"
        
        local RenameBtn = Instance.new("TextButton")
        RenameBtn.Parent = ActionBar
        RenameBtn.BackgroundColor3 = colors.button
        RenameBtn.BorderColor3 = colors.border
        RenameBtn.BorderSizePixel = 1
        RenameBtn.Position = UDim2.new(0, 230, 0, 6)
        RenameBtn.Size = UDim2.new(0, 70, 0, 30)
        RenameBtn.Text = "RENAME"
        
        local ViewScriptBtn = Instance.new("TextButton")
        ViewScriptBtn.Parent = ActionBar
        ViewScriptBtn.BackgroundColor3 = colors.button
        ViewScriptBtn.BorderColor3 = colors.border
        ViewScriptBtn.BorderSizePixel = 1
        ViewScriptBtn.Position = UDim2.new(0, 305, 0, 6)
        ViewScriptBtn.Size = UDim2.new(0, 90, 0, 30)
        ViewScriptBtn.Text = "VIEW SCRIPT"
        
        local ApplyPropBtn = Instance.new("TextButton")
        ApplyPropBtn.Parent = ActionBar
        ApplyPropBtn.BackgroundColor3 = colors.button
        ApplyPropBtn.BorderColor3 = colors.border
        ApplyPropBtn.BorderSizePixel = 1
        ApplyPropBtn.Position = UDim2.new(1, -160, 0, 6)
        ApplyPropBtn.Size = UDim2.new(0, 70, 0, 30)
        ApplyPropBtn.Text = "APPLY"
        
        local MoveBtn = Instance.new("TextButton")
        MoveBtn.Parent = ActionBar
        MoveBtn.BackgroundColor3 = colors.button
        MoveBtn.BorderColor3 = colors.border
        MoveBtn.BorderSizePixel = 1
        MoveBtn.Position = UDim2.new(1, -85, 0, 6)
        MoveBtn.Size = UDim2.new(0, 70, 0, 30)
        MoveBtn.Text = "MOVE"
        
        local RenameBox = Instance.new("TextBox")
        RenameBox.Parent = MainFrame
        RenameBox.BackgroundColor3 = colors.bg
        RenameBox.BorderColor3 = colors.border
        RenameBox.BorderSizePixel = 1
        RenameBox.Size = UDim2.new(0, 200, 0, 24)
        RenameBox.Visible = false
        
        local MoveBox = Instance.new("TextBox")
        MoveBox.Parent = MainFrame
        MoveBox.BackgroundColor3 = colors.bg
        MoveBox.BorderColor3 = colors.border
        MoveBox.BorderSizePixel = 1
        MoveBox.Size = UDim2.new(0, 200, 0, 24)
        MoveBox.Visible = false
        MoveBox.PlaceholderText = "Target parent name..."
        
        local PropNameBox = Instance.new("TextBox")
        PropNameBox.Parent = MainFrame
        PropNameBox.BackgroundColor3 = colors.bg
        PropNameBox.BorderColor3 = colors.border
        PropNameBox.BorderSizePixel = 1
        PropNameBox.Size = UDim2.new(0, 150, 0, 24)
        PropNameBox.Visible = false
        PropNameBox.PlaceholderText = "Property name..."
        
        local PropValueBox = Instance.new("TextBox")
        PropValueBox.Parent = MainFrame
        PropValueBox.BackgroundColor3 = colors.bg
        PropValueBox.BorderColor3 = colors.border
        PropValueBox.BorderSizePixel = 1
        PropValueBox.Size = UDim2.new(0, 150, 0, 24)
        PropValueBox.Visible = false
        PropValueBox.PlaceholderText = "New value..."
        
        local StatusBar = Instance.new("Frame")
        StatusBar.Parent = MainFrame
        StatusBar.BackgroundColor3 = colors.title
        StatusBar.BorderColor3 = colors.border
        StatusBar.BorderSizePixel = 1
        StatusBar.Position = UDim2.new(0, 0, 1, -26)
        StatusBar.Size = UDim2.new(1, 0, 0, 26)
        
        local StatusText = Instance.new("TextLabel")
        StatusText.Parent = StatusBar
        StatusText.BackgroundTransparency = 1
        StatusText.Position = UDim2.new(0, 8, 0, 4)
        StatusText.Size = UDim2.new(1, -16, 0, 18)
        StatusText.Text = "Ready | Click SCAN ALL to load object tree"
        StatusText.TextColor3 = colors.textDim
        StatusText.TextSize = 10
        
        local function updateStatus(msg, isError)
            StatusText.Text = msg
            if isError then
                StatusText.TextColor3 = colors.error
            else
                StatusText.TextColor3 = colors.textDim
            end
            task.wait(2)
            StatusText.TextColor3 = colors.textDim
            StatusText.Text = "Ready | " .. (#allObjectsList > 0 and #allObjectsList .. " objects loaded" or "Click SCAN ALL to load objects")
        end
        
        local function renderExplorerTree()
            for _, child in ipairs(ExplorerList:GetChildren()) do
                if child:IsA("TextButton") then
                    child:Destroy()
                end
            end
            
            local function renderNode(node, depth, yOffset)
                local btn = Instance.new("TextButton")
                btn.Parent = ExplorerList
                btn.BackgroundColor3 = colors.bg
                btn.BorderColor3 = colors.border
                btn.BorderSizePixel = 1
                btn.Size = UDim2.new(1, -5, 0, 22)
                btn.Position = UDim2.new(0, 2, 0, yOffset)
                local prefix = string.rep("  ", depth)
                if #node.children > 0 then
                    prefix = prefix .. (node.expanded and "▼ " or "▶ ")
                else
                    prefix = prefix .. "  "
                end
                btn.Text = prefix .. node.name .. " (" .. node.class .. ")"
                btn.TextColor3 = colors.text
                btn.TextSize = 10
                btn.TextXAlignment = Enum.TextXAlignment.Left
                
                btn.MouseButton1Click:Connect(function()
                    selectedObject = node.obj
                    node.expanded = not node.expanded
                    expandedNodes[node.obj] = node.expanded
                    renderExplorerTree()
                    renderProperties(node.obj)
                    updateStatus("Selected: " .. node.name)
                end)
                
                local newY = yOffset + 24
                
                if node.expanded then
                    for _, child in ipairs(node.children) do
                        newY = renderNode(child, depth + 1, newY)
                    end
                end
                
                return newY
            end
            
            local yPos = 0
            for _, root in ipairs(objectTree) do
                yPos = renderNode(root, 0, yPos)
            end
            
            ExplorerList.CanvasSize = UDim2.new(0, 0, 0, yPos + 10)
        end
        
        local function renderResults(results)
            for _, child in ipairs(ResultsList:GetChildren()) do
                if child:IsA("TextButton") then
                    child:Destroy()
                end
            end
            
            local yOffset = 0
            for _, node in ipairs(results) do
                local btn = Instance.new("TextButton")
                btn.Parent = ResultsList
                btn.BackgroundColor3 = colors.bg
                btn.BorderColor3 = colors.border
                btn.BorderSizePixel = 1
                btn.Size = UDim2.new(1, -5, 0, 22)
                btn.Position = UDim2.new(0, 2, 0, yOffset)
                btn.Text = node.name .. " (" .. node.class .. ")"
                btn.TextColor3 = colors.text
                btn.TextSize = 10
                btn.TextXAlignment = Enum.TextXAlignment.Left
                
                btn.MouseButton1Click:Connect(function()
                    selectedObject = node.obj
                    renderProperties(node.obj)
                    updateStatus("Selected: " .. node.name)
                end)
                
                yOffset = yOffset + 24
            end
            
            ResultsList.CanvasSize = UDim2.new(0, 0, 0, yOffset + 10)
        end
        
        local function renderProperties(obj)
            for _, child in ipairs(PropsList:GetChildren()) do
                if child:IsA("TextButton") then
                    child:Destroy()
                end
            end
            
            if not obj then return end
            
            local yOffset = 0
            local props = {}
            
            table.insert(props, {"Name", obj.Name, "string"})
            table.insert(props, {"ClassName", obj.ClassName, "string"})
            table.insert(props, {"Parent", obj.Parent and obj.Parent.Name or "nil", "string"})
            table.insert(props, {"Archivable", tostring(obj.Archivable), "bool"})
            
            if obj:IsA("BasePart") then
                table.insert(props, {"Position", string.format("%.2f, %.2f, %.2f", obj.Position.X, obj.Position.Y, obj.Position.Z), "Vector3"})
                table.insert(props, {"Size", string.format("%.2f, %.2f, %.2f", obj.Size.X, obj.Size.Y, obj.Size.Z), "Vector3"})
                table.insert(props, {"Anchored", tostring(obj.Anchored), "bool"})
            end
            
            if obj:IsA("NumberValue") or obj:IsA("IntValue") then
                table.insert(props, {"Value", tostring(obj.Value), "number"})
            elseif obj:IsA("StringValue") then
                table.insert(props, {"Value", obj.Value, "string"})
            elseif obj:IsA("BoolValue") then
                table.insert(props, {"Value", tostring(obj.Value), "bool"})
            end
            
            if obj:IsA("LocalScript") or obj:IsA("ModuleScript") or obj:IsA("Script") then
                table.insert(props, {"Script", "[Click VIEW SCRIPT to see source]", "script"})
            end
            
            for _, prop in ipairs(props) do
                local nameBtn = Instance.new("TextButton")
                nameBtn.Parent = PropsList
                nameBtn.BackgroundColor3 = colors.bg
                nameBtn.BorderColor3 = colors.border
                nameBtn.BorderSizePixel = 1
                nameBtn.Size = UDim2.new(0.35, -3, 0, 20)
                nameBtn.Position = UDim2.new(0, 2, 0, yOffset)
                nameBtn.Text = prop[1] .. ":"
                nameBtn.TextColor3 = colors.textDim
                nameBtn.TextSize = 10
                nameBtn.TextXAlignment = Enum.TextXAlignment.Right
                
                local valBtn = Instance.new("TextButton")
                valBtn.Parent = PropsList
                valBtn.BackgroundColor3 = colors.bg
                valBtn.BorderColor3 = colors.border
                valBtn.BorderSizePixel = 1
                valBtn.Size = UDim2.new(0.65, -3, 0, 20)
                valBtn.Position = UDim2.new(0.35, 2, 0, yOffset)
                valBtn.Text = prop[2]
                valBtn.TextColor3 = colors.text
                valBtn.TextSize = 10
                valBtn.TextXAlignment = Enum.TextXAlignment.Left
                
                yOffset = yOffset + 22
            end
            
            PropsList.CanvasSize = UDim2.new(0, 0, 0, yOffset + 10)
        end
        
        local function refreshAll()
            updateStatus("Building object tree...")
            local count = buildFullTree()
            renderExplorerTree()
            ObjectCountLabel.Text = "Objects: " .. count
            updateStatus("Loaded " .. count .. " objects")
        end
        
        local function copyObject(obj)
            clipboard = obj:Clone()
            return true
        end
        
        local function pasteObject(parent)
            if clipboard then
                local newObj = clipboard:Clone()
                newObj.Parent = parent
                return newObj
            end
            return nil
        end
        
        local function applyToObject(obj, action, value)
            if not obj then return false end
            
            if action == "Rename" then
                pcall(function() obj.Name = value end)
                return true
            elseif action == "Move" then
                local target = workspace:FindFirstChild(value) or game:FindFirstChild(value)
                if target then
                    pcall(function() obj.Parent = target end)
                    return true
                end
            elseif action == "Delete" then
                pcall(function() obj:Destroy() end)
                return true
            elseif action == "SetProperty" then
                local propName, propValue = value[1], value[2]
                pcall(function() obj[propName] = propValue end)
                return true
            end
            return false
        end
        
        ScanAllBtn.MouseButton1Click:Connect(refreshAll)
        
        ScanBtn.MouseButton1Click:Connect(function()
            local searchTerm = SearchBox.Text
            local searchType = SearchTypeBox.Text
            
            if searchTerm == "" then
                updateStatus("ERROR: Enter search term", true)
                return
            end
            
            if #allObjectsList == 0 then
                updateStatus("ERROR: Click SCAN ALL first", true)
                return
            end
            
            updateStatus("Scanning for: " .. searchTerm)
            local results = searchObjects(searchTerm, searchType)
            renderResults(results)
            updateStatus("Found " .. #results .. " objects")
        end)
        
        ExportBtn.MouseButton1Click:Connect(function()
            if #allObjectsList == 0 then
                updateStatus("ERROR: Click SCAN ALL first", true)
                return
            end
            local json = exportToJSON()
            updateStatus("Exported " .. #allObjectsList .. " objects to clipboard")
        end)
        
        RefreshBtn.MouseButton1Click:Connect(refreshAll)
        
        CopyBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                copyObject(selectedObject)
                updateStatus("Copied: " .. selectedObject.Name)
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        PasteBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                local newObj = pasteObject(selectedObject)
                if newObj then
                    refreshAll()
                    updateStatus("Pasted as: " .. newObj.Name)
                else
                    updateStatus("ERROR: Nothing to paste", true)
                end
            else
                updateStatus("ERROR: Select target parent", true)
            end
        end)
        
        DeleteBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                local name = selectedObject.Name
                if applyToObject(selectedObject, "Delete") then
                    selectedObject = nil
                    refreshAll()
                    updateStatus("Deleted: " .. name)
                end
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        RenameBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                RenameBox.Text = selectedObject.Name
                RenameBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 400, 0, MainFrame.AbsolutePosition.Y + 300)
                RenameBox.Visible = true
                RenameBox:CaptureFocus()
                
                local focusConnection
                focusConnection = RenameBox.FocusLost:Connect(function()
                    if RenameBox.Text ~= "" and RenameBox.Text ~= selectedObject.Name then
                        applyToObject(selectedObject, "Rename", RenameBox.Text)
                        refreshAll()
                        updateStatus("Renamed to: " .. RenameBox.Text)
                    end
                    RenameBox.Visible = false
                    focusConnection:Disconnect()
                end)
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        ViewScriptBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                viewScript(selectedObject)
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        MoveBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                MoveBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 400, 0, MainFrame.AbsolutePosition.Y + 300)
                MoveBox.Visible = true
                MoveBox:CaptureFocus()
                
                local focusConnection
                focusConnection = MoveBox.FocusLost:Connect(function()
                    if MoveBox.Text ~= "" then
                        if applyToObject(selectedObject, "Move", MoveBox.Text) then
                            refreshAll()
                            updateStatus("Moved to: " .. MoveBox.Text)
                        else
                            updateStatus("ERROR: Target not found", true)
                        end
                    end
                    MoveBox.Visible = false
                    focusConnection:Disconnect()
                end)
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        ApplyPropBtn.MouseButton1Click:Connect(function()
            if selectedObject then
                PropNameBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 200, 0, MainFrame.AbsolutePosition.Y + 250)
                PropValueBox.Position = UDim2.new(0, MainFrame.AbsolutePosition.X + 360, 0, MainFrame.AbsolutePosition.Y + 250)
                PropNameBox.Visible = true
                PropValueBox.Visible = true
                PropNameBox:CaptureFocus()
                
                local function applyProperty()
                    local propName = PropNameBox.Text
                    local propValue = PropValueBox.Text
                    
                    if propName ~= "" then
                        local converted
                        if propValue:match("^%d+$") then
                            converted = tonumber(propValue)
                        elseif propValue == "true" then
                            converted = true
                        elseif propValue == "false" then
                            converted = false
                        elseif propValue:match("^%d+%.%d+%.%d+$") then
                            local parts = {propValue:match("([^,]+),([^,]+),([^,]+)")}
                            if #parts == 3 then
                                converted = Vector3.new(tonumber(parts[1]), tonumber(parts[2]), tonumber(parts[3]))
                            end
                        else
                            converted = propValue
                        end
                        
                        if applyToObject(selectedObject, "SetProperty", {propName, converted}) then
                            refreshAll()
                            updateStatus("Property set: " .. propName .. " = " .. propValue)
                        else
                            updateStatus("ERROR: Failed to set property", true)
                        end
                    end
                    PropNameBox.Visible = false
                    PropValueBox.Visible = false
                end
                
                local focusConnection1, focusConnection2
                focusConnection1 = PropNameBox.FocusLost:Connect(applyProperty)
                focusConnection2 = PropValueBox.FocusLost:Connect(applyProperty)
            else
                updateStatus("ERROR: No object selected", true)
            end
        end)
        
        local function addHover(btn)
            local orig = btn.BackgroundColor3
            btn.MouseEnter:Connect(function()
                btn.BackgroundColor3 = colors.highlight
            end)
            btn.MouseLeave:Connect(function()
                btn.BackgroundColor3 = orig
            end)
        end
        
        local btns = {ScanBtn, ScanAllBtn, ExportBtn, RefreshBtn, CopyBtn, PasteBtn, DeleteBtn, RenameBtn, ViewScriptBtn, MoveBtn, ApplyPropBtn}
        for _, btn in ipairs(btns) do
            addHover(btn)
        end
        
        refreshAll()
    end
    
    local tabs = {}
    local function createTab(name, callback)
        local btn = Instance.new("TextButton")
        btn.Parent = TabBar
        btn.BackgroundTransparency = 1
        btn.Position = UDim2.new(0, (#tabs) * 90 + 5, 0, 4)
        btn.Size = UDim2.new(0, 85, 0, 24)
        btn.Text = name
        btn.TextColor3 = colors.textDim
        btn.TextSize = 11
        btn.BorderSizePixel = 0
        
        btn.MouseButton1Click:Connect(function()
            for _, tab in pairs(tabs) do
                if tab.content then tab.content.Visible = false end
                tab.btn.TextColor3 = colors.textDim
                tab.btn.BackgroundTransparency = 1
            end
            callback()
            btn.TextColor3 = colors.text
            btn.BackgroundColor3 = colors.bg
            btn.BackgroundTransparency = 0
        end)
        
        table.insert(tabs, {btn = btn, name = name, content = nil, callback = callback})
        return btn
    end
    
    createTab("Explorer", function()
        ExplorerContent.Visible = true
        ExecutorContent.Visible = false
        MemoryContent.Visible = false
    end)
    
    createTab("Executor", function()
        ExplorerContent.Visible = false
        ExecutorContent.Visible = true
        MemoryContent.Visible = false
        if #ExecutorContent:GetChildren() == 0 then
            buildExecutorUI(ExecutorContent)
        end
    end)
    
    createTab("Memory Scan", function()
        ExplorerContent.Visible = false
        ExecutorContent.Visible = false
        MemoryContent.Visible = true
        if #MemoryContent:GetChildren() == 0 then
            buildMemoryUI(MemoryContent)
        end
    end)
    
    detectInjectionType()
    buildExplorerUI()
    
    local function updateStatus(msg, isError)
        local statusBar = MainFrame:FindFirstChild("StatusBar")
        if statusBar and statusBar.StatusText then
            statusBar.StatusText.Text = msg
            if isError then
                statusBar.StatusText.TextColor3 = colors.error
            end
            task.wait(2)
            statusBar.StatusText.TextColor3 = colors.textDim
        end
    end
end)()