local Players = game:GetService("Players")
local player = Players.LocalPlayer
local gui = Instance.new("ScreenGui", player:WaitForChild("PlayerGui"))
gui.Name = "Exploit"

-- Main Frame
local frame = Instance.new("Frame", gui)
frame.Size = UDim2.new(0, 400, 0, 300)
frame.Position = UDim2.new(0.5, -200, 0.5, -150)
frame.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
frame.BorderSizePixel = 0
frame.Active = true
frame.Draggable = true

-- Title
local title = Instance.new("TextLabel", frame)
title.Size = UDim2.new(1, 0, 0, 30)
title.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
title.Text = "Exploit 0.1 | By: TIMOHA9399"
title.TextColor3 = Color3.new(1, 1, 1)
title.Font = Enum.Font.SourceSansBold
title.TextSize = 18

-- Script TextBox
local box = Instance.new("TextBox", frame)
box.Size = UDim2.new(1, -20, 0, 150)
box.Position = UDim2.new(0, 10, 0, 40)
box.Text = "-- Paste your Lua script here"
box.ClearTextOnFocus = false
box.TextWrapped = true
box.TextYAlignment = Enum.TextYAlignment.Top
box.Font = Enum.Font.Code
box.TextSize = 14
box.MultiLine = true
box.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
box.TextColor3 = Color3.new(1, 1, 1)

-- Buttons
local injectBtn = Instance.new("TextButton", frame)
injectBtn.Size = UDim2.new(0, 120, 0, 30)
injectBtn.Position = UDim2.new(0, 10, 0, 200)
injectBtn.Text = "Inject"
injectBtn.Font = Enum.Font.SourceSansBold
injectBtn.TextSize = 16
injectBtn.BackgroundColor3 = Color3.fromRGB(0, 120, 215)
injectBtn.TextColor3 = Color3.new(1, 1, 1)

local runBtn = Instance.new("TextButton", frame)
runBtn.Size = UDim2.new(0, 120, 0, 30)
runBtn.Position = UDim2.new(0, 140, 0, 200)
runBtn.Text = "Run Script"
runBtn.Font = Enum.Font.SourceSansBold
runBtn.TextSize = 16
runBtn.BackgroundColor3 = Color3.fromRGB(0, 200, 0)
runBtn.TextColor3 = Color3.new(1, 1, 1)

local clearBtn = Instance.new("TextButton", frame)
clearBtn.Size = UDim2.new(0, 120, 0, 30)
clearBtn.Position = UDim2.new(0, 270, 0, 200)
clearBtn.Text = "Clear"
clearBtn.Font = Enum.Font.SourceSansBold
clearBtn.TextSize = 16
clearBtn.BackgroundColor3 = Color3.fromRGB(200, 50, 0)
clearBtn.TextColor3 = Color3.new(1, 1, 1)

local closeBtn = Instance.new("TextButton", frame)
closeBtn.Size = UDim2.new(1, -20, 0, 30)
closeBtn.Position = UDim2.new(0, 10, 0, 240)
closeBtn.Text = "Close"
closeBtn.Font = Enum.Font.SourceSansBold
closeBtn.TextSize = 16
closeBtn.BackgroundColor3 = Color3.fromRGB(100, 0, 0)
closeBtn.TextColor3 = Color3.new(1, 1, 1)

-- Inject logic
injectBtn.MouseButton1Click:Connect(function()
	local waitFrame = Instance.new("Frame", gui)
	waitFrame.Size = UDim2.new(0, 300, 0, 100)
	waitFrame.Position = UDim2.new(0.5, -150, 0.5, -50)
	waitFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
	waitFrame.BorderSizePixel = 0

	local label = Instance.new("TextLabel", waitFrame)
	label.Size = UDim2.new(1, 0, 1, 0)
	label.Text = "Please wait, injecting..."
	label.TextColor3 = Color3.new(1, 1, 1)
	label.Font = Enum.Font.SourceSansBold
	label.TextSize = 18
	label.BackgroundTransparency = 1

	task.wait(8)

	label.Text = "✅ Successfully Injected!"
	label.TextColor3 = Color3.fromRGB(0, 255, 0)

	task.wait(2)
	waitFrame:Destroy()
end)

-- Run script logic
runBtn.MouseButton1Click:Connect(function()
	local code = box.Text
	local func, err = loadstring(code)
	if func then
		pcall(func)
	else
		warn("Script error: "..err)
	end
end)

-- Clear textbox
clearBtn.MouseButton1Click:Connect(function()
	box.Text = ""
end)

-- Close GUI
closeBtn.MouseButton1Click:Connect(function()
	gui:Destroy()
end)