--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- Avatar Morph
-- Open Source © KuramaMods
loadstring(game:HttpGet("https://pastebin.com/raw/gHRQLic7"))()