local player = game.Players.LocalPlayer

local function respawnNow()
    if player.Character then
        local humanoid = player.Character:FindFirstChild("Humanoid")
        if humanoid then
            humanoid.Health = 0
        else
            player.Character:BreakJoints()
        end
    else
        player:LoadCharacter()
    end
end

respawnNow()

player.CharacterAdded:Connect(function(character)
    task.wait(0.5)
    
    local spawnLocation = workspace:FindFirstChild("SpawnLocation")
    if spawnLocation and character.PrimaryPart then
        character:SetPrimaryPartCFrame(spawnLocation.CFrame)
    end
end)