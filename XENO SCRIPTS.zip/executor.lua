local player = game.Players.LocalPlayer
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "AdvancedExecutor"
screenGui.Parent = player:WaitForChild("PlayerGui")

-- Переменная для отслеживания состояния окна
local isMinimized = false
local originalSize = UDim2.new(0, 500, 0, 400)
local minimizedSize = UDim2.new(0, 500, 0, 35) -- Только заголовок

-- Основное окно с закругленными углами
local mainFrame = Instance.new("Frame")
mainFrame.Size = originalSize
mainFrame.Position = UDim2.new(0.5, -250, 0.5, -200)
mainFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

-- Создаем закругленные углы
local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 8)
corner.Parent = mainFrame

-- Заголовок
local titleBar = Instance.new("Frame")
titleBar.Size = UDim2.new(1, 0, 0, 35)
titleBar.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
titleBar.BorderSizePixel = 0
titleBar.Parent = mainFrame

-- Обрезаем верхние углы
local titleBarCorner = Instance.new("UICorner")
titleBarCorner.CornerRadius = UDim.new(0, 8)
titleBarCorner.Parent = titleBar

local titleText = Instance.new("TextLabel")
titleText.Size = UDim2.new(1, -120, 1, 0) -- Оставляем место для кнопок
titleText.Position = UDim2.new(0, 15, 0, 0)
titleText.BackgroundTransparency = 1
titleText.Text = "⚡ Script Executor"
titleText.TextColor3 = Color3.fromRGB(255, 255, 255)
titleText.TextXAlignment = Enum.TextXAlignment.Left
titleText.Font = Enum.Font.GothamSemibold
titleText.TextSize = 18
titleText.Parent = titleBar

-- Панель кнопок справа в заголовке
local buttonPanel = Instance.new("Frame")
buttonPanel.Size = UDim2.new(0, 90, 1, 0)
buttonPanel.Position = UDim2.new(1, -95, 0, 0)
buttonPanel.BackgroundTransparency = 1
buttonPanel.Parent = titleBar

-- Кнопка сворачивания/разворачивания
local minimizeButton = Instance.new("TextButton")
minimizeButton.Size = UDim2.new(0, 35, 0, 35)
minimizeButton.Position = UDim2.new(0, 0, 0, 0)
minimizeButton.BackgroundColor3 = Color3.fromRGB(80, 80, 80)
minimizeButton.Text = "−"
minimizeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
minimizeButton.Font = Enum.Font.GothamBold
minimizeButton.TextSize = 24
minimizeButton.Parent = buttonPanel

local minimizeCorner = Instance.new("UICorner")
minimizeCorner.CornerRadius = UDim.new(0, 8)
minimizeCorner.Parent = minimizeButton

-- Кнопка закрытия
local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 35, 0, 35)
closeButton.Position = UDim2.new(1, -35, 0, 0)
closeButton.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
closeButton.Text = "✕"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.Font = Enum.Font.GothamBold
closeButton.TextSize = 20
closeButton.Parent = buttonPanel

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 8)
closeCorner.Parent = closeButton

-- Поле для ввода с подсветкой синтаксиса
local scriptBox = Instance.new("TextBox")
scriptBox.Name = "ScriptBox"
scriptBox.Size = UDim2.new(1, -20, 1, -90)
scriptBox.Position = UDim2.new(0, 10, 0, 45)
scriptBox.BackgroundColor3 = Color3.fromRGB(15, 15, 15)
scriptBox.TextColor3 = Color3.fromRGB(0, 255, 100)
scriptBox.PlaceholderColor3 = Color3.fromRGB(100, 100, 100)
scriptBox.PlaceholderText = "-- Введите ваш скрипт здесь (Ctrl+Enter для выполнения)"
scriptBox.Text = ""
scriptBox.TextWrapped = true
scriptBox.TextXAlignment = Enum.TextXAlignment.Left
scriptBox.TextYAlignment = Enum.TextYAlignment.Top
scriptBox.MultiLine = true
scriptBox.ClearTextOnFocus = false
scriptBox.Font = Enum.Font.Code
scriptBox.TextSize = 14
scriptBox.Parent = mainFrame

local boxCorner = Instance.new("UICorner")
boxCorner.CornerRadius = UDim.new(0, 5)
boxCorner.Parent = scriptBox

-- Кнопка Execute
local executeButton = Instance.new("TextButton")
executeButton.Name = "ExecuteButton"
executeButton.Size = UDim2.new(0, 150, 0, 40)
executeButton.Position = UDim2.new(1, -160, 1, -50)
executeButton.BackgroundColor3 = Color3.fromRGB(0, 200, 100)
executeButton.Text = "▶ Execute"
executeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
executeButton.Font = Enum.Font.GothamSemibold
executeButton.TextSize = 16
executeButton.Parent = mainFrame

local executeCorner = Instance.new("UICorner")
executeCorner.CornerRadius = UDim.new(0, 5)
executeCorner.Parent = executeButton

-- Кнопка Clear
local clearButton = Instance.new("TextButton")
clearButton.Name = "ClearButton"
clearButton.Size = UDim2.new(0, 150, 0, 40)
clearButton.Position = UDim2.new(0, 10, 1, -50)
clearButton.BackgroundColor3 = Color3.fromRGB(100, 100, 100)
clearButton.Text = "🗑 Clear"
clearButton.TextColor3 = Color3.fromRGB(255, 255, 255)
clearButton.Font = Enum.Font.GothamSemibold
clearButton.TextSize = 16
clearButton.Parent = mainFrame

local clearCorner = Instance.new("UICorner")
clearCorner.CornerRadius = UDim.new(0, 5)
clearCorner.Parent = clearButton

-- Функция сворачивания/разворачивания
local function toggleMinimize()
    isMinimized = not isMinimized
    
    if isMinimized then
        -- Сворачиваем
        mainFrame.Size = minimizedSize
        minimizeButton.Text = "□" -- Символ разворачивания
        scriptBox.Visible = false
        executeButton.Visible = false
        clearButton.Visible = false
    else
        -- Разворачиваем
        mainFrame.Size = originalSize
        minimizeButton.Text = "−" -- Символ сворачивания
        scriptBox.Visible = true
        executeButton.Visible = true
        clearButton.Visible = true
    end
end

-- Функция выполнения
local function executeScript()
    local scriptText = scriptBox.Text
    if scriptText and scriptText ~= "" then
        local func, err = loadstring(scriptText)
        if func then
            local success, result = pcall(func)
            if not success then
                warn("❌ Ошибка: " .. tostring(result))
                scriptBox.TextColor3 = Color3.fromRGB(255, 100, 100)
                wait(0.5)
                scriptBox.TextColor3 = Color3.fromRGB(0, 255, 100)
            end
        else
            warn("❌ Ошибка синтаксиса: " .. tostring(err))
            scriptBox.TextColor3 = Color3.fromRGB(255, 100, 100)
            wait(0.5)
            scriptBox.TextColor3 = Color3.fromRGB(0, 255, 100)
        end
    end
end

-- Привязываем функции к кнопкам
minimizeButton.MouseButton1Click:Connect(toggleMinimize)
executeButton.MouseButton1Click:Connect(executeScript)
closeButton.MouseButton1Click:Connect(function()
    screenGui:Destroy()
end)

clearButton.MouseButton1Click:Connect(function()
    scriptBox.Text = ""
end)

-- Ctrl+Enter для выполнения
local userInputService = game:GetService("UserInputService")
scriptBox.FocusLost:Connect(function(enterPressed)
    if enterPressed and (userInputService:IsKeyDown(Enum.KeyCode.LeftControl) or userInputService:IsKeyDown(Enum.KeyCode.RightControl)) then
        executeScript()
    end
end)

-- Эффекты наведения на кнопки
local function createHoverEffect(button, normalColor, hoverColor)
    button.MouseEnter:Connect(function()
        button.BackgroundColor3 = hoverColor
    end)
    button.MouseLeave:Connect(function()
        button.BackgroundColor3 = normalColor
    end)
end

createHoverEffect(executeButton, Color3.fromRGB(0, 200, 100), Color3.fromRGB(0, 255, 150))
createHoverEffect(clearButton, Color3.fromRGB(100, 100, 100), Color3.fromRGB(150, 150, 150))
createHoverEffect(closeButton, Color3.fromRGB(200, 50, 50), Color3.fromRGB(255, 100, 100))
createHoverEffect(minimizeButton, Color3.fromRGB(80, 80, 80), Color3.fromRGB(130, 130, 130))

-- Дополнительно: сворачивание по двойному клику на заголовок
titleBar.MouseButton2Click:Connect(toggleMinimize) -- Правый клик
-- Или можно использовать двойной левый клик:
-- titleBar.MouseButton1Click:Connect(function()
--     -- Небольшая задержка для определения двойного клика
-- end)

-- Анимация сворачивания/разворачивания (опционально)
local TweenService = game:GetService("TweenService")

local function smoothToggle()
    local tweenInfo = TweenInfo.new(
        0.2, -- Время анимации
        Enum.EasingStyle.Quad,
        Enum.EasingDirection.Out
    )
    
    if isMinimized then
        -- Разворачиваем
        local goal = {Size = originalSize}
        local tween = TweenService:Create(mainFrame, tweenInfo, goal)
        tween:Play()
        
        -- Показываем элементы после анимации
        tween.Completed:Connect(function()
            scriptBox.Visible = true
            executeButton.Visible = true
            clearButton.Visible = true
        end)
    else
        -- Сворачиваем
        scriptBox.Visible = false
        executeButton.Visible = false
        clearButton.Visible = false
        
        local goal = {Size = minimizedSize}
        local tween = TweenService:Create(mainFrame, tweenInfo, goal)
        tween:Play()
    end
end

-- Заменяем простую функцию на анимированную (раскомментируйте если нужна анимация)
-- minimizeButton.MouseButton1Click:Connect(function()
--     isMinimized = not isMinimized
--     smoothToggle()
--     minimizeButton.Text = isMinimized and "□" or "−"
-- end)