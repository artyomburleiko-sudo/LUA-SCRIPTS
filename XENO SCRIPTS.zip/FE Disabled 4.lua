-- Server script
local physicsService = game:GetService("PhysicsService")

-- Disable FE globally
physicsService.FilteringEnabled = false 

-- Prevent re-enabling
local oldFilteringEnabled = physicsService.FilteringEnabled
physicsService.FilteringEnabled = function()
  warn("Tried to re-enable FE")
  return oldFilteringEnabled
end

-- Disable FE for all new player characters 
game:GetService("Players").PlayerAdded:Connect(function(player)

  local function onCharacterAdded(character)
    setCharacterFiltering(character, false)
  end

  player.CharacterAdded:Connect(onCharacterAdded)

  if player.Character then
    onCharacterAdded(player.Character)
  end
  
end)

-- Client script 
local physicsService = game:GetService("PhysicsService")

-- Disable FE globally
physicsService.FilteringEnabled = false

-- Prevent re-enabling
local oldFilteringEnabled = physicsService.FilteringEnabled 
physicsService.FilteringEnabled = function()
  warn("Tried to re-enable FE")
  return oldFilteringEnabled
end

-- Disable FE on player's character
local character = game.Players.LocalPlayer.Character
if character then
  setCharacterFiltering(character, false)
end

-- Disable FE when character changes
game.Players.LocalPlayer.CharacterAdded:Connect(function(newCharacter)
  setCharacterFiltering(newCharacter, false)  
end)
