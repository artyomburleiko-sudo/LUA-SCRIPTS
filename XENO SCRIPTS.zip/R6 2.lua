local Players = game:GetService("Players")
local player = Players.LocalPlayer

if player.Character then
    local humanoid = player.Character:FindFirstChild("Humanoid")
    if humanoid then
        local animate = player.Character:FindFirstChild("Animate")
        if animate then
            animate.Disabled = true
            wait(0.1)
            animate.Disabled = false
        end
        
        for _, track in pairs(humanoid:GetPlayingAnimationTracks()) do
            track:Stop()
        end
    end
end

player.CharacterAdded:Connect(function(char)
    local humanoid = char:WaitForChild("Humanoid")
    local animate = char:WaitForChild("Animate")
    
    animate.Disabled = true
    wait(0.1)
    animate.Disabled = false
    
    for _, track in pairs(humanoid:GetPlayingAnimationTracks()) do
        track:Stop()
    end
    
    local AnimScript = Instance.new("LocalScript")
    AnimScript.Name = "R6Animations"
    AnimScript.Source = [[
        local char = script.Parent
        local humanoid = char:WaitForChild("Humanoid")
        
        local poses = {
            idle = "rbxassetid://507767764",
            walk = "rbxassetid://507766666",
            run = "rbxassetid://507767872",
            jump = "rbxassetid://507765000",
            fall = "rbxassetid://507767968",
            climb = "rbxassetid://507765644",
            sit = "rbxassetid://507765939"
        }
        
        local anims = {}
        for pose, id in pairs(poses) do
            local anim = Instance.new("Animation")
            anim.AnimationId = id
            anims[pose] = humanoid:LoadAnimation(anim)
        end
        
        humanoid.Running:Connect(function(speed)
            if speed > 0 then
                if speed > 12 then
                    anims.run:Play()
                    anims.walk:Stop()
                else
                    anims.walk:Play()
                    anims.run:Stop()
                end
            else
                anims.walk:Stop()
                anims.run:Stop()
                anims.idle:Play()
            end
        end)
        
        humanoid.Jumping:Connect(function()
            anims.jump:Play()
        end)
        
        humanoid.FreeFalling:Connect(function()
            anims.fall:Play()
        end)
        
        humanoid.Climbing:Connect(function()
            anims.climb:Play()
        end)
        
        humanoid.Seated:Connect(function()
            anims.sit:Play()
        end)
        
        anims.idle:Play()
    ]]
    AnimScript.Parent = char
end)