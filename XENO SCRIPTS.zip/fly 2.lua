--[[
    Fly GUI для HD Admin (LocalScript)
    Вставьте этот скрипт в StarterGui или в инструмент.
    Горячая клавиша для открытия/закрытия: F (или измените на свою)
]]

-- Настройки
local toggleKey = Enum.KeyCode.F -- Клавиша для открытия/закрытия меню
local flySpeed = 50 -- Скорость полета

-- Переменные
local player = game.Players.LocalPlayer
local mouse = player:GetMouse()
local camera = workspace.CurrentCamera
local userInputService = game:GetService("UserInputService")
local tweenService = game:GetService("TweenService")

-- GUI элементы
local screenGui = Instance.new("ScreenGui")
local mainFrame = Instance.new("Frame")
local titleBar = Instance.new("Frame")
local titleText = Instance.new("TextLabel")
local closeButton = Instance.new("TextButton")
local toggleButton = Instance.new("TextButton")
local speedSlider = Instance.new("Frame")
local sliderButton = Instance.new("TextButton")
local speedLabel = Instance.new("TextLabel")

-- Состояние полета
local flying = false
local bodyVelocity = nil
local bodyGyro = nil
local flyConnection = nil
local guiVisible = true

-- Настройка GUI
screenGui.Name = "HDFlyMenu"
screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.ResetOnSpawn = false
screenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

-- Главное окно
mainFrame.Name = "MainFrame"
mainFrame.Parent = screenGui
mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
mainFrame.BorderSizePixel = 0
mainFrame.Position = UDim2.new(0.5, -150, 0.5, -100)
mainFrame.Size = UDim2.new(0, 300, 0, 200)
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Visible = true

-- Стилизация (как в HD Admin)
local uiCorner = Instance.new("UICorner")
uiCorner.CornerRadius = UDim.new(0, 8)
uiCorner.Parent = mainFrame

-- Заголовок
titleBar.Name = "TitleBar"
titleBar.Parent = mainFrame
titleBar.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
titleBar.BorderSizePixel = 0
titleBar.Size = UDim2.new(1, 0, 0, 30)

local titleCorner = Instance.new("UICorner")
titleCorner.CornerRadius = UDim.new(0, 8)
titleCorner.Parent = titleBar

titleText.Name = "TitleText"
titleText.Parent = titleBar
titleText.BackgroundTransparency = 1
titleText.Size = UDim2.new(1, -30, 1, 0)
titleText.Position = UDim2.new(0, 10, 0, 0)
titleText.Text = "Fly Menu"
titleText.TextColor3 = Color3.fromRGB(255, 255, 255)
titleText.TextXAlignment = Enum.TextXAlignment.Left
titleText.Font = Enum.Font.GothamBold
titleText.TextSize = 16

closeButton.Name = "CloseButton"
closeButton.Parent = titleBar
closeButton.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
closeButton.Size = UDim2.new(0, 20, 0, 20)
closeButton.Position = UDim2.new(1, -25, 0, 5)
closeButton.Text = "X"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextScaled = true
closeButton.Font = Enum.Font.GothamBold
closeButton.BorderSizePixel = 0

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 4)
closeCorner.Parent = closeButton

-- Кнопка включения полета
toggleButton.Name = "ToggleButton"
toggleButton.Parent = mainFrame
toggleButton.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
toggleButton.Size = UDim2.new(0.8, 0, 0, 40)
toggleButton.Position = UDim2.new(0.1, 0, 0.25, 0)
toggleButton.Text = "Включить полет"
toggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
toggleButton.Font = Enum.Font.Gotham
toggleButton.TextSize = 16
toggleButton.BorderSizePixel = 0

local toggleCorner = Instance.new("UICorner")
toggleCorner.CornerRadius = UDim.new(0, 6)
toggleCorner.Parent = toggleButton

-- Слайдер скорости
speedSlider.Name = "SpeedSlider"
speedSlider.Parent = mainFrame
speedSlider.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
speedSlider.Size = UDim2.new(0.8, 0, 0, 30)
speedSlider.Position = UDim2.new(0.1, 0, 0.55, 0)
speedSlider.BorderSizePixel = 0

local sliderCorner = Instance.new("UICorner")
sliderCorner.CornerRadius = UDim.new(0, 4)
sliderCorner.Parent = speedSlider

sliderButton.Name = "SliderButton"
sliderButton.Parent = speedSlider
sliderButton.BackgroundColor3 = Color3.fromRGB(100, 100, 255)
sliderButton.Size = UDim2.new(0.1, 0, 1, 0)
sliderButton.Position = UDim2.new(0, 0, 0, 0)
sliderButton.Text = ""
sliderButton.BorderSizePixel = 0
sliderButton.AutoButtonColor = false

local sliderButtonCorner = Instance.new("UICorner")
sliderButtonCorner.CornerRadius = UDim.new(0, 4)
sliderButtonCorner.Parent = sliderButton

speedLabel.Name = "SpeedLabel"
speedLabel.Parent = mainFrame
speedLabel.BackgroundTransparency = 1
speedLabel.Size = UDim2.new(1, 0, 0, 20)
speedLabel.Position = UDim2.new(0, 0, 0.75, 0)
speedLabel.Text = "Скорость: 50"
speedLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
speedLabel.Font = Enum.Font.Gotham
speedLabel.TextSize = 14

-- Функция для включения/выключения полета
local function toggleFly()
	flying = not flying
	
	if flying then
		-- Включаем полет
		local character = player.Character
		if not character or not character:FindFirstChild("HumanoidRootPart") then
			flying = false
			toggleButton.Text = "Включить полет"
			return
		end
		
		local rootPart = character.HumanoidRootPart
		local humanoid = character:FindFirstChildOfClass("Humanoid")
		
		if humanoid then
			humanoid.PlatformStand = true
		end
		
		-- Создаем BodyVelocity и BodyGyro
		bodyVelocity = Instance.new("BodyVelocity")
		bodyVelocity.Velocity = Vector3.new(0, 0, 0)
		bodyVelocity.MaxForce = Vector3.new(4000, 4000, 4000)
		bodyVelocity.Parent = rootPart
		
		bodyGyro = Instance.new("BodyGyro")
		bodyGyro.MaxTorque = Vector3.new(4000, 4000, 4000)
		bodyGyro.P = 1000
		bodyGyro.D = 50
		bodyGyro.CFrame = rootPart.CFrame
		bodyGyro.Parent = rootPart
		
		-- Обновляем текст кнопки
		toggleButton.Text = "Выключить полет"
		toggleButton.BackgroundColor3 = Color3.fromRGB(255, 80, 80)
		
		-- Запускаем обновление полета
		flyConnection = game:GetService("RunService").RenderStepped:Connect(function()
			if not flying or not character or not character.Parent or not rootPart or not rootPart.Parent then
				toggleFly()
				return
			end
			
			local moveDirection = Vector3.new(0, 0, 0)
			
			-- Управление с клавиатуры
			if userInputService:IsKeyDown(Enum.KeyCode.W) then
				moveDirection = moveDirection + camera.CFrame.LookVector
			end
			if userInputService:IsKeyDown(Enum.KeyCode.S) then
				moveDirection = moveDirection - camera.CFrame.LookVector
			end
			if userInputService:IsKeyDown(Enum.KeyCode.A) then
				moveDirection = moveDirection - camera.CFrame.RightVector
			end
			if userInputService:IsKeyDown(Enum.KeyCode.D) then
				moveDirection = moveDirection + camera.CFrame.RightVector
			end
			if userInputService:IsKeyDown(Enum.KeyCode.Space) then
				moveDirection = moveDirection + Vector3.new(0, 1, 0)
			end
			if userInputService:IsKeyDown(Enum.KeyCode.LeftControl) or userInputService:IsKeyDown(Enum.KeyCode.C) then
				moveDirection = moveDirection + Vector3.new(0, -1, 0)
			end
			
			if moveDirection.Magnitude > 0 then
				moveDirection = moveDirection.Unit * flySpeed
			end
			
			bodyVelocity.Velocity = moveDirection
			bodyGyro.CFrame = camera.CFrame
		end)
	else
		-- Выключаем полет
		if flyConnection then
			flyConnection:Disconnect()
			flyConnection = nil
		end
		
		if bodyVelocity then
			bodyVelocity:Destroy()
			bodyVelocity = nil
		end
		
		if bodyGyro then
			bodyGyro:Destroy()
			bodyGyro = nil
		end
		
		local character = player.Character
		if character and character:FindFirstChildOfClass("Humanoid") then
			character.Humanoid.PlatformStand = false
		end
		
		toggleButton.Text = "Включить полет"
		toggleButton.BackgroundColor3 = Color3.fromRGB(60, 60, 60)
	end
end

-- Функция для обновления скорости через слайдер
local function updateSpeedFromSlider(inputPosition)
	local sliderPos = speedSlider.AbsolutePosition.X
	local sliderSize = speedSlider.AbsoluteSize.X
	
	local relativeX = math.clamp(inputPosition - sliderPos, 0, sliderSize)
	local percent = relativeX / sliderSize
	
	-- Устанавливаем скорость от 10 до 200
	flySpeed = math.floor(10 + percent * 190)
	
	-- Обновляем позицию кнопки слайдера
	local newSize = UDim2.new(percent, 0, 1, 0)
	tweenService:Create(sliderButton, TweenInfo.new(0.1), {Size = newSize}):Play()
	
	-- Обновляем текст
	speedLabel.Text = "Скорость: " .. flySpeed
end

-- Обработчики кнопок
closeButton.MouseButton1Click:Connect(function()
	screenGui:Destroy()
end)

toggleButton.MouseButton1Click:Connect(toggleFly)

-- Обработка слайдера
sliderButton.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		local dragConnection
		dragConnection = input.Changed:Connect(function()
			if input.UserInputState == Enum.UserInputState.End then
				dragConnection:Disconnect()
			end
		end)
		
		local moveConnection = userInputService.InputChanged:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseMovement then
				updateSpeedFromSlider(userInputService:GetMouseLocation().X)
			end
		end)
		
		local releaseConnection = userInputService.InputEnded:Connect(function(input)
			if input.UserInputType == Enum.UserInputType.MouseButton1 then
				moveConnection:Disconnect()
				releaseConnection:Disconnect()
			end
		end)
	end
end)

-- Обновление скорости кликом по слайдеру
speedSlider.InputBegan:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1 then
		updateSpeedFromSlider(userInputService:GetMouseLocation().X)
	end
end)

-- Горячая клавиша для открытия/закрытия меню
userInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then return end
	
	if input.KeyCode == toggleKey then
		guiVisible = not guiVisible
		mainFrame.Visible = guiVisible
	end
end)

-- Защита от перезахода (если персонаж умирает)
player.CharacterAdded:Connect(function()
	if flying then
		toggleFly() -- Выключаем полет при смерти
	end
end)

-- Уведомление
wait(1)
if screenGui and screenGui.Parent then
	local notification = Instance.new("Hint")
	notification.Text = "Fly GUI загружен! Нажмите " .. toggleKey.Name .. " для открытия меню."
	notification.Parent = workspace
	game:GetService("Debris"):AddItem(notification, 5)
end