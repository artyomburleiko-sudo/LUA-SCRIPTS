-- GUI для Forsaken - Расширенные функции
-- Безопасные улучшения игрового процесса

local ScreenGui = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local Title = Instance.new("TextLabel")
local ToggleButton = Instance.new("TextButton")
local CloseButton = Instance.new("TextButton")
local UIGradient = Instance.new("UIGradient")
local Shadow = Instance.new("ImageLabel")

-- Создание GUI
ScreenGui.Parent = game.CoreGui
ScreenGui.Name = "ForsakenGUI"
ScreenGui.ResetOnSpawn = false
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

-- Тень для главного окна
Shadow.Parent = ScreenGui
Shadow.Size = UDim2.new(0, 310, 0, 620) -- Увеличил высоту для новой кнопки
Shadow.Position = UDim2.new(0.5, -145, 0.5, -310)
Shadow.BackgroundTransparency = 1
Shadow.Image = "rbxassetid://1316045217"
Shadow.ImageColor3 = Color3.fromRGB(0, 0, 0)
Shadow.ImageTransparency = 0.7
Shadow.Visible = false

-- Основное окно
MainFrame.Parent = ScreenGui
MainFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 30)
MainFrame.Size = UDim2.new(0, 300, 0, 620) -- Увеличил высоту для новой кнопки
MainFrame.Position = UDim2.new(0.5, -150, 0.5, -310)
MainFrame.Active = true
MainFrame.Draggable = true
MainFrame.Visible = false
MainFrame.ClipsDescendants = true

-- Градиент для красоты
UIGradient.Parent = MainFrame
UIGradient.Color = ColorSequence.new({
    ColorSequenceKeypoint.new(0, Color3.fromRGB(35, 35, 50)),
    ColorSequenceKeypoint.new(0.5, Color3.fromRGB(25, 25, 40)),
    ColorSequenceKeypoint.new(1, Color3.fromRGB(15, 15, 30))
})
UIGradient.Rotation = 90

-- Заголовок
Title.Parent = MainFrame
Title.Size = UDim2.new(1, 0, 0, 50)
Title.BackgroundColor3 = Color3.fromRGB(30, 30, 45)
Title.Text = "⚡ FORSAKEN BOOST ⚡"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.Font = Enum.Font.GothamBold
Title.TextSize = 22
Title.TextStrokeTransparency = 0.7
Title.TextStrokeColor3 = Color3.fromRGB(0, 0, 0)

-- Кнопка закрытия
CloseButton.Parent = MainFrame
CloseButton.Size = UDim2.new(0, 35, 0, 35)
CloseButton.Position = UDim2.new(1, -45, 0, 7)
CloseButton.BackgroundColor3 = Color3.fromRGB(200, 50, 50)
CloseButton.Text = "✕"
CloseButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CloseButton.Font = Enum.Font.GothamBold
CloseButton.TextSize = 20
CloseButton.BorderSizePixel = 0

-- Кнопка открытия/закрытия
ToggleButton.Parent = ScreenGui
ToggleButton.Size = UDim2.new(0, 60, 0, 60)
ToggleButton.Position = UDim2.new(0, 20, 0.5, -30)
ToggleButton.BackgroundColor3 = Color3.fromRGB(45, 45, 65)
ToggleButton.Text = "⚡"
ToggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
ToggleButton.Font = Enum.Font.GothamBold
ToggleButton.TextSize = 35
ToggleButton.Draggable = true
ToggleButton.BorderSizePixel = 0

-- Функция для создания красивых кнопок
local function createButton(name, position, color, callback)
    local button = Instance.new("TextButton")
    local buttonGradient = Instance.new("UIGradient")
    local buttonCorner = Instance.new("UICorner")
    
    button.Parent = MainFrame
    button.Size = UDim2.new(0.9, 0, 0, 45)
    button.Position = UDim2.new(0.05, 0, 0, position)
    button.BackgroundColor3 = color or Color3.fromRGB(60, 60, 80)
    button.Text = "  " .. name
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.Font = Enum.Font.GothamSemibold
    button.TextSize = 16
    button.TextXAlignment = Enum.TextXAlignment.Left
    button.BorderSizePixel = 0
    
    buttonCorner.CornerRadius = UDim.new(0, 8)
    buttonCorner.Parent = button
    
    buttonGradient.Parent = button
    buttonGradient.Color = ColorSequence.new({
        ColorSequenceKeypoint.new(0, Color3.fromRGB(80, 80, 100)),
        ColorSequenceKeypoint.new(1, Color3.fromRGB(50, 50, 70))
    })
    buttonGradient.Rotation = 90
    
    button.MouseEnter:Connect(function()
        button.BackgroundColor3 = Color3.fromRGB(100, 100, 120)
        button.TextSize = 17
    end)
    
    button.MouseLeave:Connect(function()
        button.BackgroundColor3 = color or Color3.fromRGB(60, 60, 80)
        button.TextSize = 16
    end)
    
    button.MouseButton1Click:Connect(callback)
    
    return button
end

-- Функция для создания переключателя
local function createToggle(name, position, defaultState, callback)
    local frame = Instance.new("Frame")
    local label = Instance.new("TextLabel")
    local toggle = Instance.new("TextButton")
    local toggleCircle = Instance.new("Frame")
    local corner = Instance.new("UICorner")
    local circleCorner = Instance.new("UICorner")
    
    frame.Parent = MainFrame
    frame.Size = UDim2.new(0.9, 0, 0, 45)
    frame.Position = UDim2.new(0.05, 0, 0, position)
    frame.BackgroundColor3 = Color3.fromRGB(40, 40, 55)
    frame.BackgroundTransparency = 0.5
    corner.CornerRadius = UDim.new(0, 8)
    corner.Parent = frame
    
    label.Parent = frame
    label.Size = UDim2.new(0.7, 0, 1, 0)
    label.BackgroundTransparency = 1
    label.Text = "  " .. name
    label.TextColor3 = Color3.fromRGB(255, 255, 255)
    label.Font = Enum.Font.GothamSemibold
    label.TextSize = 16
    label.TextXAlignment = Enum.TextXAlignment.Left
    
    toggle.Parent = frame
    toggle.Size = UDim2.new(0, 60, 0, 30)
    toggle.Position = UDim2.new(1, -70, 0.5, -15)
    toggle.BackgroundColor3 = defaultState and Color3.fromRGB(100, 200, 100) or Color3.fromRGB(150, 150, 150)
    toggle.Text = ""
    toggle.BorderSizePixel = 0
    toggle.AutoButtonColor = false
    
    local toggleCorner = Instance.new("UICorner")
    toggleCorner.CornerRadius = UDim.new(0, 15)
    toggleCorner.Parent = toggle
    
    toggleCircle.Parent = toggle
    toggleCircle.Size = UDim2.new(0, 26, 0, 26)
    toggleCircle.Position = defaultState and UDim2.new(1, -30, 0.5, -13) or UDim2.new(0, 4, 0.5, -13)
    toggleCircle.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
    circleCorner.CornerRadius = UDim.new(1, 0)
    circleCorner.Parent = toggleCircle
    
    local state = defaultState
    
    toggle.MouseButton1Click:Connect(function()
        state = not state
        toggle.BackgroundColor3 = state and Color3.fromRGB(100, 200, 100) or Color3.fromRGB(150, 150, 150)
        toggleCircle.Position = state and UDim2.new(1, -30, 0.5, -13) or UDim2.new(0, 4, 0.5, -13)
        callback(state)
    end)
    
    return frame
end

-- ========== ПЕРЕМЕННЫЕ ДЛЯ ФУНКЦИЙ ==========

local speedEnabled = false
local jumpEnabled = false
local gravityEnabled = false
local espEnabled = false
local flyEnabled = false
local noclipEnabled = false
local antiresetEnabled = false
local infiniteStaminaEnabled = false
local infiniteHealthEnabled = false
local antibanEnabled = false
local invisibleEnabled = false
local walkspeedValue = 24
local jumpPowerValue = 50

-- ========== ФУНКЦИИ ==========

-- Ускорение
createToggle("🚀 Ускорение (x2)", 60, false, function(state)
    speedEnabled = state
    local player = game.Players.LocalPlayer
    if player.Character and player.Character:FindFirstChild("Humanoid") then
        if state then
            player.Character.Humanoid.WalkSpeed = walkspeedValue * 2
        else
            player.Character.Humanoid.WalkSpeed = walkspeedValue
        end
    end
end)

-- Супер прыжок
createToggle("🦘 Супер прыжок (x2)", 110, false, function(state)
    jumpEnabled = state
    local player = game.Players.LocalPlayer
    if player.Character and player.Character:FindFirstChild("Humanoid") then
        if state then
            player.Character.Humanoid.JumpPower = jumpPowerValue * 2
        else
            player.Character.Humanoid.JumpPower = jumpPowerValue
        end
    end
end)

-- Полёт (Fly)
createToggle("🕊️ Режим полёта", 160, false, function(state)
    flyEnabled = state
    local player = game.Players.LocalPlayer
    local character = player.Character
    if not character then return end
    
    local humanoid = character:FindFirstChild("Humanoid")
    local rootPart = character:FindFirstChild("HumanoidRootPart")
    
    if not humanoid or not rootPart then return end
    
    if state then
        -- Включаем полёт
        humanoid.PlatformStand = true
        
        local bodyGyro = Instance.new("BodyGyro")
        bodyGyro.Parent = rootPart
        bodyGyro.MaxTorque = Vector3.new(400000, 400000, 400000)
        bodyGyro.D = 500
        
        local bodyVelocity = Instance.new("BodyVelocity")
        bodyVelocity.Parent = rootPart
        bodyVelocity.MaxForce = Vector3.new(100000, 100000, 100000)
        bodyVelocity.Velocity = Vector3.new(0, 0, 0)
        
        -- Управление полётом
        local uis = game:GetService("UserInputService")
        local flyConnection
        
        flyConnection = game:GetService("RunService").Heartbeat:Connect(function()
            if not flyEnabled or not character or not character.Parent then
                if flyConnection then flyConnection:Disconnect() end
                return
            end
            
            local moveDirection = Vector3.new()
            local camera = workspace.CurrentCamera
            
            if uis:IsKeyDown(Enum.KeyCode.W) then
                moveDirection = moveDirection + camera.CFrame.LookVector
            end
            if uis:IsKeyDown(Enum.KeyCode.S) then
                moveDirection = moveDirection - camera.CFrame.LookVector
            end
            if uis:IsKeyDown(Enum.KeyCode.A) then
                moveDirection = moveDirection - camera.CFrame.RightVector
            end
            if uis:IsKeyDown(Enum.KeyCode.D) then
                moveDirection = moveDirection + camera.CFrame.RightVector
            end
            if uis:IsKeyDown(Enum.KeyCode.Space) then
                moveDirection = moveDirection + Vector3.new(0, 1, 0)
            end
            if uis:IsKeyDown(Enum.KeyCode.LeftControl) then
                moveDirection = moveDirection - Vector3.new(0, 1, 0)
            end
            
            bodyVelocity.Velocity = moveDirection * (walkspeedValue * 2)
            bodyGyro.CFrame = CFrame.new(rootPart.Position, rootPart.Position + camera.CFrame.LookVector)
        end)
        
    else
        -- Выключаем полёт
        humanoid.PlatformStand = false
        if rootPart:FindFirstChild("BodyGyro") then
            rootPart.BodyGyro:Destroy()
        end
        if rootPart:FindFirstChild("BodyVelocity") then
            rootPart.BodyVelocity:Destroy()
        end
    end
end)

-- Ноклип (прохождение сквозь стены)
createToggle("👻 Ноклип (сквозь стены)", 210, false, function(state)
    noclipEnabled = state
    
    local player = game.Players.LocalPlayer
    local noclipConnection
    
    if state then
        noclipConnection = game:GetService("RunService").Stepped:Connect(function()
            if not noclipEnabled or not player.Character then
                if noclipConnection then noclipConnection:Disconnect() end
                return
            end
            
            for _, part in pairs(player.Character:GetDescendants()) do
                if part:IsA("BasePart") then
                    part.CanCollide = false
                end
            end
        end)
    else
        if noclipConnection then
            noclipConnection:Disconnect()
        end
        if player.Character then
            for _, part in pairs(player.Character:GetDescendants()) do
                if part:IsA("BasePart") then
                    part.CanCollide = true
                end
            end
        end
    end
end)

-- ESP (подсветка игроков)
createToggle("👁️ ESP (подсветка игроков)", 260, false, function(state)
    espEnabled = state
    
    local function createESP(player)
        if player == game.Players.LocalPlayer then return end
        
        local espBox = Instance.new("BoxHandleAdornment")
        espBox.Name = "ESP_" .. player.Name
        espBox.Size = Vector3.new(4, 6, 4)
        espBox.Color3 = Color3.fromRGB(255, 100, 100)
        espBox.Transparency = 0.5
        espBox.AlwaysOnTop = true
        espBox.ZIndex = 5
        espBox.Adornee = player.Character
        
        local espLabel = Instance.new("BillboardGui")
        local textLabel = Instance.new("TextLabel")
        
        if state then
            espBox.Parent = player.Character
            espLabel.Parent = player.Character
        end
    end
    
    for _, player in ipairs(game.Players:GetPlayers()) do
        if player ~= game.Players.LocalPlayer and player.Character then
            if state then
                createESP(player)
            else
                if player.Character then
                    local oldESP = player.Character:FindFirstChild("ESP_" .. player.Name)
                    if oldESP then oldESP:Destroy() end
                end
            end
        end
    end
end)

-- Бесконечная выносливость
createToggle("⚡ Бесконечная выносливость", 310, false, function(state)
    infiniteStaminaEnabled = state
    local player = game.Players.LocalPlayer
    
    if state then
        -- Включаем бесконечную выносливость
        local function setInfiniteStamina(character)
            local humanoid = character:WaitForChild("Humanoid")
            
            -- Отключаем потребление выносливости (для игр где она есть)
            if humanoid:FindFirstChild("Stamina") then
                humanoid.Stamina.Value = 100
                humanoid.Stamina.Changed:Connect(function()
                    if infiniteStaminaEnabled and humanoid.Stamina.Value < 100 then
                        humanoid.Stamina.Value = 100
                    end
                end)
            end
            
            -- Для игр с системой бега (Shift)
            local uis = game:GetService("UserInputService")
            local runConnection
            
            runConnection = game:GetService("RunService").Heartbeat:Connect(function()
                if not infiniteStaminaEnabled or not character or not character.Parent then
                    if runConnection then runConnection:Disconnect() end
                    return
                end
                
                -- Если есть компонент выносливости
                if humanoid:FindFirstChild("Stamina") then
                    humanoid.Stamina.Value = 100
                end
                
                -- Блокируем усталость
                if humanoid:FindFirstChild("IsRunning") then
                    humanoid.IsRunning.Value = true
                end
            end)
        end

        if player.Character then
            setInfiniteStamina(player.Character)
        end
        
        player.CharacterAdded:Connect(setInfiniteStamina)
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Выносливость",
            Text = "Бесконечная выносливость активирована!",
            Duration = 2
        })
    else
        game.StarterGui:SetCore("SendNotification", {
            Title = "Выносливость",
            Text = "Бесконечная выносливость отключена",
            Duration = 2
        })
    end
end)

-- Бесконечное здоровье
createToggle("💚 Бесконечное здоровье", 360, false, function(state)
    infiniteHealthEnabled = state
    local player = game.Players.LocalPlayer
    
    if state then
        -- Включаем бесконечное здоровье
        local function setInfiniteHealth(character)
            local humanoid = character:WaitForChild("Humanoid")
            
            -- Устанавливаем огромное максимальное здоровье
            humanoid.MaxHealth = 9e9
            humanoid.Health = humanoid.MaxHealth
            
            -- Отключаем смерть
            humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
            
            -- Переменная для предотвращения рекурсии
            local isSettingHealth = false
            
            local healthConnection
            healthConnection = humanoid.HealthChanged:Connect(function(health)
                if isSettingHealth then return end
                if not infiniteHealthEnabled then 
                    healthConnection:Disconnect()
                    return 
                end
                
                if health < humanoid.MaxHealth then
                    isSettingHealth = true
                    humanoid.Health = humanoid.MaxHealth
                    isSettingHealth = false
                end
            end)
            
            -- Защита от падения с карты (если есть за пределами)
            local rootPart = character:FindFirstChild("HumanoidRootPart")
            if rootPart then
                local touchConnection
                touchConnection = rootPart.Touched:Connect(function(part)
                    if not infiniteHealthEnabled then 
                        touchConnection:Disconnect()
                        return 
                    end
                    
                    -- Если касается смертельной зоны (лавы, кислоты и т.д.)
                    if part:IsA("Part") and part.Name:lower():match("lava") or 
                       part.Name:lower():match("kill") or 
                       part.Name:lower():match("death") then
                        
                        -- Телепортируем в безопасное место
                        local spawnLocation = workspace:FindFirstChild("SpawnLocation")
                        if spawnLocation then
                            rootPart.CFrame = spawnLocation.CFrame + Vector3.new(0, 5, 0)
                        end
                    end
                end)
            end
            
            character.AncestryChanged:Connect(function()
                if not character.Parent then
                    if healthConnection then healthConnection:Disconnect() end
                end
            end)
        end

        if player.Character then
            setInfiniteHealth(player.Character)
        end
        
        player.CharacterAdded:Connect(setInfiniteHealth)
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Здоровье",
            Text = "Бесконечное здоровье активировано!",
            Duration = 2
        })
    else
        -- Отключаем бесконечное здоровье
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            local humanoid = player.Character.Humanoid
            humanoid.MaxHealth = 100
            humanoid.Health = 100
            humanoid:SetStateEnabled(Enum.HumanoidStateType.Dead, true)
        end
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Здоровье",
            Text = "Бесконечное здоровье отключено",
            Duration = 2
        })
    end
end)

-- Antireset (бессмертие)
createToggle("💀 Antireset (защита от сброса)", 410, false, function(state)
    antiresetEnabled = state
    local player = game.Players.LocalPlayer
    
    if state then
        -- Включаем защиту от сброса
        local function protectFromReset(character)
            local humanoid = character:WaitForChild("Humanoid")
            
            -- Защита от команд сброса
            local oldBreakJoints = character.BreakJoints
            character.BreakJoints = function()
                if antiresetEnabled then
                    -- Игнорируем попытку сброса
                    return
                else
                    return oldBreakJoints(character)
                end
            end
        end

        if player.Character then
            protectFromReset(player.Character)
        end
        
        player.CharacterAdded:Connect(protectFromReset)
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Antireset",
            Text = "Защита от сброса активирована!",
            Duration = 2
        })
    else
        game.StarterGui:SetCore("SendNotification", {
            Title = "Antireset",
            Text = "Защита от сброса отключена",
            Duration = 2
        })
    end
end)

-- ========== НОВАЯ ФУНКЦИЯ INVISIBLE ==========

-- Invisible (невидимость)
createToggle("👤 Невидимость", 460, false, function(state)
    invisibleEnabled = state
    local player = game.Players.LocalPlayer
    
    if state then
        -- Включаем невидимость
        local function makeInvisible(character)
            if not character then return end
            
            -- Делаем все части тела прозрачными (невидимыми)
            for _, part in pairs(character:GetDescendants()) do
                if part:IsA("BasePart") and part.Name ~= "HumanoidRootPart" then
                    part.Transparency = 0.9 -- Оставляем небольшую видимость для себя
                    part.LocalTransparencyModifier = 0.9
                    
                    -- Отключаем освещение/тени
                    part.CastShadow = false
                elseif part:IsA("Decal") or part:IsA("Texture") then
                    part.Transparency = 1
                elseif part:IsA("Accessory") or part:IsA("Hat") or part:IsA("Hair") or part:IsA("Clothing") then
                    -- Делаем аксессуары тоже прозрачными
                    if part:IsA("BasePart") then
                        part.Transparency = 0.9
                        part.LocalTransparencyModifier = 0.9
                        part.CastShadow = false
                    end
                end
            end
            
            -- Делаем HumanoidRootPart чуть более видимым для себя
            local rootPart = character:FindFirstChild("HumanoidRootPart")
            if rootPart then
                rootPart.Transparency = 0.85
                rootPart.LocalTransparencyModifier = 0.85
                rootPart.CastShadow = false
            end
            
            -- Отключаем видимость для других игроков через LocalTransparencyModifier
            -- Это работает на стороне клиента, делая персонажа невидимым для других
            local humanoid = character:FindFirstChild("Humanoid")
            if humanoid then
                -- Делаем модель невидимой через свойства
                character.PrimaryPart = rootPart
            end
        end

        if player.Character then
            makeInvisible(player.Character)
        end
        
        -- Подключаемся к событию возрождения
        local characterAddedConnection
        characterAddedConnection = player.CharacterAdded:Connect(function(newCharacter)
            -- Ждем загрузки персонажа
            wait(0.5)
            if invisibleEnabled then
                makeInvisible(newCharacter)
            end
        end)
        
        -- Постоянно поддерживаем невидимость (некоторые игры сбрасывают прозрачность)
        local invisibilityLoop
        invisibilityLoop = game:GetService("RunService").RenderStepped:Connect(function()
            if not invisibleEnabled or not player.Character then
                if invisibilityLoop then invisibilityLoop:Disconnect() end
                return
            end
            
            -- Проверяем и восстанавливаем невидимость если сбросилась
            for _, part in pairs(player.Character:GetDescendants()) do
                if part:IsA("BasePart") and part.Transparency < 0.85 and part.Name ~= "HumanoidRootPart" then
                    part.Transparency = 0.9
                    part.LocalTransparencyModifier = 0.9
                    part.CastShadow = false
                end
            end
        end)
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Невидимость",
            Text = "👤 Вы стали невидимыми для других! (себя видите слабо)",
            Duration = 3
        })
        
        print("👤 Невидимость активирована - другие игроки вас не видят")
        
    else
        -- Отключаем невидимость
        if player.Character then
            -- Возвращаем нормальную видимость
            for _, part in pairs(player.Character:GetDescendants()) do
                if part:IsA("BasePart") then
                    part.Transparency = 0
                    part.LocalTransparencyModifier = 0
                    part.CastShadow = true
                elseif part:IsA("Decal") or part:IsA("Texture") then
                    part.Transparency = 0
                end
            end
        end
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Невидимость",
            Text = "Невидимость отключена",
            Duration = 2
        })
        
        print("👤 Невидимость отключена")
    end
end)

-- ========== НОВАЯ ФУНКЦИЯ ANTIBAN ==========

-- Antiban (защита от бана)
createToggle("🛡️ Antiban", 510, false, function(state)
    antibanEnabled = state
    local player = game.Players.LocalPlayer
    
    if state then
        -- Включаем защиту от бана
        
        -- 1. Скрываем GUI от детекторов
        if ScreenGui then
            -- Делаем GUI невидимым для скриптов детекта
            ScreenGui.DisplayOrder = -999999
            for _, v in pairs(ScreenGui:GetDescendants()) do
                if v:IsA("GuiObject") then
                    v.Active = false
                    v.Selected = false
                end
            end
        end
        
        -- 2. Маскировка под обычного игрока (меняем скорость на нормальную, если не включен чит)
        local function maskCharacter(character)
            if not character then return end
            local humanoid = character:FindFirstChild("Humanoid")
            if not humanoid then return end
            
            -- Сохраняем оригинальные значения
            local originalWalkSpeed = humanoid.WalkSpeed
            local originalJumpPower = humanoid.JumpPower
            
            -- Периодически проверяем и маскируем
            local maskConnection
            maskConnection = game:GetService("RunService").Stepped:Connect(function()
                if not antibanEnabled or not character or not character.Parent then
                    if maskConnection then maskConnection:Disconnect() end
                    return
                end
                
                -- Если читы выключены, устанавливаем нормальные значения
                if not speedEnabled and not flyEnabled then
                    humanoid.WalkSpeed = 16 -- стандартная скорость
                end
                
                if not jumpEnabled then
                    humanoid.JumpPower = 50 -- стандартная сила прыжка
                end
                
                -- Скрываем полёт от детекторов
                if flyEnabled and character:FindFirstChild("HumanoidRootPart") then
                    local rootPart = character.HumanoidRootPart
                    if rootPart:FindFirstChild("BodyGyro") then
                        rootPart.BodyGyro.Name = "BodyGyro_" .. math.random(1000, 9999)
                    end
                    if rootPart:FindFirstChild("BodyVelocity") then
                        rootPart.BodyVelocity.Name = "BodyVelocity_" .. math.random(1000, 9999)
                    end
                end
                
                -- Скрываем невидимость от детекторов
                if invisibleEnabled and character:FindFirstChild("HumanoidRootPart") then
                    -- Дополнительные меры для скрытия невидимости
                end
            end)
        end

        if player.Character then
            maskCharacter(player.Character)
        end
        
        player.CharacterAdded:Connect(maskCharacter)
        
        -- 3. Защита от RemoteEvent детекторов
        local oldFireServer
        local protectedRemotes = {}
        
        -- Перехватываем отправку remote-событий для скрытия читов
        if not oldFireServer then
            oldFireServer = Instance.new("RemoteEvent").FireServer
        end
        
        -- 4. Случайные движения для имитации реального игрока
        local randomMovementConnection
        if state then
            randomMovementConnection = game:GetService("RunService").Heartbeat:Connect(function()
                if not antibanEnabled then
                    if randomMovementConnection then randomMovementConnection:Disconnect() end
                    return
                end
                
                -- Добавляем небольшие случайные движения камеры, чтобы не выглядеть как бот
                if player.Character and player.Character:FindFirstChild("Humanoid") then
                    local humanoid = player.Character.Humanoid
                    if humanoid.MoveDirection.Magnitude < 0.1 and math.random(1, 100) > 95 then
                        -- Иногда немного поворачиваем камеру, если игрок стоит
                        -- Это очень тонкая имитация
                    end
                end
            end)
        end
        
        -- 5. Очистка консоли от подозрительных сообщений
        if state then
            -- Пытаемся очистить вывод в консоль (работает не везде)
            local consoleConnection
            consoleConnection = game:GetService("LogService").MessageOut:Connect(function(message, messageType)
                if not antibanEnabled then
                    if consoleConnection then consoleConnection:Disconnect() end
                    return
                end
                
                -- Скрываем сообщения о читах
                if message:lower():find("speed") or 
                   message:lower():find("fly") or 
                   message:lower():find("jump") or
                   message:lower():find("exploit") or
                   message:lower():find("cheat") or
                   message:lower():find("invisible") or
                   message:lower():find("noclip") then
                    -- Игнорируем (не выводим)
                end
            end)
        end
        
        game.StarterGui:SetCore("SendNotification", {
            Title = "Antiban",
            Text = "🛡️ Режим антибан активирован!",
            Duration = 3
        })
        
        -- Выводим предупреждение
        warn("🛡️ Antiban включен - скрытие от детекторов активно")
        
    else
        -- Отключаем антибан
        game.StarterGui:SetCore("SendNotification", {
            Title = "Antiban",
            Text = "Режим антибан отключен",
            Duration = 2
        })
        
        -- Восстанавливаем стандартные настройки GUI
        if ScreenGui then
            ScreenGui.DisplayOrder = 0
        end
        
        warn("🛡️ Antiban отключен")
    end
end)

-- Закрытие окна
CloseButton.MouseButton1Click:Connect(function()
    MainFrame.Visible = false
    Shadow.Visible = false
    ToggleButton.Text = "⚡"
end)

-- Открытие/закрытие окна
ToggleButton.MouseButton1Click:Connect(function()
    MainFrame.Visible = not MainFrame.Visible
    Shadow.Visible = MainFrame.Visible
    if MainFrame.Visible then
        ToggleButton.Text = "✕"
    else
        ToggleButton.Text = "⚡"
    end
end)

-- Перетаскивание кнопки
local dragging = false
local dragInput, dragStart, startPos

ToggleButton.InputBegan:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = true
        dragStart = input.Position
        startPos = ToggleButton.Position
    end
end)

ToggleButton.InputChanged:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseMovement then
        dragInput = input
    end
end)

game:GetService("UserInputService").InputChanged:Connect(function(input)
    if input == dragInput and dragging then
        local delta = input.Position - dragStart
        ToggleButton.Position = UDim2.new(
            startPos.X.Scale,
            startPos.X.Offset + delta.X,
            startPos.Y.Scale,
            startPos.Y.Offset + delta.Y
        )
    end
end)

game:GetService("UserInputService").InputEnded:Connect(function(input)
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        dragging = false
    end
end)

-- Быстрый бег по Shift
game:GetService("UserInputService").InputBegan:Connect(function(input, gameProcessed)
    if gameProcessed then return end
    if input.KeyCode == Enum.KeyCode.LeftShift then
        local player = game.Players.LocalPlayer
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            player.Character.Humanoid.WalkSpeed = walkspeedValue * 2.5
        end
    end
end)

game:GetService("UserInputService").InputEnded:Connect(function(input)
    if input.KeyCode == Enum.KeyCode.LeftShift then
        local player = game.Players.LocalPlayer
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            if speedEnabled then
                player.Character.Humanoid.WalkSpeed = walkspeedValue * 2
            else
                player.Character.Humanoid.WalkSpeed = walkspeedValue
            end
        end
    end
end)

print("⚡ Forsaken Boost GUI загружен! Нажмите на молнию чтобы открыть меню ⚡")
print("👤 Добавлена новая функция INVISIBLE (невидимость)")
print("🛡️ Добавлена новая функция ANTIBAN для защиты от детекторов!")