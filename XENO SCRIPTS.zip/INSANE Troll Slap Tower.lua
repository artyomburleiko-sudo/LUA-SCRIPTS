--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- [[ GLEB'S INFINITE 0 HP GHOST ]]
-- Жизни: 0 | Состояние: Живой Призрак | ТП: 0 секунд

local player = game.Players.LocalPlayer
local char = player.Character or player.CharacterAdded:Wait()
local hum = char:WaitForChild("Humanoid")

-- 1. ГЛЕБ, ДЕЛАЕМ "БЕСКОНЕЧНЫЕ 0 ЖИЗНИ"
-- Сначала отключаем штатную смерть
hum:SetStateEnabled(Enum.HumanoidStateType.Dead, false)
-- Ставим ровно 0
hum.Health = 0

-- Защита: если игра попытается нас воскресить или убить, возвращаем 0
hum.HealthChanged:Connect(function()
    if hum.Health ~= 0 then
        hum.Health = 0
    end
end)

-- 2. УМНЫЙ ОХОТНИК (ТЕЛЕПОРТ ЗА 0 СЕКУНД)
local currentTarget = nil

local function findTarget()
    local potential = {}
    for _, p in pairs(game.Players:GetPlayers()) do
        if p ~= player and p.Character and p.Character:FindFirstChild("HumanoidRootPart") then
            -- Проверяем, что игрок на башне, а не в бездне
            if p.Character.HumanoidRootPart.Position.Y > -50 then
                table.insert(potential, p)
            end
        end
    end
    return #potential > 0 and potential[math.random(1, #potential)] or nil
end

-- Самый быстрый цикл приклеивания
game:GetService("RunService").RenderStepped:Connect(function()
    local hrp = char:FindFirstChild("HumanoidRootPart")
    if not hrp then return end

    -- Если цели нет или она упала под карту — ищем новую
    if not currentTarget or not currentTarget.Character or 
       not currentTarget.Character:FindFirstChild("HumanoidRootPart") or 
       currentTarget.Character.HumanoidRootPart.Position.Y < -50 then
        
        currentTarget = findTarget()
    end

    -- МГНОВЕННО ПРИКЛЕИВАЕМСЯ (0 секунд)
    if currentTarget and currentTarget.Character:FindFirstChild("HumanoidRootPart") then
        local targetHrp = currentTarget.Character.HumanoidRootPart
        -- Появляемся прямо за спиной (3 метра), чтобы 4 перчатки били точно
        hrp.CFrame = targetHrp.CFrame * CFrame.new(0, 0, 3)
    end
end)

-- 3. УДАЛЯЕМ ВСЕ ЛАЗЕРЫ И БЕЛЫЕ ШТУКИ (Чтобы не мешали летать)
for _, v in pairs(game.Workspace:GetDescendants()) do
    if v:IsA("BasePart") and (v.Name:lower():find("laser") or v.Color == Color3.fromRGB(255, 0, 0) or v.Name:lower():find("kill")) then
        v.CanTouch = false
        v:Destroy()
    end
end

print("Глеб, режим ПРИЗРАКА 0 HP включен! 6 марта, погнали!")