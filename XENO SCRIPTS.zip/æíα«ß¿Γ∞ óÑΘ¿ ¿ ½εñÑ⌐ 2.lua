--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
loadstring(game:HttpGet('https://raw.githubusercontent.com/aslan90101/gracity-speed-jump/refs/heads/main/FTAP.lua'))()