-- Создаем основной GUI
local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Name = "RequireScriptsGUI"
ScreenGui.Parent = game.CoreGui -- или game.Players.LocalPlayer.PlayerGui, в зависимости от executor'a

-- Создаем главное окно
local MainFrame = Instance.new("Frame")
MainFrame.Size = UDim2.new(0, 400, 0, 500)
MainFrame.Position = UDim2.new(0.5, -200, 0.5, -250)
MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
MainFrame.BorderSizePixel = 0
MainFrame.Active = true
MainFrame.Draggable = true
MainFrame.Parent = ScreenGui

-- Заголовок
local Title = Instance.new("TextLabel")
Title.Size = UDim2.new(1, 0, 0, 30)
Title.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
Title.Text = "Require Scripts GUI"
Title.TextColor3 = Color3.fromRGB(255, 255, 255)
Title.Font = Enum.Font.SourceSansBold
Title.TextSize = 18
Title.Parent = MainFrame

-- Поле для ввода ника
local NicknameFrame = Instance.new("Frame")
NicknameFrame.Size = UDim2.new(1, 0, 0, 40)
NicknameFrame.Position = UDim2.new(0, 0, 0, 30)
NicknameFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 35)
NicknameFrame.BorderSizePixel = 0
NicknameFrame.Parent = MainFrame

local NicknameLabel = Instance.new("TextLabel")
NicknameLabel.Size = UDim2.new(0, 80, 1, 0)
NicknameLabel.BackgroundTransparency = 1
NicknameLabel.Text = "Ваш ник:"
NicknameLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
NicknameLabel.Font = Enum.Font.SourceSans
NicknameLabel.TextSize = 16
NicknameLabel.Parent = NicknameFrame

local NicknameBox = Instance.new("TextBox")
NicknameBox.Size = UDim2.new(1, -90, 0, 25)
NicknameBox.Position = UDim2.new(0, 85, 0.5, -12.5)
NicknameBox.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
NicknameBox.TextColor3 = Color3.fromRGB(255, 255, 255)
NicknameBox.PlaceholderText = "Введите ваш ник"
NicknameBox.Font = Enum.Font.SourceSans
NicknameBox.TextSize = 16
NicknameBox.ClearTextOnFocus = false
NicknameBox.Parent = NicknameFrame

-- Контейнер для кнопок с прокруткой
local ScrollContainer = Instance.new("ScrollingFrame")
ScrollContainer.Size = UDim2.new(1, 0, 1, -110)
ScrollContainer.Position = UDim2.new(0, 0, 0, 70)
ScrollContainer.BackgroundColor3 = Color3.fromRGB(40, 40, 40)
ScrollContainer.BorderSizePixel = 0
ScrollContainer.CanvasSize = UDim2.new(0, 0, 0, 0)
ScrollContainer.ScrollBarThickness = 8
ScrollContainer.ScrollingDirection = Enum.ScrollingDirection.Y
ScrollContainer.AutomaticCanvasSize = Enum.AutomaticSize.Y
ScrollContainer.Parent = MainFrame

local ListLayout = Instance.new("UIListLayout")
ListLayout.Padding = UDim.new(0, 4)
ListLayout.Parent = ScrollContainer

-- Обновление CanvasSize при изменении списка
local function updateCanvasSize()
    ScrollContainer.CanvasSize = UDim2.new(0, 0, 0, ListLayout.AbsoluteContentSize.Y + 10)
end

ListLayout:GetPropertyChangedSignal("AbsoluteContentSize"):Connect(updateCanvasSize)

-- Список всех require скриптов
local scripts = {
    {require = 'require(6174615549).CauaHub', hasColon = false},
    {require = 'require(2555964157).doom', hasColon = false},
    {require = 'require(7804327506).amigodogodenot123', hasColon = false},
    {require = 'require(133464960745567).woawsoc00l', hasColon = false},
    {require = 'require(5702244094).space', hasColon = false},
    {require = 'require(7634392335)', hasColon = false, isFunction = true},
    {require = 'require(104729740754829).markuz', hasColon = false},
    {require = 'require(2788315378).load', hasColon = false},
    {require = 'require(5610305900)', hasColon = false, isFunction = true},
    {require = 'require(14821711865).load', hasColon = false},
    {require = 'require(7192763922).load', hasColon = false},
    {require = 'require(5346235551).B1847', hasColon = false},
    {require = 'require(8222129769).youareanidiot', hasColon = false},
    {require = 'require(115548396641576)', hasColon = true, method = 'V4'},
    {require = 'require(6858594080).KrnKidsSus', hasColon = false},
    {require = 'require(0x1767bf813)', hasColon = false, isFunction = true},
    {require = 'require(127867588370050).boombox', hasColon = false},
    {require = 'require(17776365113).kj', hasColon = false},
    {require = 'require(100263845596551)', hasColon = false, isFunction = true, extraParams = ', ColorSequence.new(Color3.fromRGB(71, 148, 253), Color3.fromRGB(71, 253, 160)), "Standard"'},
    {require = 'require(115563892986622)', hasColon = true, method = 'Hload'},
    {require = 'require(5448035802).Hammer', hasColon = true, method = 'Hammer', extraParams = ',"BanHammer"'},
    {require = 'require(14829670677).EDITL0L', hasColon = false, isFunction = true},
    {require = 'require(12350030542).RC7', hasColon = false, isFunction = true},
    {require = 'require(99501833820375).tripleseven777', hasColon = false, isFunction = true},
    {require = 'require(118445834905049).gbghack', hasColon = true, method = 'gbghack'},
    {require = 'require(136348658344981).SS', hasColon = false, isFunction = true},
    {require = 'require(14125553864)', hasColon = true, method = 'Fire', extraParams = ',"c00lkidd"'},
    {require = 'require(76881352505873).ssst', hasColon = false, isFunction = true} -- Добавленный скрипт ssst
}

-- Функция для создания кнопки
local function createScriptButton(scriptData)
    local ButtonFrame = Instance.new("Frame")
    ButtonFrame.Size = UDim2.new(1, -10, 0, 35)
    ButtonFrame.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    ButtonFrame.Parent = ScrollContainer
    
    local ButtonText = Instance.new("TextLabel")
    ButtonText.Size = UDim2.new(1, -50, 1, 0)
    ButtonText.BackgroundTransparency = 1
    ButtonText.Text = scriptData.require
    ButtonText.TextColor3 = Color3.fromRGB(255, 255, 255)
    ButtonText.Font = Enum.Font.Code
    ButtonText.TextSize = 12
    ButtonText.TextXAlignment = Enum.TextXAlignment.Left
    ButtonText.TextTruncate = Enum.TextTruncate.AtEnd
    ButtonText.Parent = ButtonFrame
    
    local CopyButton = Instance.new("TextButton")
    CopyButton.Size = UDim2.new(0, 40, 0, 25)
    CopyButton.Position = UDim2.new(1, -45, 0.5, -12.5)
    CopyButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
    CopyButton.Text = "Copy"
    CopyButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    CopyButton.Font = Enum.Font.SourceSans
    CopyButton.TextSize = 14
    CopyButton.Parent = ButtonFrame
    
    -- Функция для форматирования скрипта с ником
    local function formatScriptWithNick(nick)
        nick = nick or "DarkVortex195"
        if nick == "" then nick = "DarkVortex195" end
        
        local baseScript = scriptData.require
        
        if scriptData.hasColon then
            if scriptData.extraParams then
                return baseScript .. ":" .. scriptData.method .. '("' .. nick .. '"' .. scriptData.extraParams .. ')'
            else
                return baseScript .. ":" .. scriptData.method .. '("' .. nick .. '")'
            end
        elseif scriptData.isFunction then
            if scriptData.extraParams then
                return baseScript .. '("' .. nick .. '"' .. scriptData.extraParams .. ')'
            else
                return baseScript .. '("' .. nick .. '")'
            end
        else
            return baseScript .. '("' .. nick .. '")'
        end
    end
    
    -- Обработчик нажатия на кнопку Copy
    CopyButton.MouseButton1Click:Connect(function()
        local nick = NicknameBox.Text
        local formattedScript = formatScriptWithNick(nick)
        
        -- Копируем в буфер обмена
        setclipboard(formattedScript)
        
        -- Визуальный эффект
        CopyButton.BackgroundColor3 = Color3.fromRGB(50, 200, 50)
        CopyButton.Text = "Copied!"
        task.wait(0.5)
        CopyButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
        CopyButton.Text = "Copy"
        
        print("Скопировано: " .. formattedScript)
    end)
    
    -- Обновляем CanvasSize
    updateCanvasSize()
end

-- Создаем кнопки для всех скриптов
for _, scriptData in ipairs(scripts) do
    createScriptButton(scriptData)
end

-- Добавляем возможность прокрутки колесиком мыши
ScrollContainer.ScrollBarImageColor3 = Color3.fromRGB(100, 100, 100)
ScrollContainer.ScrollBarImageTransparency = 0.5
ScrollContainer.ElasticBehavior = Enum.ElasticBehavior.Always
ScrollContainer.ScrollingEnabled = true

-- Кнопка для копирования всех скриптов сразу
local CopyAllButton = Instance.new("TextButton")
CopyAllButton.Size = UDim2.new(1, 0, 0, 30)
CopyAllButton.Position = UDim2.new(0, 0, 1, -30)
CopyAllButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
CopyAllButton.Text = "Копировать все скрипты"
CopyAllButton.TextColor3 = Color3.fromRGB(255, 255, 255)
CopyAllButton.Font = Enum.Font.SourceSansBold
CopyAllButton.TextSize = 16
CopyAllButton.Parent = MainFrame

CopyAllButton.MouseButton1Click:Connect(function()
    local nick = NicknameBox.Text
    if nick == "" then nick = "DarkVortex195" end
    
    local allScripts = {}
    for _, scriptData in ipairs(scripts) do
        local baseScript = scriptData.require
        
        if scriptData.hasColon then
            if scriptData.extraParams then
                table.insert(allScripts, baseScript .. ":" .. scriptData.method .. '("' .. nick .. '"' .. scriptData.extraParams .. ')')
            else
                table.insert(allScripts, baseScript .. ":" .. scriptData.method .. '("' .. nick .. '")')
            end
        elseif scriptData.isFunction then
            if scriptData.extraParams then
                table.insert(allScripts, baseScript .. '("' .. nick .. '"' .. scriptData.extraParams .. ')')
            else
                table.insert(allScripts, baseScript .. '("' .. nick .. '")')
            end
        else
            table.insert(allScripts, baseScript .. '("' .. nick .. '")')
        end
    end
    
    local combinedScript = table.concat(allScripts, "\n")
    setclipboard(combinedScript)
    
    CopyAllButton.BackgroundColor3 = Color3.fromRGB(50, 200, 50)
    CopyAllButton.Text = "Все скопировано!"
    task.wait(1)
    CopyAllButton.BackgroundColor3 = Color3.fromRGB(70, 130, 200)
    CopyAllButton.Text = "Копировать все скрипты"
end)

-- Добавляем текст с подсказкой о прокрутке
local ScrollHint = Instance.new("TextLabel")
ScrollHint.Size = UDim2.new(1, 0, 0, 20)
ScrollHint.Position = UDim2.new(0, 0, 1, -50)
ScrollHint.BackgroundTransparency = 1
ScrollHint.Text = "↓ Прокрутите вниз для просмотра всех скриптов ↓"
ScrollHint.TextColor3 = Color3.fromRGB(150, 150, 150)
ScrollHint.Font = Enum.Font.SourceSans
ScrollHint.TextSize = 12
ScrollHint.Parent = MainFrame

print("GUI загружен! Введите ваш ник в поле и нажимайте Copy для копирования скриптов. Используйте колесико мыши для прокрутки.")