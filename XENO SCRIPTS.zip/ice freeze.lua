--[[
    Скрипт "Призрачная заморозка"
    Команда: ice
    Описание: Замораживает игрока локально. Когда он "оттает", он окажется там, куда успел сходить.
--]]

local player = game.Players.LocalPlayer
local mouse = player:GetMouse()
local userInputService = game:GetService("UserInputService")
local tweenService = game:GetService("TweenService")

-- Настройки
local freezeDuration = 5 -- Время заморозки в секундах

-- Переменные для хранения состояния
local frozenPlayer = nil
local frozenCharacter = nil
local trackingConnection = nil
local allPlayers = {}
local guiOpen = true
local minimized = false
local originalSize = nil
local originalContent = nil

-- Создание GUI
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "IceFreezeGui"
screenGui.ResetOnSpawn = false
screenGui.Parent = player:WaitForChild("PlayerGui")
screenGui.Enabled = true

-- Основное окно
local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 400, 0, 300)
mainFrame.Position = UDim2.new(0.5, -200, 0.5, -150)
mainFrame.BackgroundColor3 = Color3.fromRGB(25, 25, 35)
mainFrame.BorderSizePixel = 0
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui
mainFrame.Visible = true

-- Сохраняем оригинальные размеры
originalSize = mainFrame.Size
originalContent = {}

-- Скругленные углы
local mainCorner = Instance.new("UICorner")
mainCorner.CornerRadius = UDim.new(0, 10)
mainCorner.Parent = mainFrame

-- Обводка
local mainStroke = Instance.new("UIStroke")
mainStroke.Color = Color3.fromRGB(80, 80, 120)
mainStroke.Thickness = 1.5
mainStroke.Parent = mainFrame

-- Заголовок
local titleBar = Instance.new("Frame")
titleBar.Size = UDim2.new(1, 0, 0, 40)
titleBar.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
titleBar.BorderSizePixel = 0
titleBar.Parent = mainFrame

local titleCorner = Instance.new("UICorner")
titleCorner.CornerRadius = UDim.new(0, 10)
titleCorner.Parent = titleBar

-- Заголовок текст
local titleLabel = Instance.new("TextLabel")
titleLabel.Size = UDim2.new(1, -100, 1, 0)
titleLabel.Position = UDim2.new(0, 15, 0, 0)
titleLabel.BackgroundTransparency = 1
titleLabel.Text = "❄️ GHOST FREEZE"
titleLabel.TextColor3 = Color3.fromRGB(220, 220, 255)
titleLabel.Font = Enum.Font.GothamBold
titleLabel.TextSize = 18
titleLabel.TextXAlignment = Enum.TextXAlignment.Left
titleLabel.Parent = titleBar

-- Контейнер для кнопок управления
local controlButtons = Instance.new("Frame")
controlButtons.Size = UDim2.new(0, 70, 1, 0)
controlButtons.Position = UDim2.new(1, -75, 0, 0)
controlButtons.BackgroundTransparency = 1
controlButtons.Parent = titleBar

-- Кнопка свернуть
local minimizeButton = Instance.new("TextButton")
minimizeButton.Size = UDim2.new(0, 30, 0, 30)
minimizeButton.Position = UDim2.new(0, 5, 0.5, -15)
minimizeButton.BackgroundColor3 = Color3.fromRGB(60, 60, 70)
minimizeButton.Text = "−"
minimizeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
minimizeButton.TextSize = 20
minimizeButton.Font = Enum.Font.GothamBold
minimizeButton.Parent = controlButtons

local minCorner = Instance.new("UICorner")
minCorner.CornerRadius = UDim.new(0, 6)
minCorner.Parent = minimizeButton

-- Кнопка закрытия
local closeButton = Instance.new("TextButton")
closeButton.Size = UDim2.new(0, 30, 0, 30)
closeButton.Position = UDim2.new(0, 40, 0.5, -15)
closeButton.BackgroundColor3 = Color3.fromRGB(60, 60, 70)
closeButton.Text = "✕"
closeButton.TextColor3 = Color3.fromRGB(255, 255, 255)
closeButton.TextSize = 18
closeButton.Font = Enum.Font.GothamBold
closeButton.Parent = controlButtons

local closeCorner = Instance.new("UICorner")
closeCorner.CornerRadius = UDim.new(0, 6)
closeCorner.Parent = closeButton

-- Контент (основная часть)
local contentFrame = Instance.new("Frame")
contentFrame.Size = UDim2.new(1, -30, 1, -70)
contentFrame.Position = UDim2.new(0, 15, 0, 55)
contentFrame.BackgroundTransparency = 1
contentFrame.Parent = mainFrame
originalContent["contentFrame"] = contentFrame

-- Поле ввода
local inputFrame = Instance.new("Frame")
inputFrame.Size = UDim2.new(1, 0, 0, 45)
inputFrame.BackgroundColor3 = Color3.fromRGB(45, 45, 55)
inputFrame.BorderSizePixel = 0
inputFrame.Parent = contentFrame
originalContent["inputFrame"] = inputFrame

local inputCorner = Instance.new("UICorner")
inputCorner.CornerRadius = UDim.new(0, 8)
inputCorner.Parent = inputFrame

local textBox = Instance.new("TextBox")
textBox.Size = UDim2.new(1, -20, 1, 0)
textBox.Position = UDim2.new(0, 10, 0, 0)
textBox.BackgroundTransparency = 1
textBox.PlaceholderText = "Введите ник игрока..."
textBox.PlaceholderColor3 = Color3.fromRGB(150, 150, 170)
textBox.TextColor3 = Color3.fromRGB(255, 255, 255)
textBox.Font = Enum.Font.Gotham
textBox.TextSize = 16
textBox.ClearTextOnFocus = false
textBox.Text = ""
textBox.Parent = inputFrame

-- Список автодополнения
local autoFrame = Instance.new("Frame")
autoFrame.Size = UDim2.new(1, 0, 0, 150)
autoFrame.Position = UDim2.new(0, 0, 0, 50)
autoFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
autoFrame.BorderSizePixel = 0
autoFrame.Visible = false
autoFrame.Parent = contentFrame
originalContent["autoFrame"] = autoFrame

local autoCorner = Instance.new("UICorner")
autoCorner.CornerRadius = UDim.new(0, 8)
autoCorner.Parent = autoFrame

local autoList = Instance.new("ScrollingFrame")
autoList.Size = UDim2.new(1, -10, 1, -10)
autoList.Position = UDim2.new(0, 5, 0, 5)
autoList.BackgroundTransparency = 1
autoList.BorderSizePixel = 0
autoList.ScrollBarThickness = 4
autoList.ScrollBarImageColor3 = Color3.fromRGB(100, 100, 200)
autoList.AutomaticCanvasSize = Enum.AutomaticSize.Y
autoList.Parent = autoFrame

local listLayout = Instance.new("UIListLayout")
listLayout.Padding = UDim.new(0, 5)
listLayout.SortOrder = Enum.SortOrder.LayoutOrder
listLayout.Parent = autoList

-- Кнопка действия
local actionButton = Instance.new("TextButton")
actionButton.Size = UDim2.new(1, 0, 0, 50)
actionButton.Position = UDim2.new(0, 0, 1, -60)
actionButton.BackgroundColor3 = Color3.fromRGB(65, 105, 255)
actionButton.Text = "❄️ ЗАМОРОЗИТЬ"
actionButton.TextColor3 = Color3.fromRGB(255, 255, 255)
actionButton.Font = Enum.Font.GothamBold
actionButton.TextSize = 18
actionButton.BorderSizePixel = 0
actionButton.Parent = contentFrame
originalContent["actionButton"] = actionButton

local buttonCorner = Instance.new("UICorner")
buttonCorner.CornerRadius = UDim.new(0, 10)
buttonCorner.Parent = actionButton

-- Статус бар
local statusFrame = Instance.new("Frame")
statusFrame.Size = UDim2.new(1, 0, 0, 30)
statusFrame.Position = UDim2.new(0, 0, 1, -30)
statusFrame.BackgroundColor3 = Color3.fromRGB(20, 20, 25)
statusFrame.BorderSizePixel = 0
statusFrame.Parent = mainFrame
originalContent["statusFrame"] = statusFrame

local statusCorner = Instance.new("UICorner")
statusCorner.CornerRadius = UDim.new(0, 10)
statusCorner.Parent = statusFrame

local statusText = Instance.new("TextLabel")
statusText.Size = UDim2.new(1, -20, 1, 0)
statusText.Position = UDim2.new(0, 10, 0, 0)
statusText.BackgroundTransparency = 1
statusText.Text = "✓ Готов к работе"
statusText.TextColor3 = Color3.fromRGB(100, 255, 100)
statusText.Font = Enum.Font.Gotham
statusText.TextSize = 14
statusText.TextXAlignment = Enum.TextXAlignment.Left
statusText.Parent = statusFrame

-- Функция сворачивания/разворачивания
local function toggleMinimize()
    minimized = not minimized
    
    if minimized then
        -- Сворачиваем
        mainFrame.Size = UDim2.new(0, 400, 0, 40)
        
        -- Прячем весь контент
        contentFrame.Visible = false
        statusFrame.Visible = false
        
        -- Меняем текст кнопки
        minimizeButton.Text = "□"
        
        -- Отключаем перетаскивание (опционально)
        mainFrame.Draggable = true
    else
        -- Разворачиваем
        mainFrame.Size = UDim2.new(0, 400, 0, 300)
        
        -- Показываем контент
        contentFrame.Visible = true
        statusFrame.Visible = true
        
        -- Меняем текст кнопки
        minimizeButton.Text = "−"
        
        -- Включаем перетаскивание
        mainFrame.Draggable = true
    end
end

-- Наводим красоту при наведении на кнопки
local function setupButtonHover(button)
    button.MouseEnter:Connect(function()
        tweenService:Create(button, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(80, 80, 90)}):Play()
    end)
    button.MouseLeave:Connect(function()
        tweenService:Create(button, TweenInfo.new(0.2), {BackgroundColor3 = Color3.fromRGB(60, 60, 70)}):Play()
    end)
end

setupButtonHover(minimizeButton)
setupButtonHover(closeButton)

-- Клик по кнопке свернуть
minimizeButton.MouseButton1Click:Connect(toggleMinimize)

-- Клик по кнопке закрыть
closeButton.MouseButton1Click:Connect(function()
    screenGui.Enabled = false
    guiOpen = false
end)

-- Функции автодополнения
local function updatePlayersList()
    allPlayers = {}
    for _, plr in ipairs(game.Players:GetPlayers()) do
        if plr ~= player then
            table.insert(allPlayers, plr)
        end
    end
    table.sort(allPlayers, function(a, b)
        return a.Name:lower() < b.Name:lower()
    end)
end

local function clearAutocomplete()
    for _, child in ipairs(autoList:GetChildren()) do
        if child:IsA("TextButton") then
            child:Destroy()
        end
    end
end

local function updateAutocomplete(input)
    clearAutocomplete()
    
    if input == "" then
        autoFrame.Visible = false
        return
    end
    
    updatePlayersList()
    
    local matches = {}
    local inputLower = input:lower()
    
    for _, plr in ipairs(allPlayers) do
        if plr.Name:lower():sub(1, #input) == inputLower or 
           (plr.DisplayName and plr.DisplayName:lower():sub(1, #input) == inputLower) then
            table.insert(matches, plr)
        end
    end
    
    if #matches > 0 then
        autoFrame.Visible = true
        
        for i, plr in ipairs(matches) do
            if i > 8 then break end
            
            local btn = Instance.new("TextButton")
            btn.Size = UDim2.new(1, -10, 0, 35)
            btn.BackgroundColor3 = Color3.fromRGB(50, 50, 60)
            btn.Text = string.format("%s (@%s)", plr.DisplayName or plr.Name, plr.Name)
            btn.TextColor3 = Color3.fromRGB(200, 200, 255)
            btn.Font = Enum.Font.Gotham
            btn.TextSize = 14
            btn.TextXAlignment = Enum.TextXAlignment.Left
            btn.Parent = autoList
            
            local btnCorner = Instance.new("UICorner")
            btnCorner.CornerRadius = UDim.new(0, 6)
            btnCorner.Parent = btn
            
            btn.MouseButton1Click:Connect(function()
                textBox.Text = plr.Name
                autoFrame.Visible = false
            end)
        end
    else
        autoFrame.Visible = false
    end
end

-- Отслеживание ввода
textBox:GetPropertyChangedSignal("Text"):Connect(function()
    updateAutocomplete(textBox.Text)
end)

textBox.Focused:Connect(function()
    if textBox.Text ~= "" then
        updateAutocomplete(textBox.Text)
    end
end)

textBox.FocusLost:Connect(function()
    wait(0.2)
    autoFrame.Visible = false
end)

-- Функции заморозки
local function unfreezeAndTeleport()
    if frozenPlayer and frozenCharacter and frozenCharacter.Parent then
        local humanoid = frozenCharacter:FindFirstChild("Humanoid")
        local rootPart = frozenCharacter:FindFirstChild("HumanoidRootPart")
        
        if rootPart and humanoid then
            humanoid:ChangeState(Enum.HumanoidStateType.Freefall)
            rootPart.Anchored = false
        end
    end
    
    if trackingConnection then
        trackingConnection:Disconnect()
        trackingConnection = nil
    end
    
    frozenPlayer = nil
    frozenCharacter = nil
    statusText.Text = "✓ Готов к работе"
    statusText.TextColor3 = Color3.fromRGB(100, 255, 100)
    actionButton.Text = "❄️ ЗАМОРОЗИТЬ"
end

local function freezePlayer(targetPlayer)
    if frozenPlayer then
        unfreezeAndTeleport()
        wait(0.5)
    end
    
    local character = targetPlayer.Character
    if not character or not character:FindFirstChild("HumanoidRootPart") then
        statusText.Text = "✗ Ошибка: нет персонажа"
        statusText.TextColor3 = Color3.fromRGB(255, 100, 100)
        return
    end
    
    local rootPart = character.HumanoidRootPart
    
    frozenPlayer = targetPlayer
    frozenCharacter = character
    
    -- Эффект заморозки
    local iceCube = Instance.new("Part")
    iceCube.Size = Vector3.new(6, 6, 6)
    iceCube.CFrame = rootPart.CFrame
    iceCube.Anchored = true
    iceCube.CanCollide = false
    iceCube.Transparency = 0.3
    iceCube.BrickColor = BrickColor.new("Cyan")
    iceCube.Material = Enum.Material.Ice
    iceCube.Parent = workspace
    game:GetService("Debris"):AddItem(iceCube, freezeDuration + 0.5)
    
    local weld = Instance.new("Weld")
    weld.Part0 = rootPart
    weld.Part1 = iceCube
    weld.C0 = CFrame.new(0, 0, 0)
    weld.Parent = iceCube
    
    rootPart.Anchored = true
    
    statusText.Text = "❄️ Заморожен: " .. targetPlayer.Name
    statusText.TextColor3 = Color3.fromRGB(100, 200, 255)
    actionButton.Text = "⏰ " .. freezeDuration .. " сек"
    
    wait(freezeDuration)
    
    if frozenPlayer == targetPlayer then
        unfreezeAndTeleport()
    end
end

-- Клик по кнопке действия
actionButton.MouseButton1Click:Connect(function()
    if frozenPlayer then
        unfreezeAndTeleport()
        return
    end
    
    local targetName = textBox.Text
    if targetName == "" then
        statusText.Text = "✗ Введите ник игрока!"
        statusText.TextColor3 = Color3.fromRGB(255, 100, 100)
        return
    end
    
    local targetPlayer = nil
    for _, plr in ipairs(game.Players:GetPlayers()) do
        if plr.Name:lower() == targetName:lower() or 
           (plr.DisplayName and plr.DisplayName:lower() == targetName:lower()) then
            targetPlayer = plr
            break
        end
    end
    
    if not targetPlayer then
        for _, plr in ipairs(game.Players:GetPlayers()) do
            if plr.Name:lower():sub(1, #targetName) == targetName:lower() or 
               (plr.DisplayName and plr.DisplayName:lower():sub(1, #targetName) == targetName:lower()) then
                targetPlayer = plr
                break
            end
        end
    end
    
    if targetPlayer then
        if targetPlayer == player then
            statusText.Text = "✗ Нельзя заморозить себя!"
            statusText.TextColor3 = Color3.fromRGB(255, 100, 100)
            return
        end
        freezePlayer(targetPlayer)
    else
        statusText.Text = "✗ Игрок не найден!"
        statusText.TextColor3 = Color3.fromRGB(255, 100, 100)
    end
end)

-- Открытие по команде
player.Chatted:Connect(function(msg)
    if msg:lower() == "ice" then
        screenGui.Enabled = not screenGui.Enabled
        guiOpen = screenGui.Enabled
    end
end)

-- Инициализация
updatePlayersList()
game.Players.PlayerAdded:Connect(updatePlayersList)
game.Players.PlayerRemoving:Connect(updatePlayersList)

-- Уведомление
print("❄️ Ghost Freeze загружен! Напишите 'ice' в чат")