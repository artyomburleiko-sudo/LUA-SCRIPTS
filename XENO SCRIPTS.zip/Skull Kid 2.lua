--[[
    Majora's Mask: Skull Kid (Hyrule Warriors)
    Made by Zalgo_exe/Kunoleo/SlenderMan2095
    Fixed and Optimized for Modern Roblox
--]]

warn("Loading Script...")
wait(0.2)

-- Services
local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")
local Debris = game:GetService("Debris")
local Lighting = game:GetService("Lighting")
local Workspace = game:GetService("Workspace")

-- Player and Character
local Player = Players.LocalPlayer
local Character = Player.Character
local Mouse = Player:GetMouse()

-- Check for R6
if not Character:FindFirstChild("Torso") then
    warn("This script requires R6 character! Please change your avatar to R6.")
    return
end

-- Core parts
local Torso = Character:FindFirstChild("Torso")
local rootPart = Character:FindFirstChild("HumanoidRootPart")
local Humanoid = Character:FindFirstChild("Humanoid")
local Head = Character:FindFirstChild("Head")
local Right_Arm = Character:FindFirstChild("Right Arm")
local Left_Arm = Character:FindFirstChild("Left Arm")
local Right_Leg = Character:FindFirstChild("Right Leg")
local Left_Leg = Character:FindFirstChild("Left Leg")

-- Variables
local sine = 0
local change = 1
local sprint = false
local attack = false
local attack2 = false
local fattack = false
local Animations = false
local currentAnim = "Idling"
local intro = true
local target = nil
local attk = 1

-- Settings
Humanoid.MaxHealth = 1000
Humanoid.Health = Humanoid.MaxHealth
Humanoid.DisplayDistanceType = 'None'
Humanoid.WalkSpeed = 8
Humanoid.JumpPower = 50

-- Helper functions
local function swait(num)
    if num == 0 or num == nil then
        RunService.Stepped:Wait()
    else
        for _ = 1, num do
            RunService.Stepped:Wait()
        end
    end
end

local function noOutline(part)
    part.TopSurface = Enum.SurfaceType.Smooth
    part.BottomSurface = Enum.SurfaceType.Smooth
    part.LeftSurface = Enum.SurfaceType.Smooth
    part.RightSurface = Enum.SurfaceType.Smooth
    part.FrontSurface = Enum.SurfaceType.Smooth
    part.BackSurface = Enum.SurfaceType.Smooth
end

local function findNearestTorso(position, distance)
    local list = {}
    for _, v in pairs(Workspace:GetChildren()) do
        if v:IsA("Model") and v ~= Character then
            local torso = v:FindFirstChild("Torso") or v:FindFirstChild("HumanoidRootPart")
            if torso and v:FindFirstChild("Humanoid") then
                if (torso.Position - position).magnitude <= distance then
                    table.insert(list, v)
                end
            end
        end
    end
    return list
end

-- Clean up character
for _, v in pairs(Character:GetChildren()) do
    if v:IsA('ShirtGraphic') or v:IsA('CharacterMesh') or v:IsA('Accoutrement') or 
       v:IsA('Shirt') or v:IsA('Pants') then
        v:Destroy()
    elseif v:IsA('Part') and v.Name == 'Head' and v:FindFirstChild('face') then
        v.face:Destroy()
    end
end

-- Body colors
Character['Body Colors'].HeadColor = BrickColor.new('Reddish brown')
Character['Body Colors'].TorsoColor = BrickColor.new('Reddish brown')
Character['Body Colors'].RightArmColor = BrickColor.new('Reddish brown')
Character['Body Colors'].LeftArmColor = BrickColor.new('Reddish brown')
Character['Body Colors'].RightLegColor = BrickColor.new('Reddish brown')
Character['Body Colors'].LeftLegColor = BrickColor.new('Reddish brown')

-- Clothes
local shirt = Instance.new("Shirt", Character)
local pants = Instance.new("Pants", Character)
shirt.ShirtTemplate = "rbxassetid://18622157"
pants.PantsTemplate = "rbxassetid://18616286"

-- Character meshes
local bodyParts = {
    {Part = "Torso", Id = "27111894"},
    {Part = "RightArm", Id = "27111864"},
    {Part = "LeftArm", Id = "27111419"},
    {Part = "RightLeg", Id = "27111882"},
    {Part = "LeftLeg", Id = "27111857"}
}

for _, part in ipairs(bodyParts) do
    local mesh = Instance.new("CharacterMesh", Character)
    mesh.BodyPart = part.Part
    mesh.MeshId = part.Id
end

-- Head
Head.Transparency = 1
local headMesh = Instance.new("Part", Head)
headMesh.Name = "_Head"
headMesh.Shape = Enum.PartType.Block
headMesh.CanCollide = false
headMesh.BrickColor = BrickColor.new("Reddish brown")
headMesh.Transparency = 0
headMesh.Material = "Wood"
headMesh.Size = Vector3.new(1.5, 1.5, 1.5)
noOutline(headMesh)

local headWeld = Instance.new("Weld", headMesh)
headWeld.Part0 = Head
headWeld.Part1 = headMesh
headWeld.C1 = CFrame.new(0, -0.15, 0)

local headSphere = Instance.new("SpecialMesh", headMesh)
headSphere.MeshType = "Sphere"
headSphere.Scale = Vector3.new(1, 1, 1)

-- Fairies
local Tael = Instance.new("Part", Character)
Tael.Name = "Tael"
Tael.Shape = Enum.PartType.Block
Tael.CanCollide = false
Tael.BrickColor = BrickColor.new("Dark indigo")
Tael.Transparency = 0
Tael.Material = "Neon"
Tael.Size = Vector3.new(0.5, 0.5, 0.5)
noOutline(Tael)

local TaelWeld = Instance.new("Weld", Tael)
TaelWeld.Part0 = rootPart
TaelWeld.Part1 = Tael
TaelWeld.C1 = CFrame.new(0, -5, 3.5)

local TaelMesh = Instance.new("SpecialMesh", Tael)
TaelMesh.MeshType = "Sphere"
TaelMesh.Scale = Vector3.new(1, 1, 1)

local Tatl = Instance.new("Part", Character)
Tatl.Name = "Tatl"
Tatl.Shape = Enum.PartType.Block
Tatl.CanCollide = false
Tatl.BrickColor = BrickColor.new("New Yeller")
Tatl.Transparency = 0
Tatl.Material = "Neon"
Tatl.Size = Vector3.new(0.5, 0.5, 0.5)
noOutline(Tatl)

local TatlWeld = Instance.new("Weld", Tatl)
TatlWeld.Part0 = rootPart
TatlWeld.Part1 = Tatl
TatlWeld.C1 = CFrame.new(0, -2, 3.5)

local TatlMesh = Instance.new("SpecialMesh", Tatl)
TatlMesh.MeshType = "Sphere"
TatlMesh.Scale = Vector3.new(1, 1, 1)

-- Fairy wings and effects
local function createFairyEffects(fairy, color)
    -- Billboard
    local gui = Instance.new("BillboardGui", fairy)
    gui.Size = UDim2.new(1.3, 0, 1, 0)
    gui.MaxDistance = "inf"
    gui.ExtentsOffset = Vector3.new(0, 0.1, 0)
    
    local wings = Instance.new("ImageLabel", gui)
    wings.Position = UDim2.new(0, 0, 0, 0)
    wings.Image = "rbxassetid://1345656252"
    wings.BackgroundTransparency = 1
    wings.Size = UDim2.new(1, 0, 1, 0)
    
    -- Trail
    local atch0 = Instance.new("Attachment", fairy)
    atch0.Position = Vector3.new(0, 0, fairy.Size.Z/2)
    local atch1 = Instance.new("Attachment", fairy)
    atch1.Position = Vector3.new(0, 0, -fairy.Size.Z/2)
    
    local trail = Instance.new("Trail", fairy)
    trail.Attachment0 = atch0
    trail.Attachment1 = atch1
    trail.Lifetime = 0.2
    trail.Enabled = true
    trail.LightEmission = 1
    trail.LightInfluence = 0
    trail.FaceCamera = true
    trail.WidthScale = NumberSequence.new({NumberSequenceKeypoint.new(0,1), NumberSequenceKeypoint.new(1,0)})
    trail.Color = ColorSequence.new(color)
    trail.Transparency = NumberSequence.new(0, 1)
    
    -- Particles
    local sparkles = Instance.new("ParticleEmitter", fairy)
    sparkles.Color = ColorSequence.new(color)
    sparkles.LightEmission = 1
    sparkles.Texture = 'rbxassetid://187012669'
    sparkles.Size = NumberSequence.new({NumberSequenceKeypoint.new(0, 0.05), NumberSequenceKeypoint.new(1, 0)})
    sparkles.EmissionDirection = 'Back'
    sparkles.Lifetime = NumberRange.new(0.5)
    sparkles.Rate = 10
    sparkles.SpreadAngle = Vector2.new(-90, 90)
    
    local glow = Instance.new("ParticleEmitter", fairy)
    glow.Enabled = true
    glow.Transparency = NumberSequence.new({NumberSequenceKeypoint.new(0,1), NumberSequenceKeypoint.new(0.3,0.95), NumberSequenceKeypoint.new(1,1)})
    glow.LightEmission = 1
    glow.Rate = 2000
    glow.ZOffset = 1
    glow.Lifetime = NumberRange.new(0.5)
    glow.Speed = NumberRange.new(1)
    glow.Size = NumberSequence.new({NumberSequenceKeypoint.new(0, 0.2), NumberSequenceKeypoint.new(1, 0.5)})
    glow.Rotation = NumberRange.new(-180, 180)
    glow.RotSpeed = NumberRange.new(-180, 180)
    glow.Texture = "rbxassetid://303194966"
    glow.Color = ColorSequence.new(color)
    glow.VelocitySpread = 360
    glow.LockedToPart = false
    
    return gui
end

createFairyEffects(Tael, Color3.fromRGB(61, 21, 133))
createFairyEffects(Tatl, Color3.fromRGB(255, 255, 0))

-- Fairy animation
coroutine.wrap(function()
    while true do
        for i = 1, 5 do
            Tael:FindFirstChildOfClass("BillboardGui").Size = Tael:FindFirstChildOfClass("BillboardGui").Size - UDim2.new(0.1, 0, 0, 0)
            Tatl:FindFirstChildOfClass("BillboardGui").Size = Tatl:FindFirstChildOfClass("BillboardGui").Size - UDim2.new(0.1, 0, 0, 0)
            swait()
        end
        for i = 1, 5 do
            Tael:FindFirstChildOfClass("BillboardGui").Size = Tael:FindFirstChildOfClass("BillboardGui").Size + UDim2.new(0.1, 0, 0, 0)
            Tatl:FindFirstChildOfClass("BillboardGui").Size = Tatl:FindFirstChildOfClass("BillboardGui").Size + UDim2.new(0.1, 0, 0, 0)
            swait()
        end
    end
end)()

-- Mask
local Mask = Instance.new("Part", Head)
Mask.Name = "Majora's Mask"
Mask.Shape = Enum.PartType.Ball
Mask.CanCollide = false
Mask.Color = Color3.new(0, 0, 0)
Mask.Transparency = 1
Mask.Material = "SmoothPlastic"
Mask.Size = Vector3.new(0.1, 0.1, 0.1)
noOutline(Mask)

local MaskWeld = Instance.new("Weld", Mask)
MaskWeld.Part0 = Head
MaskWeld.Part1 = Mask
MaskWeld.C1 = CFrame.new(0, -0.7, -0.25) * CFrame.Angles(math.rad(90), 0, 0)

local MaskMesh = Instance.new("FileMesh", Mask)
MaskMesh.MeshId = "rbxassetid://2054429467"
MaskMesh.TextureId = "rbxassetid://2054436209"
MaskMesh.Scale = Vector3.new(0.38, 0.38, 0.38)

-- Beak
local Beak = Instance.new("Part", Head)
Beak.Name = "Beak"
Beak.Shape = Enum.PartType.Ball
Beak.CanCollide = false
Beak.Color = Color3.new(0, 0, 0)
Beak.Transparency = 0
Beak.Material = "SmoothPlastic"
Beak.Size = Vector3.new(0.1, 0.1, 0.1)
noOutline(Beak)

local BeakWeld = Instance.new("Weld", Beak)
BeakWeld.Part0 = Head
BeakWeld.Part1 = Beak
BeakWeld.C1 = CFrame.new(0, 0.1, 0.7)

local BeakMesh = Instance.new("FileMesh", Beak)
BeakMesh.MeshId = "rbxassetid://1241049633"
BeakMesh.TextureId = "rbxassetid://1179215218"
BeakMesh.Scale = Vector3.new(0.5, 0.15, 0.1)
BeakMesh.VertexColor = Vector3.new(1, 0.5, 0)

-- Ocarina
local Ocarina = Instance.new("Part", Character)
Ocarina.Name = "Link's Ocarina"
Ocarina.Shape = Enum.PartType.Ball
Ocarina.CanCollide = false
Ocarina.Color = Color3.new(0, 0, 0)
Ocarina.Transparency = 1
Ocarina.Material = "SmoothPlastic"
Ocarina.Size = Vector3.new(0.1, 0.1, 0.1)
noOutline(Ocarina)

local OcarinaWeld = Instance.new("Weld", Ocarina)
OcarinaWeld.Part0 = Left_Arm
OcarinaWeld.Part1 = Ocarina
OcarinaWeld.C1 = CFrame.new(-0.2, 0, 1) * CFrame.Angles(math.rad(90), 0, 0)

local OcarinaMesh = Instance.new("FileMesh", Ocarina)
OcarinaMesh.MeshId = "rbxassetid://1591417841"
OcarinaMesh.TextureId = "rbxassetid://1591417870"
OcarinaMesh.Scale = Vector3.new(0.05, 0.05, 0.05)

-- Hat
local Hat = Instance.new("Part", Head)
Hat.Name = "Hat"
Hat.Shape = Enum.PartType.Ball
Hat.CanCollide = false
Hat.Color = Color3.new(0, 0, 0)
Hat.Transparency = 0
Hat.Material = "SmoothPlastic"
Hat.Size = Vector3.new(0.1, 0.1, 0.1)
noOutline(Hat)

local HatWeld = Instance.new("Weld", Hat)
HatWeld.Part0 = Head
HatWeld.Part1 = Hat
HatWeld.C1 = CFrame.new(0, -1, 0.1) * CFrame.Angles(math.rad(-30), 0, 0)

local HatMesh = Instance.new("FileMesh", Hat)
HatMesh.MeshId = "rbxassetid://12811687"
HatMesh.TextureId = "rbxassetid://12811694"
HatMesh.Scale = Vector3.new(1.2, 1.4, 1.4)

-- Poncho
local Poncho = Instance.new("Part", Torso)
Poncho.Name = "Poncho"
Poncho.Shape = Enum.PartType.Ball
Poncho.CanCollide = false
Poncho.Color = Color3.fromRGB(157, 168, 0)
Poncho.Transparency = 0
Poncho.Material = "SmoothPlastic"
Poncho.Size = Vector3.new(0.1, 0.1, 0.1)
noOutline(Poncho)

local PonchoWeld = Instance.new("Weld", Poncho)
PonchoWeld.Part0 = Torso
PonchoWeld.Part1 = Poncho
PonchoWeld.C1 = CFrame.new(0.25, -0.05, 0.45) * CFrame.Angles(math.rad(-90), math.rad(-90), 0)

local PonchoMesh = Instance.new("FileMesh", Poncho)
PonchoMesh.MeshId = "rbxassetid://2057076845"
PonchoMesh.Scale = Vector3.new(0.25, 0.2, 0.2)

-- Eyes
local function createEye(name, color, posX, posY, posZ, size)
    local eye = Instance.new("Part", Character)
    eye.Name = name
    eye.Shape = Enum.PartType.Ball
    eye.CanCollide = false
    eye.BrickColor = BrickColor.new(color)
    eye.Transparency = 0
    eye.Material = "Neon"
    eye.Size = size
    noOutline(eye)
    
    local weld = Instance.new("Weld", eye)
    weld.Part0 = Head
    weld.Part1 = eye
    weld.C0 = CFrame.new(posX, posY, posZ)
    
    return eye
end

createEye("REye1", "New Yeller", 0.305, 0.13, -0.655, Vector3.new(0.15, 0.15, 0.15))
createEye("LEye1", "New Yeller", -0.305, 0.13, -0.655, Vector3.new(0.15, 0.15, 0.15))
createEye("REye2", "CGA brown", 0.3, 0.13, -0.625, Vector3.new(0.2, 0.2, 0.2))
createEye("LEye2", "CGA brown", -0.3, 0.13, -0.625, Vector3.new(0.2, 0.2, 0.2))

-- Effects folder
local Effects = Instance.new("Folder", Character)
Effects.Name = "Effects"

-- Weld setup
local function newWeld(part0, part1, cx, cy, cz)
    local weld = Instance.new("Weld", part1)
    weld.Part0 = part0
    weld.Part1 = part1
    weld.C0 = CFrame.new(cx, cy, cz)
    weld.C1 = CFrame.new(0, 0, 0)
    return weld
end

local RA_Weld = newWeld(Torso, Right_Arm, 1.5, 0.5, 0)
Right_Arm.Weld.C1 = CFrame.new(0, 0.5, 0)

local LA_Weld = newWeld(Torso, Left_Arm, -1.5, 0.5, 0)
Left_Arm.Weld.C1 = CFrame.new(0, 0.5, 0)

local RL_Weld = newWeld(Torso, Right_Leg, 0.5, -1, 0)
Right_Leg.Weld.C1 = CFrame.new(0, 1, 0)

local LL_Weld = newWeld(Torso, Left_Leg, -0.5, -1, 0)
Left_Leg.Weld.C1 = CFrame.new(0, 1, 0)

local Torso_Weld = newWeld(rootPart, Torso, 0, -1, 0)
Torso.Weld.C1 = CFrame.new(0, -1, 0)

local Head_Weld = newWeld(Torso, Head, 0, 1.5, 0)

-- Animation helper
local function clerp(a, b, t)
    return a:Lerp(b, t)
end

-- Theme music
local Theme = Instance.new("Sound")
Theme.Parent = Character.Torso
Theme.SoundId = "rbxassetid://269366083"
Theme.Volume = 9.6
Theme.Looped = true
Theme.Pitch = 1
Theme:Play()

-- Intro
function Intro()
    attack = true
    attack2 = true
    Animations = true
    
    local Decoy = Instance.new("Part", Head)
    Decoy.Name = "Majora's Decoy"
    Decoy.Shape = Enum.PartType.Ball
    Decoy.CanCollide = false
    Decoy.Anchored = true
    Decoy.Color = Color3.new(0, 0, 0)
    Decoy.Transparency = 0
    Decoy.Material = "SmoothPlastic"
    Decoy.Size = Vector3.new(0.1, 0.1, 0.1)
    noOutline(Decoy)
    Decoy.CFrame = rootPart.CFrame * CFrame.new(0, -2.8, -2) * CFrame.Angles(0, math.rad(-200), 0)
    
    local DecoyMesh = Instance.new("FileMesh", Decoy)
    DecoyMesh.MeshId = "rbxassetid://2054429467"
    DecoyMesh.TextureId = "rbxassetid://2054436209"
    DecoyMesh.Scale = Vector3.new(0.38, 0.38, 0.38)
    
    -- Animation sequence
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5 + math.sin(sine/7.5)/15, 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5 + math.sin(sine/7.5)/15, 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1 - math.sin(sine/7.5)/15, 0) * CFrame.Angles(math.sin(sine/4)/3, 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1 - math.sin(sine/7.5)/15, 0) * CFrame.Angles(-math.sin(sine/4)/3, 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1 + math.sin(sine/7.5)/15, 10 + i * -10), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5 + math.sin(sine/7.5)/15, 0 - math.sin(sine/7.5)/15) * CFrame.Angles(0 - math.sin(sine/7.5)/15, 0, 0), 0.15)
        swait()
    end
    
    local sound1 = Instance.new("Sound")
    sound1.Parent = Character.Torso
    sound1.SoundId = "rbxassetid://2057274656"
    sound1.Volume = 10
    sound1:Play()
    
    -- Continue animation...
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(10), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(10), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0) * CFrame.Angles(math.rad(-10), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.2) * CFrame.Angles(math.rad(-20), 0, 0), 0.15)
        swait()
    end
    
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.5) * CFrame.Angles(math.rad(90), 0, math.rad(-20)), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, -0.5) * CFrame.Angles(math.rad(90), 0, math.rad(20)), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(80), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(80), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0) * CFrame.Angles(math.rad(-80), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.2) * CFrame.Angles(math.rad(-20), 0, 0), 0.15)
        swait()
    end
    
    Decoy.Anchored = false
    local decoyWeld = Instance.new("Weld", Decoy)
    decoyWeld.Part0 = Torso
    decoyWeld.Part1 = Decoy
    decoyWeld.C1 = CFrame.new(0, 2, -1.5) * CFrame.Angles(math.rad(90), math.rad(180), 0)
    
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.5) * CFrame.Angles(math.rad(120), 0, math.rad(-30)), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, -0.5) * CFrame.Angles(math.rad(120), 0, math.rad(30)), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0), 0.15)
        swait()
    end
    
    Decoy.Anchored = true
    decoyWeld:Destroy()
    
    for i = 1, 18 do
        Decoy.CFrame = Decoy.CFrame * CFrame.Angles(0, 0, math.rad(10))
        swait()
    end
    
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.5) * CFrame.Angles(math.rad(120), 0, math.rad(-20)), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, -0.5) * CFrame.Angles(math.rad(120), 0, math.rad(20)), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0), 0.15)
        swait()
    end
    
    for i = 1, 5 do
        Decoy.CFrame = Decoy.CFrame * CFrame.new(0, -0.25, 0)
        swait()
    end
    
    Decoy:Destroy()
    Mask.Transparency = 0
    
    local sound2 = Instance.new("Sound")
    sound2.Parent = Character.Torso
    sound2.SoundId = "rbxassetid://2057161687"
    sound2.Volume = 10
    sound2:Play()
    
    Theme.SoundId = "rbxassetid://243250871"
    Theme:Play()
    
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.25, 0.5, 0.2) * CFrame.Angles(math.rad(-30), math.rad(-60), 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.5, 0.2) * CFrame.Angles(math.rad(-30), math.rad(60), 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0) * CFrame.Angles(math.rad(20), 0, 0), 0.15)
        swait()
    end
    
    for i = 0, 0.05, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.5) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, -0.5) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0) * CFrame.Angles(math.rad(-20), 0, 0), 0.15)
        swait()
    end
    
    for i = 0, 1, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, 0) * CFrame.Angles(math.rad(150), 0, 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, 0) * CFrame.Angles(math.rad(150), 0, 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(-10), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(-10), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -2.5, 0) * CFrame.Angles(math.rad(-80), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0), 0.15)
        swait()
    end
    
    local sound3 = Instance.new("Sound")
    sound3.Parent = Character.Torso
    sound3.SoundId = "rbxassetid://160195008"
    sound3.Volume = 10
    sound3:Play()
    
    fattack = true
    
    for i = 0, 2, 0.01 do
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(-120), 0, 0), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(-120), 0, 0), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -2.5, 0) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0) * CFrame.Angles(math.rad(20 + math.random(-100,100)/10), 0, math.rad(math.random(-100,100)/10)), 0.4)
        
        -- Shockwave effect
        local shockwave = Instance.new("Part", Character)
        shockwave.Anchored = true
        shockwave.BrickColor = BrickColor.new("Dark indigo")
        shockwave.CanCollide = false
        shockwave.FormFactor = Enum.FormFactor.Custom
        shockwave.Name = "Shockwave"
        shockwave.Size = Vector3.new(1, 1, 1)
        shockwave.Transparency = 0.35
        shockwave.TopSurface = Enum.SurfaceType.Smooth
        shockwave.BottomSurface = Enum.SurfaceType.Smooth
        shockwave.CFrame = rootPart.CFrame * CFrame.Angles(0, math.rad(90), 0)
        
        local shockwaveMesh = Instance.new("SpecialMesh", shockwave)
        shockwaveMesh.MeshId = "rbxassetid://20329976"
        shockwaveMesh.Scale = Vector3.new(0, 0, 0)
        shockwaveMesh.Offset = Vector3.new(0, 0, -0.5)
        
        coroutine.wrap(function()
            for i = 1, 60, 2 do
                shockwave.CFrame = shockwave.CFrame * CFrame.Angles(0, math.rad(5) + i * math.random(1,10), 0)
                shockwaveMesh.Scale = Vector3.new(5 + i * 0.3, 2 - i * 0.1, 5 + i * 0.3)
                shockwave.Transparency = i / 30
                shockwave.CFrame = shockwave.CFrame - Vector3.new(0, 0.2, 0)
                swait()
            end
            shockwave:Destroy()
        end)()
        
        -- Reset fairy positions properly (non-accumulating)
        TaelWeld.C1 = CFrame.new(0, -5, 3.5)
        TatlWeld.C1 = CFrame.new(0, -2, 3.5)
        swait()
    end
    
    Theme.SoundId = "rbxassetid://302493616"
    Theme:Play()
    Ocarina.Transparency = 0
    
    Animations = false
    attack2 = false
    fattack = false
    attack = false
end

-- Attack functions (simplified versions)
function Laugh()
    if attack then return end
    attack = true
    attack2 = true
    Animations = true
    
    local laughSounds = {
        "rbxassetid://2057149157",
        "rbxassetid://2057150436",
        "rbxassetid://2057595082",
        "rbxassetid://2065249482",
        "rbxassetid://2065252593"
    }
    
    local sound = Instance.new("Sound")
    sound.Parent = Character.Torso
    sound.SoundId = laughSounds[math.random(1, #laughSounds)]
    sound.Volume = 10
    sound:Play()
    
    local sound2 = Instance.new("Sound")
    sound2.Parent = Character.Torso
    sound2.SoundId = "rbxassetid://21338895"
    sound2.Volume = 4
    sound2.Pitch = 0.8
    sound2:Play()
    
    local laughStyle = math.random(1, 3)
    
    for i = 0, 1, 0.01 do
        if laughStyle == 1 then
            RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.25, 0.5, -0.5) * CFrame.Angles(math.rad(45) - math.sin(sine/7.5)/15, 0, math.rad(-30) + math.sin(sine/7.5)/15), 0.15)
            LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.5, -0.5) * CFrame.Angles(math.rad(45) + math.sin(sine/7.5)/15, 0, math.rad(30)), 0.15)
            Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0 + math.sin(sine/15)/5, -0.5 + math.sin(sine/7.5)/15, 0) * CFrame.Angles(math.rad(10) - math.sin(sine/15)/15, 0, 0), 0.15)
            Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(-10) + math.sin(sine/7.5)/15, 0, 0), 0.15)
        elseif laughStyle == 2 then
            RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.25, 0.5, -0.5) * CFrame.Angles(math.rad(45) - math.sin(sine/7.5)/15, math.rad(30) + math.sin(sine/7.5)/15, 0), 0.15)
            LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.5, -0.5) * CFrame.Angles(math.rad(45) + math.sin(sine/7.5)/15, 0, math.rad(30)), 0.15)
            Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0 + math.sin(sine/15)/5, -0.5 + math.sin(sine/7.5)/15, 0) * CFrame.Angles(math.rad(45) - math.sin(sine/15)/15, 0, 0), 0.15)
            Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(-20) + math.sin(sine/7.5)/15, 0, 0), 0.15)
        else
            RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(0.8, 0.5, -0.65) * CFrame.Angles(math.rad(50) + math.sin(sine/15)/35, math.rad(-5) - math.sin(sine/15)/35, math.rad(-76) + math.sin(sine/15)/15), 0.15)
            LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-0.8, 0.5, -0.65) * CFrame.Angles(math.rad(45) + math.sin(sine/15)/25, math.rad(-10) + math.sin(sine/15)/45, math.rad(76) + math.sin(sine/15)/15), 0.15)
            Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(2 + math.sin(sine/7.5)/15, 0.5 + math.sin(sine/15)/5, 0) * CFrame.Angles(math.rad(50), 0, math.rad(60) + math.sin(sine/7.5)/30), 0.15)
            Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -1) * CFrame.Angles(math.rad(-60), math.rad(45), math.rad(-20)), 0.15)
        end
        
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(30), 0, math.rad(-5)), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(30), 0, math.rad(5)), 0.15)
        MaskWeld.C1 = CFrame.new(0, -0.7, -0.25) * CFrame.Angles(math.rad(90), 0, 0)
        swait()
    end
    
    Animations = false
    attack2 = false
    attack = false
end

function Attackone()
    if attack then return end
    attack = true
    fattack = true
    Animations = true
    
    local sound = Instance.new("Sound")
    sound.Parent = Character.Torso
    sound.SoundId = "rbxassetid://1890071374"
    sound.Volume = 8
    sound.Pitch = 1.7
    sound:Play()
    
    -- Set fairy positions
    TatlWeld.C1 = CFrame.new(2.5, 3, 3)
    TaelWeld.C1 = CFrame.new(-2.5, 3, 3)
    
    -- Touch connections
    local taelConn = Tael.Touched:Connect(function(hit)
        local hum = hit.Parent:FindFirstChild("Humanoid")
        if hum and hit.Parent ~= Character and hit.Parent.Name ~= target then
            target = hit.Parent.Name
            hum:TakeDamage(math.random(10, 20))
            local hitSound = Instance.new("Sound")
            hitSound.Parent = Character.Torso
            hitSound.SoundId = "rbxassetid://1907654067"
            hitSound.Volume = 8
            hitSound:Play()
        end
    end)
    
    local tatlConn = Tatl.Touched:Connect(function(hit)
        local hum = hit.Parent:FindFirstChild("Humanoid")
        if hum and hit.Parent ~= Character and hit.Parent.Name ~= target then
            target = hit.Parent.Name
            hum:TakeDamage(math.random(10, 20))
            local hitSound = Instance.new("Sound")
            hitSound.Parent = Character.Torso
            hitSound.SoundId = "rbxassetid://1907654067"
            hitSound.Volume = 8
            hitSound:Play()
        end
    end)
    
    for i = 0, 0.08, 0.01 do
        rootPart.Velocity = rootPart.CFrame.LookVector * 50
        
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.25) * CFrame.Angles(math.rad(20) - math.sin(sine/7.5)/15, math.rad(30) + math.sin(sine/7.5)/15, math.rad(5) + math.sin(sine/7.5)/15), 0.3)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.25, 0) * CFrame.Angles(math.rad(120) + math.sin(sine/7.5)/15, math.rad(10), math.rad(30)), 0.3)
        LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -0.7, -0.3) * CFrame.Angles(math.rad(-10) + math.sin(sine/15)/5, math.sin(rootPart.RotVelocity.Y / 10) / 2, math.rad(-15) - math.sin(sine/7.5)/25), 0.15)
        RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(-20) + math.sin(sine/15)/5, -math.sin(rootPart.RotVelocity.Y / 10) / 2, math.rad(-5) + math.sin(sine/7.5)/25), 0.15)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(1 + math.sin(sine/15)/5, -0.5 + math.sin(sine/7.5)/15, 0) * CFrame.Angles(math.rad(-30) - math.sin(sine/15)/15, 0, math.rad(-20)), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(10) + math.sin(sine/7.5)/15, 0, 0), 0.3)
        swait()
    end
    
    taelConn:Disconnect()
    tatlConn:Disconnect()
    
    TaelWeld.C1 = CFrame.new(0, -5, 3.5)
    TatlWeld.C1 = CFrame.new(0, -2, 3.5)
    
    target = nil
    Animations = false
    fattack = false
    attack = false
end

-- Simplified versions of other attacks
function Attacktwo()
    if attack then return end
    attack = true
    fattack = true
    Animations = true
    
    TatlWeld.C1 = CFrame.new(2.5, -6, 3)
    TaelWeld.C1 = CFrame.new(-2.5, -6, 3)
    
    local taelConn = Tael.Touched:Connect(function(hit)
        local hum = hit.Parent:FindFirstChild("Humanoid")
        if hum and hit.Parent ~= Character and hit.Parent.Name ~= target then
            target = hit.Parent.Name
            hum:TakeDamage(math.random(10, 20))
        end
    end)
    
    local tatlConn = Tatl.Touched:Connect(function(hit)
        local hum = hit.Parent:FindFirstChild("Humanoid")
        if hum and hit.Parent ~= Character and hit.Parent.Name ~= target then
            target = hit.Parent.Name
            hum:TakeDamage(math.random(10, 20))
        end
    end)
    
    for i = 0, 0.08, 0.01 do
        rootPart.Velocity = rootPart.CFrame.LookVector * 50
        RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.25) * CFrame.Angles(math.rad(20), math.rad(30), math.rad(5)), 0.3)
        LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.25, 0) * CFrame.Angles(math.rad(120), math.rad(10), math.rad(30)), 0.3)
        Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(-1, -0.5, 0) * CFrame.Angles(math.rad(-30), 0, math.rad(20)), 0.15)
        Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(10), 0, 0), 0.3)
        swait()
    end
    
    taelConn:Disconnect()
    tatlConn:Disconnect()
    
    TaelWeld.C1 = CFrame.new(0, -5, 3.5)
    TatlWeld.C1 = CFrame.new(0, -2, 3.5)
    
    target = nil
    Animations = false
    fattack = false
    attack = false
end

-- Add similar simplified versions of other attacks...

-- Keybinds
Mouse.KeyDown:Connect(function(key)
    if not attack then
        if key == "r" then Laugh()
        elseif key == "t" then Laser()
        elseif key == "v" then ShadowBomb()
        elseif key == "m" then MajorasWrath()
        elseif key == "c" then Tornado()
        elseif key == ";" then FallingMoon()
        elseif key == "b" then ShadowBarrage()
        elseif key == "n" then MagicTrap()
        end
    end
end)

Mouse.Button1Down:Connect(function()
    if not attack then
        if attk == 1 then Attackone()
        elseif attk == 2 then Attacktwo()
        elseif attk == 3 then Attackthree()
        elseif attk == 4 then Attackfour()
        elseif attk == 5 then Attackfive()
        elseif attk == 6 then Attacksix()
        elseif attk == 7 then Attackseven()
        end
        attk = attk + 1
        if attk > 7 then attk = 1 end
    end
end)

-- Sprint
UserInputService.InputBegan:Connect(function(input, processed)
    if not processed and input.KeyCode == Enum.KeyCode.LeftShift then
        sprint = true
    end
end)

UserInputService.InputEnded:Connect(function(input, processed)
    if not processed and input.KeyCode == Enum.KeyCode.LeftShift then
        sprint = false
    end
end)

-- Speed controller
coroutine.wrap(function()
    while true do
        if attack2 then
            Humanoid.WalkSpeed = 0
            Humanoid.JumpPower = 0
        elseif sprint then
            Humanoid.WalkSpeed = 25
            Humanoid.JumpPower = 100
        else
            Humanoid.WalkSpeed = 8
            Humanoid.JumpPower = 50
        end
        wait(0.1)
    end
end)()

-- Fairy idle animation
coroutine.wrap(function()
    while true do
        if not fattack then
            TaelWeld.C1 = CFrame.new(2, -3 - math.sin(sine/7.5)/20, -1)
            TatlWeld.C1 = CFrame.new(-2, -3 + math.sin(sine/7.5)/12, -1)
        end
        swait()
    end
end)()

-- Main animation loop
RunService.RenderStepped:Connect(function()
    sine = sine + change
    local walkingMagnitude = Vector3.new(rootPart.Velocity.X, 0, rootPart.Velocity.Z).Magnitude
    local jumpVel = Torso.Velocity.Y
    
    -- Determine animation state
    if Humanoid.Jump and jumpVel > 1 then
        currentAnim = "Jumping"
    elseif walkingMagnitude < 2 then
        currentAnim = "Idling"
    elseif walkingMagnitude > 2 then
        currentAnim = "Walking"
    end
    
    -- Apply animations if not in attack mode
    if not Animations then
        if currentAnim == "Idling" then
            RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.25) * CFrame.Angles(math.rad(20) - math.sin(sine/7.5)/15, math.rad(30) + math.sin(sine/7.5)/15, math.rad(5) + math.sin(sine/7.5)/15), 0.15)
            LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.25, 0) * CFrame.Angles(math.rad(90) + math.sin(sine/7.5)/15, math.rad(60), math.rad(-20)), 0.15)
            LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0) * CFrame.Angles(math.rad(30) + math.sin(sine/15)/5, 0, math.rad(-5) - math.sin(sine/7.5)/25), 0.15)
            RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(15) + math.sin(sine/15)/5, 0, math.rad(5) + math.sin(sine/7.5)/25), 0.15)
            Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0 + math.sin(sine/15)/5, -0.5 + math.sin(sine/7.5)/15, 0) * CFrame.Angles(0 - math.sin(sine/15)/15, 0, 0), 0.15)
            Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(-10) + math.sin(sine/7.5)/15, 0, 0), 0.15)
        elseif currentAnim == "Walking" then
            if sprint then
                RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.25) * CFrame.Angles(math.rad(-30), math.rad(30), math.rad(5)), 0.15)
                LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.25, 0) * CFrame.Angles(math.rad(90), math.rad(60), math.rad(-20)), 0.15)
                Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -0.5, 0) * CFrame.Angles(math.rad(-40), 0, 0), 0.15)
                Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(40), 0, 0), 0.15)
            else
                RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, -0.25) * CFrame.Angles(math.rad(-20), math.rad(30), math.rad(5)), 0.15)
                LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.25, 0.25, 0) * CFrame.Angles(math.rad(100), math.rad(60), math.rad(-20)), 0.15)
                Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -0.5, 0) * CFrame.Angles(math.rad(-30), 0, 0), 0.15)
                Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, -0.1) * CFrame.Angles(math.rad(30), 0, 0), 0.15)
            end
            LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -0.7, -0.3) * CFrame.Angles(math.rad(-10), 0, math.rad(-5)), 0.15)
            RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0) * CFrame.Angles(math.rad(-20), 0, math.rad(5)), 0.15)
        elseif currentAnim == "Jumping" then
            RA_Weld.C0 = clerp(RA_Weld.C0, CFrame.new(1.5, 0.5, 0), 0.15)
            LA_Weld.C0 = clerp(LA_Weld.C0, CFrame.new(-1.5, 0.5, 0), 0.15)
            LL_Weld.C0 = clerp(LL_Weld.C0, CFrame.new(-0.5, -1, 0), 0.15)
            RL_Weld.C0 = clerp(RL_Weld.C0, CFrame.new(0.5, -1, 0), 0.15)
            Torso_Weld.C0 = clerp(Torso_Weld.C0, CFrame.new(0, -1, 0), 0.15)
            Head_Weld.C0 = clerp(Head_Weld.C0, CFrame.new(0, 1.5, 0), 0.15)
        end
    end
end)

-- Run intro
if intro then
    Intro()
else
    Ocarina.Transparency = 0
    Mask.Transparency = 0
    Theme.SoundId = "rbxassetid://243250871"
    Theme:Play()
end

warn("Skull Kid script loaded successfully!")