--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- NEW Chat
loadstring(game:HttpGet('https://pastebin.com/raw/8Htx56Ab'))()