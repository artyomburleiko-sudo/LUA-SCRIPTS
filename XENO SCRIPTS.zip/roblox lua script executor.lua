local exe = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local EXE = Instance.new("TextButton")
local CLR = Instance.new("TextButton")
local scr = Instance.new("ScrollingFrame")
local IHATELIFE = Instance.new("TextBox")
--Properties:
exe.Name = "exe"
exe.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")

Frame.Parent = exe
Frame.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.623199403, 0, 0.384341627, 0)
Frame.Size = UDim2.new(0, 397, 0, 228)

EXE.Name = "EXE"
EXE.Parent = Frame
EXE.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
EXE.BorderSizePixel = 0
EXE.Position = UDim2.new(0.00103312731, 0, 0.779702783, 0)
EXE.Size = UDim2.new(0, 200, 0, 50)
EXE.Font = Enum.Font.SourceSans
EXE.Text = "EXECUTE"
EXE.TextColor3 = Color3.new(1, 1, 1)
EXE.TextScaled = true
EXE.TextSize = 14
EXE.TextWrapped = true

CLR.Name = "CLR"
CLR.Parent = Frame
CLR.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
CLR.BorderSizePixel = 0
CLR.Position = UDim2.new(0.503778338, 0, 0.780701756, 0)
CLR.Size = UDim2.new(0, 197, 0, 50)
CLR.Font = Enum.Font.SourceSans
CLR.Text = "CLEAR"
CLR.TextColor3 = Color3.new(1, 1, 1)
CLR.TextScaled = true
CLR.TextSize = 14
CLR.TextWrapped = true

scr.Name = "scr"
scr.Parent = Frame
scr.BackgroundColor3 = Color3.new(1, 1, 1)
scr.BorderSizePixel = 0
scr.Size = UDim2.new(0, 397, 0, 178)

IHATELIFE.Name = "IHATELIFE"
IHATELIFE.Parent = scr
IHATELIFE.BackgroundColor3 = Color3.new(0.117647, 0.117647, 0.117647)
IHATELIFE.BorderSizePixel = 0
IHATELIFE.Size = UDim2.new(0, 397, 0, 519)
IHATELIFE.ClearTextOnFocus = false
IHATELIFE.Font = Enum.Font.Code
IHATELIFE.TextColor3 = Color3.new(1, 1, 1)
IHATELIFE.TextSize = 28
IHATELIFE.TextWrapped = true
IHATELIFE.TextXAlignment = Enum.TextXAlignment.Left
IHATELIFE.TextYAlignment = Enum.TextYAlignment.Top
-- Scripts:
function SCRIPT_ZCGT71_FAKESCRIPT() -- EXE.Script 
	getfenv().script = Instance.new('Script', EXE)

	script.Parent.MouseButton1Click:Connect(function()
		loadstring(script.Parent.Parent.scr.IHATELIFE.Text)()
	end)

end
coroutine.resume(coroutine.create(SCRIPT_ZCGT71_FAKESCRIPT))
function SCRIPT_KVFU74_FAKESCRIPT() -- CLR.Script 
	getfenv().script = Instance.new('Script', CLR)

	script.Parent.MouseButton1Click:Connect(function()
		script.Parent.Parent.scr.IHATELIFE.Text = ""
	end)

end
coroutine.resume(coroutine.create(SCRIPT_KVFU74_FAKESCRIPT))