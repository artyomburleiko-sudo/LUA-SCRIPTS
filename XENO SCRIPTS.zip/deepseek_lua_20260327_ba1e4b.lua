local targetName = "Name"

local Players = game:GetService("Players")

local function getPlayerByName(name)
    for _, player in pairs(Players:GetPlayers()) do
        if string.lower(player.Name) == string.lower(name) or string.lower(player.DisplayName) == string.lower(name) then
            return player
        end
    end
    return nil
end

local target = getPlayerByName(targetName)
if target then
    workspace.Gravity = 0
end