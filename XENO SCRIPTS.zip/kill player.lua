local target = "Namehere"

local Players = game:GetService("Players")

for _, v in pairs(Players:GetPlayers()) do
    if v.Name:lower():sub(1,#target) == target:lower() then

        if not (v.Character and v.Character:FindFirstChild("HumanoidRootPart")) then return end
        local tchar = v.Character
        local thrp = tchar.HumanoidRootPart

        local plr = Players.LocalPlayer
        local char = plr.Character or plr.CharacterAdded:Wait()
        local hum = char:FindFirstChildOfClass("Humanoid")
        local hrp = char:WaitForChild("HumanoidRootPart")
        local cam = workspace.CurrentCamera
        local anim = char:WaitForChild("Animate")
        char.Humanoid.Health =  0
        local clone = hum:Clone()
        clone.Parent = char
        hum:Destroy()

        char.Humanoid:TakeDamage(20)
        char.Humanoid:ChangeState(15)

        cam.CameraSubject = char
        anim.Disabled = true
        anim.Disabled = false
        
        local tool = plr.Backpack:FindFirstChildOfClass("Tool")
        if tool then
            clone:EquipTool(tool)
        end

        task.wait(0.2)

        hrp.CFrame = thrp.CFrame * CFrame.new(0, 0, -0)

    end
end

--Guardamiento De Respawn

local Players = game:GetService("Players")
local LocalPlayer = Players.LocalPlayer

local Character = LocalPlayer.Character or LocalPlayer.CharacterAdded:Wait()
local Root = Character:WaitForChild("HumanoidRootPart")


local GuardarCFrame = Root.CFrame

LocalPlayer.CharacterAdded:Wait()
task.wait(0.1)
LocalPlayer.Character:WaitForChild("HumanoidRootPart").CFrame = GuardarCFrame