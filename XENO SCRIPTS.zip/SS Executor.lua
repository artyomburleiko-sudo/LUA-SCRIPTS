--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
local SS = Instance.new("ScreenGui") -- Renamed to SS
SS.Name = "SS"
SS.Parent = game.CoreGui
SS.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

local Frame = Instance.new("Frame")
Frame.Parent = SS
Frame.BackgroundColor3 = Color3.fromRGB(120, 0, 0) -- Dark red background
Frame.BorderColor3 = Color3.fromRGB(80, 0, 0) -- Slightly darker red border
Frame.BorderSizePixel = 1
Frame.Position = UDim2.new(0.132, 0, 0.17, 0)
Frame.Size = UDim2.new(0, 332, 0, 252)
Frame.Active = true
Frame.Draggable = true

-- Minimize Button ("-")
local minimize = Instance.new("TextButton")
minimize.Name = "minimize"
minimize.Parent = Frame
minimize.BackgroundTransparency = 1 -- No background
minimize.BorderSizePixel = 0
minimize.Position = UDim2.new(0.87, 0, 0, 0)
minimize.Size = UDim2.new(0, 20, 0, 20)
minimize.Font = Enum.Font.SourceSans
minimize.Text = "-"
minimize.TextColor3 = Color3.fromRGB(255, 255, 255)
minimize.TextSize = 16

minimize.MouseButton1Click:Connect(function()
    Frame.Visible = false
end)

-- Close Button ("X")
local close = Instance.new("TextButton")
close.Name = "close"
close.Parent = Frame
close.BackgroundTransparency = 1 -- No background
close.BorderSizePixel = 0
close.Position = UDim2.new(0.93, 0, 0, 0)
close.Size = UDim2.new(0, 20, 0, 20)
close.Font = Enum.Font.SourceSans
close.Text = "X"
close.TextColor3 = Color3.fromRGB(255, 255, 255)
close.TextSize = 16

close.MouseButton1Click:Connect(function()
    SS:Destroy()
end)

local main = Instance.new("Frame")
main.Name = "main"
main.Parent = Frame
main.BackgroundColor3 = Color3.fromRGB(90, 0, 0) -- Even darker red for main frame
main.BorderColor3 = Color3.fromRGB(60, 0, 0)
main.Position = UDim2.new(0.006, 0, 0.104, 0)
main.Size = UDim2.new(0, 327, 0, 225)

local ScrollingFrame = Instance.new("ScrollingFrame")
ScrollingFrame.Parent = main
ScrollingFrame.Active = true
ScrollingFrame.BackgroundColor3 = Color3.fromRGB(110, 0, 0) -- Dark red for scrolling frame
ScrollingFrame.BorderColor3 = Color3.fromRGB(80, 0, 0)
ScrollingFrame.Position = UDim2.new(0, 0, 0.089, 0)
ScrollingFrame.Selectable = false
ScrollingFrame.Size = UDim2.new(0, 286, 0, 205)

local input = Instance.new("TextBox")
input.Name = "input"
input.Parent = ScrollingFrame
input.BackgroundColor3 = Color3.fromRGB(255, 255, 255) -- White background for the input field
input.BorderColor3 = Color3.fromRGB(0, 0, 0)
input.BorderSizePixel = 0
input.Position = UDim2.new(0, 0, 0, 0)
input.Size = UDim2.new(0, 272, 0, 449)
input.Font = Enum.Font.SourceSans
input.Text = ""
input.TextColor3 = Color3.fromRGB(0, 0, 0) -- Black text for contrast
input.TextSize = 14
input.TextXAlignment = Enum.TextXAlignment.Left
input.TextYAlignment = Enum.TextYAlignment.Top
input.MultiLine = true

-- SS EXE Button
local execSS = Instance.new("TextButton")
execSS.Name = "execSS"
execSS.Parent = main
execSS.BackgroundColor3 = Color3.fromRGB(150, 0, 0) -- Dark red for "SS EXE" button
execSS.BorderSizePixel = 0 -- Removed white border
execSS.Position = UDim2.new(0.878, 0, 0.089, 0) -- Original position
execSS.Size = UDim2.new(0, 40, 0, 102)
execSS.Font = Enum.Font.SourceSans
execSS.Text = "SS EXE"
execSS.TextColor3 = Color3.fromRGB(255, 255, 255)
execSS.TextScaled = true
execSS.TextSize = 14
execSS.TextWrapped = true

execSS.MouseButton1Click:Connect(function()
    game.ReplicatedStorage.RemoteEvent:FireServer(input.Text)
end)

-- Clear Button
local clear = Instance.new("TextButton")
clear.Name = "clear"
clear.Parent = main
clear.BackgroundColor3 = Color3.fromRGB(150, 0, 0) -- Dark red for "CLEAR" button
clear.BorderSizePixel = 0 -- Removed white border
clear.Position = UDim2.new(0.878, 0, 0.547, 0) -- Original position
clear.Size = UDim2.new(0, 40, 0, 102)
clear.Font = Enum.Font.SourceSans
clear.Text = "CLEAR"
clear.TextColor3 = Color3.fromRGB(255, 255, 255)
clear.TextScaled = true
clear.TextSize = 14
clear.TextWrapped = true

clear.MouseButton1Click:Connect(function()
    input.Text = ""
end)

Comments_.Name = "Comments_"
Comments_.Parent = Source
Comments_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Comments_.BackgroundTransparency = 1.000
Comments_.Size = UDim2.new(1, 0, 1, 0)
Comments_.ZIndex = 5
Comments_.Font = Enum.Font.Code
Comments_.Text = ""
Comments_.TextColor3 = Color3.fromRGB(59, 200, 59)
Comments_.TextSize = 15.000
Comments_.TextXAlignment = Enum.TextXAlignment.Left
Comments_.TextYAlignment = Enum.TextYAlignment.Top

Globals_.Name = "Globals_"
Globals_.Parent = Source
Globals_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Globals_.BackgroundTransparency = 1.000
Globals_.Size = UDim2.new(1, 0, 1, 0)
Globals_.ZIndex = 5
Globals_.Font = Enum.Font.Code
Globals_.Text = ""
Globals_.TextColor3 = Color3.fromRGB(132, 214, 247)
Globals_.TextSize = 15.000
Globals_.TextXAlignment = Enum.TextXAlignment.Left
Globals_.TextYAlignment = Enum.TextYAlignment.Top

Keywords_.Name = "Keywords_"
Keywords_.Parent = Source
Keywords_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Keywords_.BackgroundTransparency = 1.000
Keywords_.Size = UDim2.new(1, 0, 1, 0)
Keywords_.ZIndex = 5
Keywords_.Font = Enum.Font.Code
Keywords_.Text = ""
Keywords_.TextColor3 = Color3.fromRGB(248, 109, 124)
Keywords_.TextSize = 15.000
Keywords_.TextXAlignment = Enum.TextXAlignment.Left
Keywords_.TextYAlignment = Enum.TextYAlignment.Top

RemoteHighlight_.Name = "RemoteHighlight_"
RemoteHighlight_.Parent = Source
RemoteHighlight_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
RemoteHighlight_.BackgroundTransparency = 1.000
RemoteHighlight_.Size = UDim2.new(1, 0, 1, 0)
RemoteHighlight_.ZIndex = 5
RemoteHighlight_.Font = Enum.Font.Code
RemoteHighlight_.Text = ""
RemoteHighlight_.TextColor3 = Color3.fromRGB(0, 144, 255)
RemoteHighlight_.TextSize = 15.000
RemoteHighlight_.TextXAlignment = Enum.TextXAlignment.Left
RemoteHighlight_.TextYAlignment = Enum.TextYAlignment.Top

Strings_.Name = "Strings_"
Strings_.Parent = Source
Strings_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Strings_.BackgroundTransparency = 1.000
Strings_.Size = UDim2.new(1, 0, 1, 0)
Strings_.ZIndex = 5
Strings_.Font = Enum.Font.Code
Strings_.Text = ""
Strings_.TextColor3 = Color3.fromRGB(173, 241, 149)
Strings_.TextSize = 15.000
Strings_.TextXAlignment = Enum.TextXAlignment.Left
Strings_.TextYAlignment = Enum.TextYAlignment.Top

Tokens_.Name = "Tokens_"
Tokens_.Parent = Source
Tokens_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Tokens_.BackgroundTransparency = 1.000
Tokens_.Size = UDim2.new(1, 0, 1, 0)
Tokens_.ZIndex = 5
Tokens_.Font = Enum.Font.Code
Tokens_.Text = ""
Tokens_.TextColor3 = Color3.fromRGB(255, 255, 255)
Tokens_.TextSize = 15.000
Tokens_.TextXAlignment = Enum.TextXAlignment.Left
Tokens_.TextYAlignment = Enum.TextYAlignment.Top

Numbers_.Name = "Numbers_"
Numbers_.Parent = Source
Numbers_.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Numbers_.BackgroundTransparency = 1.000
Numbers_.Size = UDim2.new(1, 0, 1, 0)
Numbers_.ZIndex = 4
Numbers_.Font = Enum.Font.Code
Numbers_.Text = ""
Numbers_.TextColor3 = Color3.fromRGB(255, 198, 0)
Numbers_.TextSize = 15.000
Numbers_.TextXAlignment = Enum.TextXAlignment.Left
Numbers_.TextYAlignment = Enum.TextYAlignment.Top

local lua_keywords = {"and", "break", "do", "else", "elseif", "end", "false", "for", "function", "goto", "if", "in", "local", "nil", "not", "or", "repeat", "return", "then", "true", "until", "while", "is_synapse_function","is_protosmasher_caller", "execute","foreach","foreachi","insert","syn","HttpGet","HttpPost","__index","__namecall","__add","__call","__tostring","__tonumber","__div"}
local global_env = {"getrawmetatable", "game", "workspace", "script", "math", "string", "table", "print", "wait", "BrickColor", "Color3", "next", "pairs", "ipairs", "select", "unpack", "Instance", "Vector2", "Vector3", "CFrame", "Ray", "UDim2", "Enum", "assert", "error", "warn", "tick", "loadstring", "_G", "shared", "getfenv", "setfenv", "newproxy", "setmetatable", "getmetatable", "os", "debug", "pcall", "ypcall", "xpcall", "rawequal", "rawset", "rawget", "tonumber", "tostring", "type", "typeof", "_VERSION", "coroutine", "delay", "require", "spawn", "LoadLibrary", "settings", "stats", "time", "UserSettings", "version", "Axes", "ColorSequence", "Faces", "ColorSequenceKeypoint", "NumberRange", "NumberSequence", "NumberSequenceKeypoint", "gcinfo", "elapsedTime", "collectgarbage", "PhysicalProperties", "Rect", "Region3", "Region3int16", "UDim", "Vector2int16", "Vector3int16","run_secure_function","create_secure_function","hookfunc","hookfunction","newcclosure","replaceclosure","islclosure","getgc","gcinfo","rconsolewarn","rconsoleprint","rconsoleinfo","rconsoleinput","rconsoleinputasync","rconsoleclear","rconsoleerr",}

local src = Source
local lin = Lines

local Highlight = function(string, keywords)
local K = {}
local S = string
local Token =
{
["="] = true,
["."] = true,
[","] = true,
["("] = true,
[")"] = true,
["["] = true,
["]"] = true,
["{"] = true,
["}"] = true,
[":"] = true,
["*"] = true,
["/"] = true,
["+"] = true,
["-"] = true,
["%"] = true,
[";"] = true,
["~"] = true
}
for i, v in pairs(keywords) do
K[v] = true
end
S = S:gsub(".", function(c)
if Token[c] ~= nil then
return "\32"
else
return c
end
end)
S = S:gsub("%S+", function(c)
if K[c] ~= nil then
return c
else
return (" "):rep(#c)
end
end)

return S
end

local hTokens = function(string)
local Token =
{
["="] = true,
["."] = true,
[","] = true,
["("] = true,
[")"] = true,
["["] = true,
["]"] = true,
["{"] = true,
["}"] = true,
[":"] = true,
["*"] = true,
["/"] = true,
["+"] = true,
["-"] = true,
["%"] = true,
[";"] = true,
["~"] = true
}
local A = ""
local B = [[]]
string:gsub(".", function(c)
if Token[c] ~= nil then
A = A .. c
elseif c == "\n" then
A = A .. "\n"
elseif c == "\t" then
A = A .. "\t"
else
A = A .. "\32"
end
end)
return A
end


local strings = function(string)
local highlight = ""
local quote = false
string:gsub(".", function(c)
if quote == false and c == "\"" then
quote = true
elseif quote == true and c == "\"" then
quote = false
end
if quote == false and c == "\"" then
highlight = highlight .. "\""
elseif c == "\n" then
highlight = highlight .. "\n"
elseif c == "\t" then
highlight = highlight .. "\t"
elseif quote == true then
highlight = highlight .. c
elseif quote == false then
highlight = highlight .. "\32"
end
end)

return highlight
end

local comments = function(string)
local ret = ""
string:gsub("[^\r\n]+", function(c)
local comm = false
local i = 0
c:gsub(".", function(n)
i = i + 1
if c:sub(i, i + 1) == "--" then
comm = true
end
if comm == true then
ret = ret .. n
else
ret = ret .. "\32"
end
end)
ret = ret
end)

return ret
end

local numbers = function(string)
local A = ""
string:gsub(".", function(c)
if tonumber(c) ~= nil then
A = A .. c
elseif c == "\n" then
A = A .. "\n"
elseif c == "\t" then
A = A .. "\t"
else
A = A .. "\32"
end
end)

return A
end

local highlight_source = function(type)
if type == "Text" then
src.Text = Source.Text:gsub("\13", "")
src.Text = Source.Text:gsub("\t", "      ")
local s = src.Text
src.Keywords_.Text = Highlight(s, lua_keywords)
src.Globals_.Text = Highlight(s, global_env)
src.RemoteHighlight_.Text = Highlight(s, {"FireServer", "fireServer", "InvokeServer", "invokeServer"})
src.Tokens_.Text = hTokens(s)
src.Numbers_.Text = numbers(s)
src.Strings_.Text = strings(s)
local lin = 1
s:gsub("\n", function()
lin = lin + 1
end)
Lines.Text = ""
for i = 1, lin do
Lines.Text = Lines.Text .. i .. "\n"
end
end
end

highlight_source("Text")

src.Changed:Connect(highlight_source)
exec.MouseButton1Click:Connect(function()
assert(loadstring(Source.Text))()
end)
clear.MouseButton1Click:Connect(function()
   Source.Text = ""
end)
execSS.MouseButton1Click:Connect(function()
   game.ReplicatedStorage.RemoteEvent:FireServer(Source.Text)
end)

Main.Active = true
Main.Draggable = true