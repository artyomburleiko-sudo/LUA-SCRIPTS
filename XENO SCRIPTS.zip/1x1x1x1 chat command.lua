local player = game.Players.LocalPlayer
local replicatedStorage = game:GetService("ReplicatedStorage")
local workspace = game:GetService("Workspace")
local lighting = game:GetService("Lighting")
local players = game:GetService("Players")
local userInputService = game:GetService("UserInputService")
local tweenService = game:GetService("TweenService")

-- Переменные для GUI
local guiVisible = true
local mainFrame = nil
local minimizedHeight = 40
local expandedHeight = 450

-- Список всех команд
local commands = {
    {
        name = "1x1x1x1",
        description = "Запускает сообщения 1x1x1x1 в чат",
        category = "Атака",
        icon = "💀"
    },
    {
        name = "music",
        description = "Включает музыку 1x1x1x1",
        category = "Звук",
        icon = "🎵"
    },
    {
        name = "laugh",
        description = "Включает смех 1x1x1x1",
        category = "Звук",
        icon = "😈"
    },
    {
        name = "night",
        description = "Устанавливает ночное время",
        category = "Освещение",
        icon = "🌙"
    },
    {
        name = "666",
        description = "Активирует режим тьмы и огня",
        category = "Эффекты",
        icon = "🔥"
    },
    {
        name = "sax",
        description = "Включает Epic Sax Guy",
        category = "Звук",
        icon = "🎷"
    },
    {
        name = "disco",
        description = "Активирует диско режим на 30 сек",
        category = "Эффекты",
        icon = "🪩"
    },
    {
        name = "2006",
        description = "Включает музыку 2006 года",
        category = "Звук",
        icon = "📼"
    },
    {
        name = "ff on",
        description = "Включает силовое поле",
        category = "Защита",
        icon = "🛡️"
    },
    {
        name = "ff off",
        description = "Выключает силовое поле",
        category = "Защита",
        icon = "🔓"
    },
    {
        name = "clear",
        description = "Очищает весь огонь",
        category = "Утилиты",
        icon = "🧹"
    }
}

-- Функция для отправки сообщений в чат
function sendChatMessage(message)
    local args = {
        [1] = message,
        [2] = "All"
    }
    game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(unpack(args))
end

-- Функция для воспроизведения звука
function playSound(soundId, pitch, volume)
    local sound = Instance.new("Sound")
    sound.SoundId = "rbxassetid://" .. soundId
    sound.Volume = volume or 1
    sound.Pitch = pitch or 1
    sound.Parent = workspace
    sound:Play()
    
    sound.Ended:Connect(function()
        sound:Destroy()
    end)
end

-- Функция для показа сообщения игроку
function notifyPlayer(message)
    game.StarterGui:SetCore("SendNotification", {
        Title = "1x1x1x1 System",
        Text = message,
        Duration = 5
    })
end

-- Функция создания GUI
function createGUI()
    -- Создаем основной фрейм
    mainFrame = Instance.new("ScreenGui")
    mainFrame.Name = "CommandsGUI"
    mainFrame.Parent = player:WaitForChild("PlayerGui")
    mainFrame.ResetOnSpawn = false
    mainFrame.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
    
    -- Полупрозрачный фон для всего экрана
    local screenOverlay = Instance.new("Frame")
    screenOverlay.Name = "ScreenOverlay"
    screenOverlay.Parent = mainFrame
    screenOverlay.Size = UDim2.new(1, 0, 1, 0)
    screenOverlay.Position = UDim2.new(0, 0, 0, 0)
    screenOverlay.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
    screenOverlay.BackgroundTransparency = 0.3
    screenOverlay.Active = false
    screenOverlay.Visible = true
    
    -- Основной контейнер
    local container = Instance.new("Frame")
    container.Name = "Container"
    container.Parent = mainFrame
    container.Size = UDim2.new(0, 800, 0, expandedHeight)
    container.Position = UDim2.new(0.5, -400, 0, 10)
    container.BackgroundColor3 = Color3.fromRGB(25, 25, 35)
    container.BackgroundTransparency = 0.05
    container.BorderSizePixel = 0
    container.Active = true
    container.Draggable = false
    
    -- Добавляем закругленные углы
    local containerCorner = Instance.new("UICorner")
    containerCorner.CornerRadius = UDim.new(0, 10)
    containerCorner.Parent = container
    
    -- Тень
    local shadow = Instance.new("ImageLabel")
    shadow.Name = "Shadow"
    shadow.Parent = container
    shadow.Size = UDim2.new(1, 40, 1, 40)
    shadow.Position = UDim2.new(0, -20, 0, -20)
    shadow.BackgroundTransparency = 1
    shadow.Image = "rbxassetid://6014261993"
    shadow.ImageColor3 = Color3.fromRGB(0, 0, 0)
    shadow.ImageTransparency = 0.5
    shadow.ScaleType = Enum.ScaleType.Slice
    shadow.SliceCenter = Rect.new(10, 10, 118, 118)
    
    -- Верхняя панель
    local topBar = Instance.new("Frame")
    topBar.Name = "TopBar"
    topBar.Parent = container
    topBar.Size = UDim2.new(1, 0, 0, 40)
    topBar.Position = UDim2.new(0, 0, 0, 0)
    topBar.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
    topBar.BackgroundTransparency = 0.1
    topBar.BorderSizePixel = 0
    
    local topBarCorner = Instance.new("UICorner")
    topBarCorner.CornerRadius = UDim.new(0, 10)
    topBarCorner.Parent = topBar
    
    -- Заголовок
    local titleLabel = Instance.new("TextLabel")
    titleLabel.Name = "TitleLabel"
    titleLabel.Parent = topBar
    titleLabel.Size = UDim2.new(1, -80, 1, 0)
    titleLabel.Position = UDim2.new(0, 15, 0, 0)
    titleLabel.BackgroundTransparency = 1
    titleLabel.Text = "🔱 1x1x1x1 COMMANDS 🔱"
    titleLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
    titleLabel.TextSize = 20
    titleLabel.Font = Enum.Font.GothamBold
    titleLabel.TextXAlignment = Enum.TextXAlignment.Left
    
    -- Кнопка сворачивания
    local toggleButton = Instance.new("TextButton")
    toggleButton.Name = "ToggleButton"
    toggleButton.Parent = topBar
    toggleButton.Size = UDim2.new(0, 30, 0, 30)
    toggleButton.Position = UDim2.new(1, -40, 0, 5)
    toggleButton.BackgroundColor3 = Color3.fromRGB(255, 100, 100)
    toggleButton.BackgroundTransparency = 0.2
    toggleButton.Text = "−"
    toggleButton.TextColor3 = Color3.fromRGB(255, 255, 255)
    toggleButton.TextSize = 20
    toggleButton.Font = Enum.Font.GothamBold
    toggleButton.BorderSizePixel = 0
    
    local buttonCorner = Instance.new("UICorner")
    buttonCorner.CornerRadius = UDim.new(0, 5)
    buttonCorner.Parent = toggleButton
    
    -- Список команд
    local commandsList = Instance.new("ScrollingFrame")
    commandsList.Name = "CommandsList"
    commandsList.Parent = container
    commandsList.Size = UDim2.new(1, -20, 1, -60)
    commandsList.Position = UDim2.new(0, 10, 0, 50)
    commandsList.BackgroundColor3 = Color3.fromRGB(20, 20, 30)
    commandsList.BackgroundTransparency = 0.2
    commandsList.BorderSizePixel = 0
    commandsList.ScrollBarThickness = 8
    commandsList.ScrollBarImageColor3 = Color3.fromRGB(255, 100, 100)
    commandsList.CanvasSize = UDim2.new(0, 0, 0, #commands * 70)
    
    local listCorner = Instance.new("UICorner")
    listCorner.CornerRadius = UDim.new(0, 8)
    listCorner.Parent = commandsList
    
    -- Создаем кнопки для каждой команды
    for i, cmd in ipairs(commands) do
        local yPos = (i - 1) * 70
        
        local cmdFrame = Instance.new("Frame")
        cmdFrame.Name = "Cmd_" .. cmd.name
        cmdFrame.Parent = commandsList
        cmdFrame.Size = UDim2.new(1, -15, 0, 65)
        cmdFrame.Position = UDim2.new(0, 10, 0, yPos + 5)
        cmdFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
        cmdFrame.BackgroundTransparency = 0.3
        cmdFrame.BorderSizePixel = 0
        
        local cmdCorner = Instance.new("UICorner")
        cmdCorner.CornerRadius = UDim.new(0, 6)
        cmdCorner.Parent = cmdFrame
        
        -- Иконка команды
        local iconLabel = Instance.new("TextLabel")
        iconLabel.Name = "Icon"
        iconLabel.Parent = cmdFrame
        iconLabel.Size = UDim2.new(0, 50, 1, 0)
        iconLabel.Position = UDim2.new(0, 10, 0, 0)
        iconLabel.BackgroundTransparency = 1
        iconLabel.Text = cmd.icon
        iconLabel.TextColor3 = Color3.fromRGB(255, 200, 100)
        iconLabel.TextSize = 30
        iconLabel.Font = Enum.Font.GothamBold
        
        -- Название команды
        local nameLabel = Instance.new("TextLabel")
        nameLabel.Name = "Name"
        nameLabel.Parent = cmdFrame
        nameLabel.Size = UDim2.new(0, 150, 0, 25)
        nameLabel.Position = UDim2.new(0, 70, 0, 8)
        nameLabel.BackgroundTransparency = 1
        nameLabel.Text = "!" .. cmd.name
        nameLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
        nameLabel.TextSize = 18
        nameLabel.Font = Enum.Font.GothamBold
        nameLabel.TextXAlignment = Enum.TextXAlignment.Left
        
        -- Категория
        local categoryLabel = Instance.new("TextLabel")
        categoryLabel.Name = "Category"
        categoryLabel.Parent = cmdFrame
        categoryLabel.Size = UDim2.new(0, 150, 0, 18)
        categoryLabel.Position = UDim2.new(0, 70, 0, 33)
        categoryLabel.BackgroundTransparency = 1
        categoryLabel.Text = cmd.category
        categoryLabel.TextColor3 = Color3.fromRGB(150, 150, 150)
        categoryLabel.TextSize = 12
        categoryLabel.Font = Enum.Font.Gotham
        categoryLabel.TextXAlignment = Enum.TextXAlignment.Left
        
        -- Описание
        local descLabel = Instance.new("TextLabel")
        descLabel.Name = "Description"
        descLabel.Parent = cmdFrame
        descLabel.Size = UDim2.new(1, -320, 1, -16)
        descLabel.Position = UDim2.new(0, 230, 0, 8)
        descLabel.BackgroundTransparency = 1
        descLabel.Text = cmd.description
        descLabel.TextColor3 = Color3.fromRGB(200, 200, 200)
        descLabel.TextSize = 14
        descLabel.Font = Enum.Font.Gotham
        descLabel.TextXAlignment = Enum.TextXAlignment.Left
        descLabel.TextWrapped = true
        
        -- Кнопка Execute
        local cmdExecuteBtn = Instance.new("TextButton")
        cmdExecuteBtn.Name = "Execute"
        cmdExecuteBtn.Parent = cmdFrame
        cmdExecuteBtn.Size = UDim2.new(0, 90, 0, 35)
        cmdExecuteBtn.Position = UDim2.new(1, -100, 0, 15)
        cmdExecuteBtn.BackgroundColor3 = Color3.fromRGB(255, 100, 100)
        cmdExecuteBtn.Text = "⚡ EXECUTE"
        cmdExecuteBtn.TextColor3 = Color3.fromRGB(255, 255, 255)
        cmdExecuteBtn.TextSize = 12
        cmdExecuteBtn.Font = Enum.Font.GothamBold
        cmdExecuteBtn.BorderSizePixel = 0
        
        local btnCorner = Instance.new("UICorner")
        btnCorner.CornerRadius = UDim.new(0, 4)
        btnCorner.Parent = cmdExecuteBtn
        
        -- Подсветка при наведении
        cmdExecuteBtn.MouseEnter:Connect(function()
            cmdExecuteBtn.BackgroundColor3 = Color3.fromRGB(255, 150, 150)
        end)
        
        cmdExecuteBtn.MouseLeave:Connect(function()
            cmdExecuteBtn.BackgroundColor3 = Color3.fromRGB(255, 100, 100)
        end)
        
        -- Обработчик кнопки
        cmdExecuteBtn.MouseButton1Click:Connect(function()
            executeCommand(cmd.name)
        end)
        
        -- Подсветка при наведении на фрейм
        cmdFrame.MouseEnter:Connect(function()
            cmdFrame.BackgroundColor3 = Color3.fromRGB(45, 45, 55)
        end)
        
        cmdFrame.MouseLeave:Connect(function()
            cmdFrame.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
        end)
    end
    
    -- Информационная панель снизу
    local infoPanel = Instance.new("Frame")
    infoPanel.Name = "InfoPanel"
    infoPanel.Parent = container
    infoPanel.Size = UDim2.new(1, -20, 0, 35)
    infoPanel.Position = UDim2.new(0, 10, 1, -45)
    infoPanel.BackgroundColor3 = Color3.fromRGB(35, 35, 45)
    infoPanel.BackgroundTransparency = 0.3
    infoPanel.BorderSizePixel = 0
    
    local infoCorner = Instance.new("UICorner")
    infoCorner.CornerRadius = UDim.new(0, 6)
    infoCorner.Parent = infoPanel
    
    local infoText = Instance.new("TextLabel")
    infoText.Name = "InfoText"
    infoText.Parent = infoPanel
    infoText.Size = UDim2.new(1, -20, 1, 0)
    infoText.Position = UDim2.new(0, 10, 0, 0)
    infoText.BackgroundTransparency = 1
    infoText.Text = "⚡ Всего команд: " .. #commands .. " | Нажмите EXECUTE для выполнения | Кнопка − свернуть"
    infoText.TextColor3 = Color3.fromRGB(180, 180, 180)
    infoText.TextSize = 12
    infoText.Font = Enum.Font.Gotham
    infoText.TextXAlignment = Enum.TextXAlignment.Left
    
    return mainFrame
end

-- Функция переключения видимости
function toggleGUI()
    if not mainFrame then return end
    
    local container = mainFrame:FindFirstChild("Container")
    local screenOverlay = mainFrame:FindFirstChild("ScreenOverlay")
    local toggleBtn = container and container.TopBar:FindFirstChild("ToggleButton")
    
    if container then
        guiVisible = not guiVisible
        
        local targetHeight = guiVisible and expandedHeight or minimizedHeight
        local tweenInfo = TweenInfo.new(0.3, Enum.EasingStyle.Quad, Enum.EasingDirection.Out)
        local tween = tweenService:Create(container, tweenInfo, {Size = UDim2.new(0, 800, 0, targetHeight)})
        tween:Play()
        
        if toggleBtn then
            toggleBtn.Text = guiVisible and "−" or "+"
        end
        
        if screenOverlay then
            screenOverlay.Visible = guiVisible
        end
    end
end

-- Функция обработки команд
function executeCommand(command)
    command = command:lower()
    
    if command == "1x1x1x1" then
        notifyPlayer("Запуск сообщений 1x1x1x1...")
        coroutine.wrap(function()
            wait(12)
            sendChatMessage("1x1x1x1: MUHAWHAWHAW! NOOBS! I HAVE RETURNED FOR MY REVENGE!")
            wait(10)
            sendChatMessage("1x1x1x1: NOW YOU WILL ALL PERISH IN MY FIRE OF DOOM!")
            wait(10)
            sendChatMessage("1x1x1x1: I WILL DESTROY YOU ALL! YOU ARE WORTHLESS!")
            wait(10)
            sendChatMessage("1x1x1x1: YOU WILL NOT LIVE THROUGH MY DEADLY ATTACKS!")
            wait(10)
            sendChatMessage("1x1x1x1: I MIGHT AS WELL CLONE YOU INTO BOTS!")
            wait(10)
            sendChatMessage("1x1x1x1: AND THEN THOSE BOTS WILL DESTROY ROBLOX! HAHAHAHAHA!")
            wait(10)
            sendChatMessage("1x1x1x1: YOU CAN'T STOP ME! THERE'S NOTHING YOU CAN DO!")
        end)()
        
    elseif command == "music" then
        playSound("139488665764275", 1, 10)
        notifyPlayer("Играет музыка 1x1x1x1")
        
    elseif command == "laugh" then
        playSound("35935204", 0.9, 10)
        notifyPlayer("1x1x1x1 смеется")
        
    elseif command == "night" then
        lighting.ClockTime = 18
        notifyPlayer("Установлено время: ночь")
        
    elseif command == "666" then
        lighting.ClockTime = 0
        notifyPlayer("Активирован режим 666")
        
        for i, v in pairs(workspace:GetDescendants()) do
            if v:IsA("BasePart") and not v:IsA("Terrain") then
                local fire = Instance.new("Fire")
                fire.Parent = v
            end
        end
        
    elseif command == "sax" then
        playSound("99930819694048", 0.302, 10)
        notifyPlayer("Epic Sax Guy активирован")
        
    elseif command == "disco" then
        notifyPlayer("Диско режим активирован на 30 секунд")
        coroutine.wrap(function()
            local colors = {Color3.fromRGB(255,0,0), Color3.fromRGB(0,255,0), Color3.fromRGB(0,0,255), 
                            Color3.fromRGB(255,255,0), Color3.fromRGB(255,0,255), Color3.fromRGB(0,255,255)}
            
            for i = 1, 30 do
                lighting.Ambient = colors[math.random(1, #colors)]
                lighting.ColorShift_Top = colors[math.random(1, #colors)]
                lighting.ColorShift_Bottom = colors[math.random(1, #colors)]
                wait(0.3)
            end
            
            lighting.Ambient = Color3.fromRGB(0, 0, 0)
            lighting.ColorShift_Top = Color3.fromRGB(0, 0, 0)
            lighting.ColorShift_Bottom = Color3.fromRGB(0, 0, 0)
        end)()
        
    elseif command == "2006" then
        playSound("125591252722564", 0.13, 10)
        notifyPlayer("Играет музыка 2006")
        
    elseif command == "ff on" then
        if player.Character and player.Character:FindFirstChild("Humanoid") then
            local FF = Instance.new("ForceField")
            FF.Parent = player.Character
            notifyPlayer("Силовое поле включено")
        end
        
    elseif command == "ff off" then
        if player.Character then
            local forceField = player.Character:FindFirstChildOfClass("ForceField")
            if forceField then
                forceField:Destroy()
                notifyPlayer("Силовое поле выключено")
            end
        end
        
    elseif command == "clear" then
        for i, v in pairs(workspace:GetDescendants()) do
            if v:IsA("Fire") then
                v:Destroy()
            end
        end
        notifyPlayer("Огонь очищен")
    end
end

-- Создаем GUI при запуске
createGUI()

-- Настраиваем обработчик кнопки сворачивания
if mainFrame then
    local container = mainFrame:FindFirstChild("Container")
    if container then
        local toggleBtn = container.TopBar:FindFirstChild("ToggleButton")
        if toggleBtn then
            toggleBtn.MouseButton1Click:Connect(toggleGUI)
        end
    end
end

-- Приветственное сообщение
notifyPlayer("🔱 1x1x1x1 Commands загружен! " .. #commands .. " команд с кнопками Execute")