-- FE Air Walk Script (Полностью клиентский)
local FLY_SCRIPT = [[

local Players = game:GetService("Players")
local RunService = game:GetService("RunService")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")

-- Настройки
local AIR_WALK_ENABLED = true
local PLATFORM_DURATION = 2 -- секунды
local PLATFORM_SIZE = Vector3.new(4, 1, 4)
local VERTICAL_SPEED = 50 -- скорость движения вверх/вниз

-- Клавиши для движения вверх/вниз
local UP_KEY = Enum.KeyCode.E
local DOWN_KEY = Enum.KeyCode.Q

-- Таблица для хранения созданных платформ
local activePlatforms = {}
local verticalVelocity = 0
local verticalDirection = 0

-- Создаем папку для платформ (для организации)
local platformFolder = Instance.new("Folder")
platformFolder.Name = "AirWalkPlatforms_" .. player.Name
platformFolder.Parent = workspace

-- Создаем BindableEvent для синхронизации (опционально)
local bindableEvent = Instance.new("BindableEvent")
bindableEvent.Name = "PlatformSync"
bindableEvent.Parent = player:WaitForChild("PlayerGui")

-- Функция создания платформы (только клиентская)
local function createPlatform(position)
    -- Создаем локальную платформу (видна только игроку)
    local platform = Instance.new("Part")
    platform.Name = "AirPlatform_" .. tick()
    platform.Size = PLATFORM_SIZE
    platform.Position = position + Vector3.new(0, -3, 0) -- Немного ниже ног
    platform.Anchored = true
    platform.CanCollide = true
    platform.CanTouch = false -- Отключаем триггеры для безопасности
    platform.CanQuery = false -- Отключаем запросы для оптимизации
    platform.Transparency = 0.7 -- Полупрозрачная
    platform.Material = Enum.Material.Neon
    platform.Color = Color3.fromRGB(0, 170, 255)
    platform.BrickColor = BrickColor.new("Bright blue")
    
    -- Добавляем освещение
    local pointLight = Instance.new("PointLight")
    pointLight.Brightness = 1
    pointLight.Range = 8
    pointLight.Color = Color3.fromRGB(0, 170, 255)
    pointLight.Parent = platform
    
    -- Добавляем частицы для эффекта
    local attachment = Instance.new("Attachment")
    attachment.Parent = platform
    
    local particles = Instance.new("ParticleEmitter")
    particles.Texture = "rbxasset://textures/particles/sparkles_main.dds"
    particles.Lifetime = NumberRange.new(0.5, 1)
    particles.Rate = 10
    particles.SpreadAngle = Vector2.new(180, 180)
    particles.VelocityInheritance = 0
    particles.Color = ColorSequence.new(Color3.fromRGB(0, 170, 255))
    particles.Size = NumberSequence.new(0.2)
    particles.Transparency = NumberSequence.new(0.5)
    particles.Parent = attachment
    
    -- Добавляем в папку
    platform.Parent = platformFolder
    
    -- Добавляем в таблицу с временем создания
    table.insert(activePlatforms, {
        part = platform,
        creationTime = tick(),
        particles = particles
    })
    
    -- Создаем звук шагов (опционально)
    if math.random(1, 3) == 1 then -- Случайно, чтобы не спамить звуками
        local sound = Instance.new("Sound")
        sound.SoundId = "rbxasset://sounds/collide/glass_small.mp3"
        sound.Volume = 0.2
        sound.PlaybackSpeed = 1.5
        sound.Parent = platform
        sound:Play()
        
        -- Удаляем звук после воспроизведения
        game:GetService("Debris"):AddItem(sound, 1)
    end
    
    return platform
end

-- Функция очистки старых платформ
local function cleanupOldPlatforms()
    local currentTime = tick()
    for i = #activePlatforms, 1, -1 do
        local platformData = activePlatforms[i]
        if currentTime - platformData.creationTime > PLATFORM_DURATION then
            -- Эффект исчезновения
            if platformData.particles then
                platformData.particles.Enabled = false
            end
            
            -- Звук исчезновения
            local sound = Instance.new("Sound")
            sound.SoundId = "rbxasset://sounds/collide/glass_small.mp3"
            sound.Volume = 0.1
            sound.PlaybackSpeed = 0.8
            sound.Parent = platformData.part
            sound:Play()
            
            -- Удаляем платформу
            platformData.part:Destroy()
            table.remove(activePlatforms, i)
        end
    end
end

-- Функция для обработки вертикального движения
local function updateVerticalMovement(dt)
    local rootPart = character:FindFirstChild("HumanoidRootPart")
    if not rootPart then return end
    
    -- Обновляем вертикальную скорость
    verticalVelocity = VERTICAL_SPEED * verticalDirection
    
    -- Применяем вертикальное движение
    if verticalVelocity ~= 0 then
        -- Получаем текущую позицию
        local currentPosition = rootPart.Position
        
        -- Вычисляем новую позицию с учетом вертикального движения
        local newPosition = currentPosition + Vector3.new(0, verticalVelocity * dt, 0)
        
        -- Проверяем, есть ли препятствия выше/ниже
        local raycastParams = RaycastParams.new()
        raycastParams.FilterDescendantsInstances = {character, platformFolder} -- Игнорируем свои платформы
        raycastParams.FilterType = Enum.RaycastFilterType.Blacklist
        
        local raycastResult = workspace:Raycast(
            currentPosition,
            Vector3.new(0, verticalVelocity * dt, 0),
            raycastParams
        )
        
        if not raycastResult then
            -- Если нет препятствий, перемещаем персонажа
            rootPart.CFrame = CFrame.new(newPosition)
            
            -- Создаем платформу при движении вверх/вниз
            if verticalDirection ~= 0 then
                createPlatform(newPosition)
            end
        end
    end
end

-- Обработчик ввода
local function handleInput(input, gameProcessed)
    if gameProcessed then return end
    
    if input.KeyCode == UP_KEY then
        if input.UserInputState == Enum.UserInputState.Begin then
            verticalDirection = 1
        elseif input.UserInputState == Enum.UserInputState.End then
            verticalDirection = 0
        end
    elseif input.KeyCode == DOWN_KEY then
        if input.UserInputState == Enum.UserInputState.Begin then
            verticalDirection = -1
        elseif input.UserInputState == Enum.UserInputState.End then
            verticalDirection = 0
        end
    end
end

-- Подписываемся на события ввода
UserInputService.InputBegan:Connect(handleInput)
UserInputService.InputEnded:Connect(handleInput)

-- Основной цикл
local connection
if AIR_WALK_ENABLED then
    connection = RunService.Heartbeat:Connect(function(dt)
        -- Проверяем персонажа
        character = player.Character
        if not character then return end
        
        humanoid = character:FindFirstChild("Humanoid")
        if not humanoid or humanoid.Health <= 0 then return end
        
        -- Обрабатываем вертикальное движение
        updateVerticalMovement(dt)
        
        -- Проверяем горизонтальное движение
        local moveDirection = humanoid.MoveDirection
        if moveDirection.Magnitude > 0 then
            local rootPart = character:FindFirstChild("HumanoidRootPart")
            if rootPart then
                -- Создаем платформу под ногами
                createPlatform(rootPart.Position)
            end
        end
        
        -- Очищаем старые платформы
        cleanupOldPlatforms()
    end)
end

-- Функция для переподключения при смерти
local function onCharacterAdded(newCharacter)
    character = newCharacter
    humanoid = character:WaitForChild("Humanoid")
    
    -- Сбрасываем состояние
    verticalVelocity = 0
    verticalDirection = 0
    
    -- Удаляем все старые платформы
    for _, platformData in ipairs(activePlatforms) do
        platformData.part:Destroy()
    end
    activePlatforms = {}
end

player.CharacterAdded:Connect(onCharacterAdded)

-- Очистка при выходе
local function onWindowFocusReleased()
    if connection then
        connection:Disconnect()
    end
    -- Удаляем все платформы
    for _, platformData in ipairs(activePlatforms) do
        platformData.part:Destroy()
    end
    activePlatforms = {}
    
    -- Удаляем папку
    if platformFolder then
        platformFolder:Destroy()
    end
end

UserInputService.WindowFocusReleased:Connect(onWindowFocusReleased)

-- Обработка ошибок
local function onError()
    if connection then
        connection:Disconnect()
    end
    -- Очистка при ошибке
    for _, platformData in ipairs(activePlatforms) do
        platformData.part:Destroy()
    end
    activePlatforms = {}
end

-- Защита от разрывов соединения
game:GetService("CoreGui").ChildRemoved:Connect(function(child)
    if child == platformFolder then
        onError()
    end
end)

-- Информация для пользователя
print("=== Air Walk FE активирован! ===")
print("Движение: WASD или стрелки")
print("Вверх: E | Вниз: Q")
print("Платформы исчезают через " .. PLATFORM_DURATION .. " секунд")
print("Создано платформ: 0")
print("================================")

-- Счетчик платформ для информации
local lastCount = 0
spawn(function()
    while connection and connection.Connected do
        wait(1)
        local currentCount = #activePlatforms
        if currentCount ~= lastCount then
            print("Активных платформ: " .. currentCount)
            lastCount = currentCount
        end
    end
end)
]]

-- Функция для безопасной загрузки скрипта
local function loadAirWalk()
    -- Проверяем, что это клиент
    if not game:GetService("RunService"):IsClient() then
        warn("Этот скрипт может быть запущен только на клиенте!")
        return
    end
    
    -- Загружаем и выполняем скрипт
    local success, result = pcall(function()
        local func = loadstring(FLY_SCRIPT)
        if func then
            return func()
        else
            error("Не удалось скомпилировать скрипт")
        end
    end)
    
    if success then
        print("✓ Скрипт Air Walk FE успешно загружен!")
    else
        warn("✗ Ошибка при загрузке скрипта Air Walk FE: " .. tostring(result))
    end
end

-- Защищенный запуск
local protectedLoad = pcall(loadAirWalk)
if not protectedLoad then
    warn("Не удалось запустить Air Walk FE")
end

-- Альтернативный метод загрузки (если первый не сработал)
spawn(function()
    wait(0.5)
    if not game:GetService("RunService"):IsClient() then
        return
    end
    
    -- Повторная попытка загрузки если нужно
    local success, result = pcall(function()
        loadstring(FLY_SCRIPT)()
    end)
    
    if success then
        print("✓ Air Walk FE загружен (альтернативный метод)")
    end
end)