--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
local player = game.Players.LocalPlayer
local playerGui = player:WaitForChild("PlayerGui")

if playerGui:FindFirstChild("StigmaUltimate") then
	playerGui.StigmaUltimate:Destroy()
end

local gui = Instance.new("ScreenGui", playerGui)
gui.Name = "StigmaUltimate"

local frame = Instance.new("Frame", gui)
frame.Size = UDim2.new(0, 350, 0, 180)
frame.Position = UDim2.new(0.1, 0, 0.1, 0)
frame.BackgroundColor3 = Color3.new(1, 1, 1)
frame.BorderSizePixel = 1
frame.Active = true
frame.Draggable = true

-- Layered text for title (TextLabels)
local function createThickTextLabel(parent, text, position, size, textSize)
	local offsets = {
		Vector2.new(-1,0),
		Vector2.new(1,0),
		Vector2.new(0,-1),
		Vector2.new(0,1),
	}
	for _,offset in ipairs(offsets) do
		local shadow = Instance.new("TextLabel", parent)
		shadow.Size = size
		shadow.Position = UDim2.new(position.X.Scale, position.X.Offset + offset.X, position.Y.Scale, position.Y.Offset + offset.Y)
		shadow.BackgroundTransparency = 1
		shadow.Text = text
		shadow.Font = Enum.Font.Legacy
		shadow.TextColor3 = Color3.new(0, 0, 0)
		shadow.TextSize = textSize
		shadow.TextXAlignment = Enum.TextXAlignment.Left
		shadow.ZIndex = 1
	end
	local label = Instance.new("TextLabel", parent)
	label.Size = size
	label.Position = position
	label.BackgroundTransparency = 1
	label.Text = text
	label.Font = Enum.Font.Legacy
	label.TextColor3 = Color3.new(0, 0, 0)
	label.TextSize = textSize
	label.TextXAlignment = Enum.TextXAlignment.Left
	label.ZIndex = 2
	return label
end

local title = createThickTextLabel(frame, "stigma v3", UDim2.new(0,3,0,2), UDim2.new(0,150,0,30), 12)

local textbox = Instance.new("TextBox", frame)
textbox.Size = UDim2.new(0, 230, 0, 140)
textbox.Position = UDim2.new(0, 5, 0, 40)
textbox.ClearTextOnFocus = false
textbox.MultiLine = true
textbox.Text = ""
textbox.Font = Enum.Font.Legacy
textbox.TextColor3 = Color3.new(0, 0, 0)
textbox.BackgroundColor3 = Color3.new(1, 1, 1)
textbox.BorderSizePixel = 1
textbox.TextSize = 10
textbox.TextWrapped = true
textbox.TextXAlignment = Enum.TextXAlignment.Left
textbox.TextYAlignment = Enum.TextYAlignment.Top

-- Function to create thick TextButton (5 layered buttons with offsets)
local function createThickButton(parent, text, position, size, textSize, callback)
	local offsets = {
		Vector2.new(-1,0),
		Vector2.new(1,0),
		Vector2.new(0,-1),
		Vector2.new(0,1),
	}
	local buttons = {}
	for _,offset in ipairs(offsets) do
		local btn = Instance.new("TextButton", parent)
		btn.Size = size
		btn.Position = UDim2.new(position.X.Scale, position.X.Offset + offset.X, position.Y.Scale, position.Y.Offset + offset.Y)
		btn.BackgroundColor3 = Color3.new(0.9, 0.9, 0.9)
		btn.BorderSizePixel = 1
		btn.Text = text
		btn.Font = Enum.Font.Legacy
		btn.TextColor3 = Color3.new(0, 0, 0)
		btn.TextSize = textSize
		btn.AutoButtonColor = false
		btn.ZIndex = 1
		btn.TextWrapped = false
		table.insert(buttons, btn)
	end
	local mainBtn = Instance.new("TextButton", parent)
	mainBtn.Size = size
	mainBtn.Position = position
	mainBtn.BackgroundColor3 = Color3.new(0.9, 0.9, 0.9)
	mainBtn.BorderSizePixel = 1
	mainBtn.Text = text
	mainBtn.Font = Enum.Font.Legacy
	mainBtn.TextColor3 = Color3.new(0, 0, 0)
	mainBtn.TextSize = textSize
	mainBtn.AutoButtonColor = true
	mainBtn.ZIndex = 2
	mainBtn.TextWrapped = false

	mainBtn.MouseButton1Click:Connect(callback)

	return mainBtn
end

local execute = createThickButton(frame, "EXE", UDim2.new(0, 240, 0, 40), UDim2.new(0, 100, 0, 50), 12, function()
	pcall(function()
		loadstring(textbox.Text)()
	end)
end)

local clear = createThickButton(frame, "CLEAR", UDim2.new(0, 240, 0, 95), UDim2.new(0, 100, 0, 50), 12, function()
	textbox.Text = ""
end)
