--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
-- Define o player
local player = game.Players.LocalPlayer
local character = player.Character or player.CharacterAdded:Wait()
local humanoid = character:WaitForChild("Humanoid")
local humanoidRootPart = character:WaitForChild("HumanoidRootPart")

local uis = game:GetService("UserInputService")
local runService = game:GetService("RunService")
local lighting = game:GetService("Lighting")
local players = game:GetService("Players")

-- Som 1: Primeiro som a ser tocado
local sound1 = Instance.new("Sound")
sound1.SoundId = "rbxassetid://862484466"
sound1.Volume = 1
sound1.Parent = workspace

-- URLs dos scripts
local GRABKNIFE_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/grab-knife/refs/heads/main/Grab%20V4.txt"
local AK47_URL = "https://raw.githubusercontent.com/sinret/rbxscript.com-scripts-reuploads-/main/ak47"
local METALPIPE_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/metal-pip/refs/heads/main/metal%20pipe"
local XESTER_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/xester/refs/heads/main/qC7MUFRJ.txt"
local BACKDOORSCANNER_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/blocs-of-death/refs/heads/main/blocs%20of%20death"
local SGLITCHER_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/SCPECTRUMGLITCHER/refs/heads/main/SpectrumG%20(1).txt"
local C00LGUI_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/c00lgui/refs/heads/main/c00lguiv3rx.lua.txt"
local SINDRAGON_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/sin-dragon/refs/heads/main/Fe_sin_dragon_music_customizado_final.lua"
local HANDRAVAGE_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/sin-dragon/refs/heads/main/reevenge%20hands.txt"
local VEREUS_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/xester/refs/heads/main/fLrx77PM.txt"
local JOHNDOE_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/metal-pip/refs/heads/main/john_doe_with_esp.lua"
local GOODCOP_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/good-cop-bad-coop/refs/heads/main/KwuminKa.txt"
local GASTERHANDS_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/good-cop-bad-coop/refs/heads/main/GasterHands.txt"
local FUNNYFLY_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/fix-game/refs/heads/main/funny%20fly"
local FIX_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/fix-game/refs/heads/main/fix.lua"
local CRYSTALDANCE_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/crytasl/refs/heads/main/Krystal%20Dance%20V2.lua.txt"
local GONER_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/crytasl/refs/heads/main/goner.lua.txt"
local SERVEADMIN_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/crytasl/refs/heads/main/serveradmin.lua"
local BANHAMMER_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/ban-hammer/refs/heads/main/ban"
local THESUN_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/the-sun/refs/heads/main/the%20sun"
local KILLBOT_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/rare/refs/heads/main/killbot.lua"
local KITCHENGUN_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/rare/refs/heads/main/kitcher%20gun.lua"
local GRAKED_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/grakkeda/refs/heads/main/Roblox%20Genkadda%20omega%20leaked.txt"
local KIRITO_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/the-angel/refs/heads/main/Kirito%20Blades.txt"
local ANGEL_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/the-angel/refs/heads/main/The%20Angel.txt"
local NEBULA_URL = "https://raw.githubusercontent.com/nicolasbarbosa323/nebulaglitcher/refs/heads/main/Nebula's%20Star%20Glitcher%20(EDITED%20BY%20FENIX7667%20IMORTAL%20EDIT%20).txt"

-- Guardar o som atual tocando
local currentMusic = nil

-- Função para criar botões
local function createButton(name, url, musicId, parent, posY)
    local button = Instance.new("TextButton")
    button.Size = UDim2.new(0, 200, 0, 40)
    button.Position = UDim2.new(0, 10, 0, posY)
    button.BackgroundColor3 = Color3.fromRGB(50, 50, 50)
    button.TextColor3 = Color3.fromRGB(255, 255, 255)
    button.Font = Enum.Font.SourceSansBold
    button.TextSize = 18
    button.Text = name
    button.Parent = parent

    button.MouseButton1Click:Connect(function()
        -- Parar a música anterior
        if currentMusic then
            currentMusic:Stop()
            currentMusic:Destroy()
            currentMusic = nil
        end

        -- Criar e tocar a nova música, se houver
        if musicId and musicId ~= "" then
            local sound = Instance.new("Sound", workspace)
            sound.SoundId = "rbxassetid://" .. musicId
            sound.Volume = 2
            sound.Looped = true
            sound:Play()
            currentMusic = sound
        end

        -- Executar o script
        local success, result = pcall(function()
            loadstring(game:HttpGet(url))()
        end)
        if not success then
            warn("Erro ao executar o script: " .. tostring(result))
        end
    end)
end

-- Criar a interface
local screenGui = Instance.new("ScreenGui")
screenGui.Name = "UTG_BY_NICOLASPIETRO"
screenGui.Parent = game.CoreGui

local mainFrame = Instance.new("Frame")
mainFrame.Size = UDim2.new(0, 240, 0, 500)
mainFrame.Position = UDim2.new(0, 10, 0, 0.1)
mainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
mainFrame.Active = true
mainFrame.Draggable = true
mainFrame.Parent = screenGui

local title = Instance.new("TextLabel")
title.Size = UDim2.new(1, 0, 0, 40)
title.BackgroundColor3 = Color3.fromRGB(20, 20, 20)
title.TextColor3 = Color3.fromRGB(255, 255, 255)
title.Font = Enum.Font.SourceSansBold
title.TextSize = 20
title.Text = "UTG BY NICOLASPIETRO"
title.Parent = mainFrame

-- ScrollFrame para comportar os botões
local scrollFrame = Instance.new("ScrollingFrame")
scrollFrame.Size = UDim2.new(1, 0, 1, -40)
scrollFrame.Position = UDim2.new(0, 0, 0, 40)
scrollFrame.CanvasSize = UDim2.new(0, 0, 0, 0)
scrollFrame.ScrollBarThickness = 8
scrollFrame.BackgroundTransparency = 1
scrollFrame.Parent = mainFrame

-- Lista de botões
local buttons = {
    {"Grab Knife V4", GRABKNIFE_URL, "16190760285"},
    {"AK47", AK47_URL, "1845149698"},
    {"Metal Pipe", METALPIPE_URL, ""},
    {"Xester", XESTER_URL, "16190760285"},
    {"Blocs of Death", BACKDOORSCANNER_URL, ""},
    {"Spectrum Glitcher", SGLITCHER_URL, "1845805363"},
    {"C00lGui", C00LGUI_URL, ""},
    {"Sin Dragon", SINDRAGON_URL, ""},
    {"Revenge Hands", HANDRAVAGE_URL, "112461424977148"},
    {"Vereus", VEREUS_URL, "1845149698"},
    {"John Doe", JOHNDOE_URL, ""},
    {"Good Cop Bad Cop", GOODCOP_URL, "1845805363"},
    {"Gaster Hands", GASTERHANDS_URL, "1838626744"},
    {"Funnyfly", FUNNYFLY_URL, ""},
    {"Fix", FIX_URL, "1840271919"},
    {"CrystalDance", CRYSTALDANCE_URL, ""},
    {"Goner", GONER_URL, "1845149698"},
    {"Serveradmin", SERVEADMIN_URL, "9038254260"},
    {"Ban hammer", BANHAMMER_URL, "9038254260"},
    {"grakeddar", GRAKED_URL, "9038254260"},
    {"kirito blades", KIRITO_URL, "9038254260"},
    {"THE angel", ANGEL_URL, "1838626744"},
    {"The Sun", THESUN_URL, ""},
    {"Killbot", KILLBOT_URL, ""},
    {"Kitchen Gun", KITCHENGUN_URL, ""},
    {"Nebula starglitcher", NEBULA_URL, ""},
}

-- Criar os botões dentro do scroll frame
for i, info in ipairs(buttons) do
    createButton(info[1], info[2], info[3], scrollFrame, (i - 1) * 45)
end

-- Ajustar o tamanho do canvas do scroll para caber todos os botões
scrollFrame.CanvasSize = UDim2.new(0, 0, 0, #buttons * 45)

-- Parar música quando o jogador morrer
player.CharacterAdded:Connect(function(character)
    local humanoid = character:WaitForChild("Humanoid")
    humanoid.Died:Connect(function()
        if currentMusic then
            currentMusic:Stop()
            currentMusic:Destroy()
            currentMusic = nil
        end
    end)
end)