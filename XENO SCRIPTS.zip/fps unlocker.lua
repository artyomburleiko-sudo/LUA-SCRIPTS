--[[
	WARNING: Heads up! This script has not been verified by ScriptBlox. Use at your own risk!
]]
setfflag("TaskSchedulerTargetFps", "500")