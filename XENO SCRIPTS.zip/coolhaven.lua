loadstring(game:HttpGet("https://raw.githubusercontent.com/magoozelote/w/main/w.lua"))() 
-- // More scripts: https://t.me/+X-HS7qugKIQ0MTRi