local ScreenGui = Instance.new("ScreenGui")
local MainFrame = Instance.new("Frame")
local TitleLabel = Instance.new("TextLabel")
local AntiBanEnableButton = Instance.new("TextButton")
local AntiBanDisableButton = Instance.new("TextButton")
local UICorner = Instance.new("UICorner")
local StatusLabel = Instance.new("TextLabel")

-- Настройка GUI
ScreenGui.Name = "AntiBanGUI"
ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ResetOnSpawn = false
ScreenGui.DisplayOrder = 999999  -- Высокий приоритет отображения
ScreenGui.IgnoreGuiInset = true   -- Игнорировать интерфейс Roblox

-- Основной фрейм
MainFrame.Name = "MainFrame"
MainFrame.Parent = ScreenGui
MainFrame.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
MainFrame.Position = UDim2.new(0.8, 0, 0.1, 0)
MainFrame.Size = UDim2.new(0, 250, 0, 200)  -- Увеличил высоту для двух кнопок
MainFrame.Active = true
MainFrame.Draggable = true

-- Скругление углов
UICorner.Parent = MainFrame
UICorner.CornerRadius = UDim.new(0, 10)

-- Заголовок
TitleLabel.Name = "TitleLabel"
TitleLabel.Parent = MainFrame
TitleLabel.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
TitleLabel.Size = UDim2.new(1, 0, 0, 30)
TitleLabel.Position = UDim2.new(0, 0, 0, 0)
TitleLabel.Text = "AntiBan System"
TitleLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TitleLabel.Font = Enum.Font.GothamBold
TitleLabel.TextSize = 16

-- Кнопка Enable
AntiBanEnableButton.Name = "AntiBanEnableButton"
AntiBanEnableButton.Parent = MainFrame
AntiBanEnableButton.BackgroundColor3 = Color3.fromRGB(50, 255, 50)
AntiBanEnableButton.Size = UDim2.new(0.8, 0, 0, 35)
AntiBanEnableButton.Position = UDim2.new(0.1, 0, 0.2, 0)
AntiBanEnableButton.Text = "ANTIBAN ENABLE"
AntiBanEnableButton.TextColor3 = Color3.fromRGB(0, 0, 0)
AntiBanEnableButton.Font = Enum.Font.GothamBold
AntiBanEnableButton.TextSize = 14

-- Кнопка Disable
AntiBanDisableButton.Name = "AntiBanDisableButton"
AntiBanDisableButton.Parent = MainFrame
AntiBanDisableButton.BackgroundColor3 = Color3.fromRGB(255, 50, 50)
AntiBanDisableButton.Size = UDim2.new(0.8, 0, 0, 35)
AntiBanDisableButton.Position = UDim2.new(0.1, 0, 0.45, 0)
AntiBanDisableButton.Text = "ANTIBAN DISABLE"
AntiBanDisableButton.TextColor3 = Color3.fromRGB(255, 255, 255)
AntiBanDisableButton.Font = Enum.Font.GothamBold
AntiBanDisableButton.TextSize = 14

-- Скругление кнопок
local EnableButtonCorner = Instance.new("UICorner")
EnableButtonCorner.Parent = AntiBanEnableButton
EnableButtonCorner.CornerRadius = UDim.new(0, 5)

local DisableButtonCorner = Instance.new("UICorner")
DisableButtonCorner.Parent = AntiBanDisableButton
DisableButtonCorner.CornerRadius = UDim.new(0, 5)

-- Статус
StatusLabel.Name = "StatusLabel"
StatusLabel.Parent = MainFrame
StatusLabel.BackgroundColor3 = Color3.fromRGB(45, 45, 45)
StatusLabel.Size = UDim2.new(0.9, 0, 0, 25)
StatusLabel.Position = UDim2.new(0.05, 0, 0.75, 0)
StatusLabel.Text = "Status: Disabled"
StatusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
StatusLabel.Font = Enum.Font.Gotham
StatusLabel.TextSize = 12

-- Скругление статуса
local StatusCorner = Instance.new("UICorner")
StatusCorner.Parent = StatusLabel
StatusCorner.CornerRadius = UDim.new(0, 5)

-- Переменная состояния
local isAntiBanEnabled = false
local antiBanConnections = {}
local protectLoopRunning = false

-- Функция обхода анти-читы и защиты от бана
local function enableAntiBan()
    if isAntiBanEnabled then return end
    isAntiBanEnabled = true
    
    -- Обновляем статус сразу
    StatusLabel.Text = "Status: Enabled"
    StatusLabel.TextColor3 = Color3.fromRGB(100, 255, 100)
    
    -- Защита от ошибок при использовании недопустимых функций
    local success, err = pcall(function()
        -- 1. Перехват отправки данных (защита от RemoteEvent детектов)
        local oldFireServer
        if not oldFireServer then
            oldFireServer = Instance.new("RemoteEvent").FireServer
        end
        
        Instance.prototype.FireServer = function(self, ...)
            -- Пропускаем только события не связанные с баном
            local args = {...}
            local skip = false
            
            -- Список ключевых слов для блокировки
            local blockKeywords = {"ban", "kick", "detect", "exploit", "cheat", "auto", "script", "hack", "inject", "mod"}
            
            -- Проверяем аргументы на наличие ключевых слов
            for _, arg in pairs(args) do
                if type(arg) == "string" then
                    for _, keyword in pairs(blockKeywords) do
                        if string.find(string.lower(arg), keyword) then
                            skip = true
                            warn("[AntiBan] Блокировка подозрительного RemoteEvent: " .. arg)
                            break
                        end
                    end
                end
                if skip then break end
            end
            
            -- Пропускаем если не нужно блокировать
            if not skip and isAntiBanEnabled then
                return oldFireServer(self, ...)
            end
        end
    end)
    
    if not success then
        warn("[AntiBan] Ошибка при настройке FireServer: " .. tostring(err))
    end
    
    -- 2. Защита от удаления GUI
    local function protectGUI()
        -- Восстанавливаем GUI если удален
        if not ScreenGui or not ScreenGui.Parent then
            pcall(function()
                ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
            end)
        end
        
        -- Защита от изменения свойств
        if ScreenGui and ScreenGui.Enabled == false then
            ScreenGui.Enabled = true
        end
    end
    
    -- 3. Блокировка обнаружения через CoreGui
    pcall(function()
        if not game:GetService("CoreGui"):FindFirstChild(ScreenGui.Name) then
            ScreenGui.Parent = game:GetService("CoreGui")  -- Прячем в CoreGui (если доступно)
        end
    end)
    
    -- 4. Создание поддельных скриптов для отвлечения
    pcall(function()
        local decoyScript = Instance.new("LocalScript")
        decoyScript.Name = "AntiCheatBypass"
        decoyScript.Source = "-- Пустой скрипт для обмана анти-чита"
        decoyScript.Parent = game.Players.LocalPlayer
        decoyScript.Disabled = true  -- Не выполняем
    end)
    
    -- 5. Мониторинг и блокировка подозрительных событий
    pcall(function()
        local connection
        connection = game:GetService("LogService").MessageOut:Connect(function(message, messageType)
            if messageType == Enum.MessageType.MessageError then
                if string.find(message, "Kick") or string.find(message, "Ban") then
                    warn("[AntiBan] Обнаружена попытка кика: " .. message)
                    -- Пытаемся предотвратить кик (не всегда работает)
                end
            end
        end)
        table.insert(antiBanConnections, connection)
    end)
    
    -- 6. Подмена данных о выполнении скриптов (если доступно)
    pcall(function()
        -- Проверяем наличие функций исполнителя
        if getrawmetatable and setreadonly and newcclosure and getnamecallmethod then
            local mt = getrawmetatable(game)
            local oldNamecall = mt.__namecall
            setreadonly(mt, false)
            
            mt.__namecall = newcclosure(function(...)
                local method = getnamecallmethod()
                local args = {...}
                
                -- Перехват запросов на определение чит-программ
                if method == "FireServer" and isAntiBanEnabled then
                    local eventName = tostring(args[1])
                    if string.find(eventName, "Check") or string.find(eventName, "Detect") or string.find(eventName, "Scan") then
                        warn("[AntiBan] Блокировка проверки: " .. eventName)
                        return
                    end
                end
                
                return oldNamecall(...)
            end)
            
            setreadonly(mt, true)
        end
    end)
    
    -- 7. Скрытие имени исполнителя (если доступно)
    pcall(function()
        if identifyexecutor then
            local oldIdentify = identifyexecutor
            identifyexecutor = function()
                return "Roblox Studio"
            end
        end
    end)
    
    -- Запускаем цикл защиты GUI
    if not protectLoopRunning then
        protectLoopRunning = true
        spawn(function()
            while isAntiBanEnabled do
                protectGUI()
                
                -- Проверяем целостность GUI
                if not ScreenGui or not ScreenGui.Parent then
                    pcall(function()
                        ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
                    end)
                end
                
                -- Скрываемся от детектов - меняем имя случайным образом
                if ScreenGui and math.random(1, 10) == 1 then  -- Иногда меняем имя
                    local names = {"Settings", "UI", "Menu", "Interface", "HUD", "System", "Config", "Panel"}
                    ScreenGui.Name = names[math.random(1, #names)] .. tostring(math.random(100, 999))
                end
                
                wait(2)
            end
            protectLoopRunning = false
        end)
    end
    
    warn("[AntiBan] Система защиты активирована")
end

-- Функция отключения защиты
local function disableAntiBan()
    if not isAntiBanEnabled then return end
    isAntiBanEnabled = false
    
    -- Обновляем статус
    StatusLabel.Text = "Status: Disabled"
    StatusLabel.TextColor3 = Color3.fromRGB(255, 100, 100)
    
    -- Отключаем все соединения
    for _, connection in pairs(antiBanConnections) do
        pcall(function()
            connection:Disconnect()
        end)
    end
    antiBanConnections = {}
    
    -- Восстанавливаем оригинальные функции (пытаемся)
    pcall(function()
        Instance.prototype.FireServer = nil
    end)
    
    -- Восстанавливаем метатаблицы (если доступно)
    pcall(function()
        if getrawmetatable and setreadonly then
            local mt = getrawmetatable(game)
            setreadonly(mt, false)
            mt.__namecall = nil
            setreadonly(mt, true)
        end
    end)
    
    -- Восстанавливаем identifyexecutor (если доступно)
    pcall(function()
        if oldIdentifyExecutor then
            identifyexecutor = oldIdentifyExecutor
        end
    end)
    
    warn("[AntiBan] Система защиты отключена")
end

-- Функция для кнопки Enable
local function onEnableClick()
    enableAntiBan()
end

-- Функция для кнопки Disable
local function onDisableClick()
    disableAntiBan()
end

-- Подключаем обработчики клика
AntiBanEnableButton.MouseButton1Click:Connect(onEnableClick)
AntiBanDisableButton.MouseButton1Click:Connect(onDisableClick)

-- Защита от закрытия и удаления
ScreenGui.ChildRemoved:Connect(function(child)
    if child == AntiBanEnableButton or child == AntiBanDisableButton then
        task.wait(0.1)
        if not AntiBanEnableButton.Parent then
            AntiBanEnableButton.Parent = MainFrame
        end
        if not AntiBanDisableButton.Parent then
            AntiBanDisableButton.Parent = MainFrame
        end
    end
end)

-- Защита от изменения родителя
local oldParent = ScreenGui.Parent
ScreenGui:GetPropertyChangedSignal("Parent"):Connect(function()
    if not ScreenGui.Parent or ScreenGui.Parent == nil then
        task.wait(0.1)
        pcall(function()
            ScreenGui.Parent = game:GetService("CoreGui") or game.Players.LocalPlayer:WaitForChild("PlayerGui")
        end)
    end
end)

-- Дополнительная защита через метатаблицы (если доступно)
pcall(function()
    if getrawmetatable and setreadonly then
        -- Для поддерживаемых исполнителей
        local gui = ScreenGui
        local mt = getrawmetatable(gui)
        setreadonly(mt, false)
        
        local oldIndex = mt.__index
        mt.__index = function(self, key)
            if key == "Parent" and self == gui then
                -- Возвращаем всегда существующий Parent
                return game.Players.LocalPlayer:FindFirstChild("PlayerGui") or game:GetService("CoreGui")
            end
            return oldIndex(self, key)
        end
        
        setreadonly(mt, true)
    end
end)

print("AntiBan GUI загружен. Используйте кнопки ENABLE/DISABLE для управления защитой.")