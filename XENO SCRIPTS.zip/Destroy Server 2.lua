-- Gui to Lua
-- Version: 3.2

-- Instances:

local ScreenGui = Instance.new("ScreenGui")
local Frame = Instance.new("Frame")
local TextButton = Instance.new("TextButton")
local TextLabel = Instance.new("TextLabel")
local TextButton_2 = Instance.new("TextButton")
local TextButton_3 = Instance.new("TextButton")
local TextButton_4 = Instance.new("TextButton")
local TextButton_5 = Instance.new("TextButton")
local TextButton_6 = Instance.new("TextButton")
local TextButton_7 = Instance.new("TextButton")
local ImageLabel = Instance.new("ImageLabel")
local ImageLabel_2 = Instance.new("ImageLabel")

--Properties:

ScreenGui.Parent = game.Players.LocalPlayer:WaitForChild("PlayerGui")
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.Position = UDim2.new(0.0410256237, 0, 0.0372670814, 0)
Frame.Size = UDim2.new(0, 272, 0, 579)

TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton.Position = UDim2.new(0.106617644, 0, 0.07772021, 0)
TextButton.Size = UDim2.new(0, 200, 0, 50)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "Get toasted roasted"
TextButton.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton.TextSize = 14.000

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.Position = UDim2.new(0.106617637, 0, 0.0138169248, 0)
TextLabel.Size = UDim2.new(0, 200, 0, 22)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "Server Destroyer Gui by samir3216 1.0"
TextLabel.TextColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.TextSize = 14.000

TextButton_2.Parent = Frame
TextButton_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_2.Position = UDim2.new(0.106617644, 0, 0.196891189, 0)
TextButton_2.Size = UDim2.new(0, 200, 0, 50)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "NootNoot"
TextButton_2.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_2.TextSize = 14.000

TextButton_3.Parent = Frame
TextButton_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_3.Position = UDim2.new(0.106617644, 0, 0.333333343, 0)
TextButton_3.Size = UDim2.new(0, 200, 0, 50)
TextButton_3.Font = Enum.Font.SourceSans
TextButton_3.Text = "Roblox anti-piracy fake made by samir3216"
TextButton_3.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_3.TextSize = 14.000

TextButton_4.Parent = Frame
TextButton_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_4.Position = UDim2.new(0.106617644, 0, 0.471502602, 0)
TextButton_4.Size = UDim2.new(0, 200, 0, 50)
TextButton_4.Font = Enum.Font.SourceSans
TextButton_4.Text = "Inject Virus Script From Free Models"
TextButton_4.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_4.TextSize = 14.000

TextButton_5.Parent = Frame
TextButton_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_5.Position = UDim2.new(0.106617644, 0, 0.611398935, 0)
TextButton_5.Size = UDim2.new(0, 200, 0, 50)
TextButton_5.Font = Enum.Font.SourceSans
TextButton_5.Text = "Block Abuse"
TextButton_5.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_5.TextSize = 14.000

TextButton_6.Parent = Frame
TextButton_6.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_6.Position = UDim2.new(0.106617644, 0, 0.7564767, 0)
TextButton_6.Size = UDim2.new(0, 200, 0, 50)
TextButton_6.Font = Enum.Font.SourceSans
TextButton_6.Text = "LAG"
TextButton_6.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_6.TextSize = 14.000

TextButton_7.Parent = Frame
TextButton_7.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextButton_7.Position = UDim2.new(0.106617644, 0, 0.879101872, 0)
TextButton_7.Size = UDim2.new(0, 200, 0, 50)
TextButton_7.Font = Enum.Font.SourceSans
TextButton_7.Text = "Smash!"
TextButton_7.TextColor3 = Color3.fromRGB(0, 0, 0)
TextButton_7.TextSize = 14.000

ImageLabel.Parent = Frame
ImageLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel.Position = UDim2.new(0.838235378, 0, 0, 0)
ImageLabel.Size = UDim2.new(0, 44, 0, 45)
ImageLabel.Image = "http://www.roblox.com/asset/?id=9966241"

ImageLabel_2.Parent = ScreenGui
ImageLabel_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ImageLabel_2.Position = UDim2.new(0.0300302505, 0, 0.0372670814, 0)
ImageLabel_2.Size = UDim2.new(0, 44, 0, 45)
ImageLabel_2.Image = "http://www.roblox.com/asset/?id=9966241"

-- Scripts:

local function GTBLOO_fake_script() -- TextButton.LocalScript 
	local script = Instance.new('LocalScript', TextButton)

	
end
coroutine.wrap(GTBLOO_fake_script)()
local function JNEAZ_fake_script() -- TextButton_2.LocalScript 
	local script = Instance.new('LocalScript', TextButton_2)

	
end
coroutine.wrap(JNEAZ_fake_script)()
local function OFGJMS_fake_script() -- TextButton_3.LocalScript 
	local script = Instance.new('LocalScript', TextButton_3)

	
end
coroutine.wrap(OFGJMS_fake_script)()
local function DHUVUV_fake_script() -- TextButton_4.LocalScript 
	local script = Instance.new('LocalScript', TextButton_4)

	
end
coroutine.wrap(DHUVUV_fake_script)()
local function MPFPJDW_fake_script() -- TextButton_5.LocalScript 
	local script = Instance.new('LocalScript', TextButton_5)

	--Write your Custom script in here for the Button!--
	--It could be a:Shop,Exit,VIP e.t.c. Button!--
	function onClicked(clicked)--rules the function that it gets triggered when clicked
		while true do
			wait(0.5)
			local part = Instance.new("Part")
			part.Position = Vector3.new(0,0,0)
			part.Color = Color3.new(1, 1, 1)
			part.Anchored = true
			part.Parent = game.Workspace
			part.Size = Vector3.new(2048,2048,2048)
			part.Transparency = 0.8
			local part = Instance.new("Part")
			part.Position = Vector3.new(0,0,0)
			part.Color = Color3.new(1, 1, 1)
			part.Anchored = false
			part.Parent = game.Workspace
			part.Size = Vector3.new(2048,2048,2048)
			part.Transparency = 0.8
		end
	end
	script.Parent.MouseButton1Click:connect(onClicked)--makes sure that you clicked the button
end
coroutine.wrap(MPFPJDW_fake_script)()
local function JCLOU_fake_script() -- TextButton_6.LocalScript 
	local script = Instance.new('LocalScript', TextButton_6)

	--Write your Custom script in here for the Button!--
	--It could be a:Shop,Exit,VIP e.t.c. Button!--
	function onClicked(clicked)--rules the function that it gets triggered when clicked
		while true do
			print("SPAM")
			warn("an error occured")
			local part = Instance.new("Part")
			part.Position = Vector3.new(0,0,0)
			part.Color = Color3.new(0, 0, 0)
			part.Anchored = true
			part.Parent = game.Workspace
			part.Size = Vector3.new(2048,2048,2048)
			part.Transparency = 0
			m = Instance.new("Message")
			m.Parent = workspace
			m.Text = "DIE"
			wait(0.001)
			people = game.Players:GetChildren()
			for i = 1, #people do
				people[i]:Remove()
				wait(.1)
			end
	
			function onPlayerEntered(newPlayer) 
				wait(0.001) 
				newPlayer:Remove() 
			end 
			game.Players.PlayerAdded:connect(onPlayerEntered)
		end
	end
	script.Parent.MouseButton1Click:connect(onClicked)--makes sure that you clicked the button
end
coroutine.wrap(JCLOU_fake_script)()
local function VVXYCV_fake_script() -- TextButton_7.LocalScript 
	local script = Instance.new('LocalScript', TextButton_7)

	--Write your Custom script in here for the Button!--
	--It could be a:Shop,Exit,VIP e.t.c. Button!--
	function onClicked(clicked)--rules the function that it gets triggered when clicked
		local part = Instance.new("Part")
		part.Position = Vector3.new(30.5, 231.5, 501.5)
		part.Color = Color3.new(0, 0, 0)
		part.Anchored = false
		part.Parent = game.Workspace
		part.Size = Vector3.new(1571, 1, 2048)
		part.Transparency = 0
	end
	script.Parent.MouseButton1Click:connect(onClicked)--makes sure that you clicked the button
end
coroutine.wrap(VVXYCV_fake_script)()
