local Players = game:GetService("Players")
local CoreGui = game:GetService("CoreGui")
local RunService = game:GetService("RunService")
local Lighting = game:GetService("Lighting")
local TweenService = game:GetService("TweenService")
local UserInputService = game:GetService("UserInputService")

local Player = Players.LocalPlayer

local ScreenGui = Instance.new("ScreenGui")
ScreenGui.Parent = CoreGui
ScreenGui.ZIndexBehavior = Enum.ZIndexBehavior.Sibling

local Frame = Instance.new("Frame")
Frame.Parent = ScreenGui
Frame.BackgroundColor3 = Color3.fromRGB(39, 39, 40)
Frame.BorderColor3 = Color3.fromRGB(196, 189, 0)
Frame.BorderSizePixel = 3
Frame.Position = UDim2.new(0.258870959, 0, 0.240934372, 0)
Frame.Size = UDim2.new(0, 695, 0, 450)

local TextButton = Instance.new("TextButton")
TextButton.Parent = Frame
TextButton.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton.BorderSizePixel = 2
TextButton.Position = UDim2.new(0.208403438, 0, 0.140752807, 0)
TextButton.Size = UDim2.new(0, 133, 0, 40)
TextButton.Font = Enum.Font.SourceSans
TextButton.Text = "DecalSpam"
TextButton.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton.TextSize = 29.000

local TextButton_2 = Instance.new("TextButton")
TextButton_2.Parent = Frame
TextButton_2.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_2.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_2.BorderSizePixel = 2
TextButton_2.Position = UDim2.new(0.415020257, 0, 0.140752807, 0)
TextButton_2.Size = UDim2.new(0, 117, 0, 41)
TextButton_2.Font = Enum.Font.SourceSans
TextButton_2.Text = "SkyBox"
TextButton_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_2.TextSize = 45.000

local TextButton_3 = Instance.new("TextButton")
TextButton_3.Parent = Frame
TextButton_3.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_3.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_3.BorderSizePixel = 2
TextButton_3.Position = UDim2.new(0.415020257, 0, 0.25502342, 0)
TextButton_3.Size = UDim2.new(0, 116, 0, 41)
TextButton_3.Font = Enum.Font.SourceSans
TextButton_3.Text = "666"
TextButton_3.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_3.TextSize = 41.000

local TextLabel = Instance.new("TextLabel")
TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(38, 39, 39)
TextLabel.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel.BorderSizePixel = 0
TextLabel.Position = UDim2.new(0.301356107, 0, 0.0295644905, 0)
TextLabel.Size = UDim2.new(0, 250, 0, 27)
TextLabel.Font = Enum.Font.SourceSans
TextLabel.Text = "c00lgui v12"
TextLabel.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.TextSize = 41.000

local TextLabel_2 = Instance.new("TextLabel")
TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(37, 38, 38)
TextLabel_2.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0.172259822, 0, 0.969139874, 0)
TextLabel_2.Size = UDim2.new(0, 466, 0, 5)
TextLabel_2.Font = Enum.Font.SourceSans
TextLabel_2.Text = "by team skrubl0rdz"
TextLabel_2.TextColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_2.TextSize = 25.000

local TextButton_4 = Instance.new("TextButton")
TextButton_4.Parent = Frame
TextButton_4.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_4.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_4.BorderSizePixel = 2
TextButton_4.Position = UDim2.new(0.415020257, 0, 0.376003832, 0)
TextButton_4.Size = UDim2.new(0, 116, 0, 41)
TextButton_4.Font = Enum.Font.SourceSans
TextButton_4.Text = "raining toads"
TextButton_4.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_4.TextSize = 25.000

local TextButton_5 = Instance.new("TextButton")
TextButton_5.Parent = Frame
TextButton_5.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_5.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_5.BorderSizePixel = 2
TextButton_5.Position = UDim2.new(0.83029449, 0, 0.421231121, 0)
TextButton_5.Size = UDim2.new(0, 102, 0, 30)
TextButton_5.Font = Enum.Font.SourceSans
TextButton_5.Text = "Hint 1"
TextButton_5.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_5.TextSize = 29.000

local TextButton_6 = Instance.new("TextButton")
TextButton_6.Parent = Frame
TextButton_6.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_6.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_6.BorderSizePixel = 2
TextButton_6.Position = UDim2.new(-0.000986310537, 0, 0.635829091, 0)
TextButton_6.Size = UDim2.new(0, 140, 0, 29)
TextButton_6.Font = Enum.Font.SourceSans
TextButton_6.Text = "Kick All"
TextButton_6.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_6.TextSize = 29.000

local TextButton_7 = Instance.new("TextButton")
TextButton_7.Parent = Frame
TextButton_7.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_7.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_7.BorderSizePixel = 2
TextButton_7.Position = UDim2.new(0.0095850667, 0, 0.140752807, 0)
TextButton_7.Size = UDim2.new(0, 132, 0, 27)
TextButton_7.Font = Enum.Font.SourceSans
TextButton_7.Text = "Spooky Music"
TextButton_7.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_7.TextSize = 20.000

local TextButton_8 = Instance.new("TextButton")
TextButton_8.Parent = Frame
TextButton_8.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_8.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_8.BorderSizePixel = 2
TextButton_8.Position = UDim2.new(0.83029449, 0, 0.303391427, 0)
TextButton_8.Size = UDim2.new(0, 102, 0, 41)
TextButton_8.Font = Enum.Font.SourceSans
TextButton_8.Text = "Disco Fog"
TextButton_8.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_8.TextSize = 25.000

local TextButton_9 = Instance.new("TextButton")
TextButton_9.Parent = Frame
TextButton_9.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_9.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_9.BorderSizePixel = 2
TextButton_9.Position = UDim2.new(0.208403438, 0, 0.377206236, 0)
TextButton_9.Size = UDim2.new(0, 133, 0, 41)
TextButton_9.Font = Enum.Font.SourceSans
TextButton_9.Text = "Unanchor All"
TextButton_9.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_9.TextSize = 25.000

local TextButton_10 = Instance.new("TextButton")
TextButton_10.Parent = Frame
TextButton_10.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_10.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_10.BorderSizePixel = 2
TextButton_10.Position = UDim2.new(0.593212187, 0, 0.254994154, 0)
TextButton_10.Size = UDim2.new(0, 152, 0, 41)
TextButton_10.Font = Enum.Font.SourceSans
TextButton_10.Text = "Jumpscare"
TextButton_10.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_10.TextSize = 29.000

local TextButton_11 = Instance.new("TextButton")
TextButton_11.Parent = Frame
TextButton_11.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_11.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_11.BorderSizePixel = 2
TextButton_11.Position = UDim2.new(0.593212187, 0, 0.140752807, 0)
TextButton_11.Size = UDim2.new(0, 152, 0, 41)
TextButton_11.Font = Enum.Font.SourceSans
TextButton_11.Text = "Particles"
TextButton_11.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_11.TextSize = 29.000

local TextButton_12 = Instance.new("TextButton")
TextButton_12.Parent = Frame
TextButton_12.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_12.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_12.BorderSizePixel = 2
TextButton_12.Position = UDim2.new(0.172259822, 0, 0.732464671, 0)
TextButton_12.Size = UDim2.new(0, 444, 0, 25)
TextButton_12.Font = Enum.Font.SourceSans
TextButton_12.Text = "Kill All"
TextButton_12.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_12.TextSize = 29.000

local TextButton_13 = Instance.new("TextButton")
TextButton_13.Parent = Frame
TextButton_13.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_13.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_13.BorderSizePixel = 2
TextButton_13.Position = UDim2.new(0.00526851974, 0, 0.515268803, 0)
TextButton_13.Size = UDim2.new(0, 135, 0, 40)
TextButton_13.Font = Enum.Font.SourceSans
TextButton_13.Text = "Anti Robloxian"
TextButton_13.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_13.TextSize = 20.000

local TextButton_14 = Instance.new("TextButton")
TextButton_14.Parent = Frame
TextButton_14.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_14.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_14.BorderSizePixel = 2
TextButton_14.Position = UDim2.new(0.593212187, 0, 0.376864582, 0)
TextButton_14.Size = UDim2.new(0, 152, 0, 40)
TextButton_14.Font = Enum.Font.SourceSans
TextButton_14.Text = "SpookySky"
TextButton_14.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_14.TextSize = 25.000

local TextButton_15 = Instance.new("TextButton")
TextButton_15.Parent = Frame
TextButton_15.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_15.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_15.BorderSizePixel = 2
TextButton_15.Position = UDim2.new(0.208403438, 0, 0.255116224, 0)
TextButton_15.Size = UDim2.new(0, 133, 0, 41)
TextButton_15.Font = Enum.Font.SourceSans
TextButton_15.Text = "Fire Parts"
TextButton_15.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_15.TextSize = 25.000

local TextButton_16 = Instance.new("TextButton")
TextButton_16.Parent = Frame
TextButton_16.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_16.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_16.BorderSizePixel = 2
TextButton_16.Position = UDim2.new(0.562476993, 0, 0.500656366, 0)
TextButton_16.Size = UDim2.new(0, 174, 0, 40)
TextButton_16.Font = Enum.Font.SourceSans
TextButton_16.Text = "C00lify"
TextButton_16.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_16.TextSize = 29.000

local TextButton_17 = Instance.new("TextButton")
TextButton_17.Parent = Frame
TextButton_17.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_17.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_17.BorderSizePixel = 2
TextButton_17.Position = UDim2.new(0.210524529, 0, 0.500656366, 0)
TextButton_17.Size = UDim2.new(0, 111, 0, 40)
TextButton_17.Font = Enum.Font.SourceSans
TextButton_17.Text = "Flood"
TextButton_17.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_17.TextSize = 25.000

local TextButton_18 = Instance.new("TextButton")
TextButton_18.Parent = Frame
TextButton_18.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_18.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_18.BorderSizePixel = 2
TextButton_18.Position = UDim2.new(0.0101506291, 0, 0.22743611, 0)
TextButton_18.Size = UDim2.new(0, 132, 0, 31)
TextButton_18.Font = Enum.Font.SourceSans
TextButton_18.Text = "Speed Hack"
TextButton_18.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_18.TextSize = 21.000

local TextButton_19 = Instance.new("TextButton")
TextButton_19.Parent = Frame
TextButton_19.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_19.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_19.BorderSizePixel = 2
TextButton_19.Position = UDim2.new(0.83029449, 0, 0.0292278975, 0)
TextButton_19.Size = UDim2.new(0, 104, 0, 55)
TextButton_19.Font = Enum.Font.SourceSans
TextButton_19.Text = "Restore Sky"
TextButton_19.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_19.TextSize = 17.000

local TextButton_20 = Instance.new("TextButton")
TextButton_20.Parent = Frame
TextButton_20.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_20.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_20.BorderSizePixel = 2
TextButton_20.Position = UDim2.new(0.83029449, 0, 0.182919562, 0)
TextButton_20.Size = UDim2.new(0, 103, 0, 40)
TextButton_20.Font = Enum.Font.SourceSans
TextButton_20.Text = "Hint 2"
TextButton_20.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_20.TextSize = 21.000

local TextButton_21 = Instance.new("TextButton")
TextButton_21.Parent = Frame
TextButton_21.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_21.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_21.BorderSizePixel = 2
TextButton_21.Position = UDim2.new(0.172259822, 0, 0.807163477, 0)
TextButton_21.Size = UDim2.new(0, 444, 0, 25)
TextButton_21.Font = Enum.Font.SourceSans
TextButton_21.Text = "Hint 3"
TextButton_21.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_21.TextSize = 29.000

local TextButton_22 = Instance.new("TextButton")
TextButton_22.Parent = Frame
TextButton_22.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_22.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_22.BorderSizePixel = 2
TextButton_22.Position = UDim2.new(0.83029449, 0, 0.510387719, 0)
TextButton_22.Size = UDim2.new(0, 102, 0, 33)
TextButton_22.Font = Enum.Font.SourceSans
TextButton_22.Text = "Hint 4"
TextButton_22.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_22.TextSize = 29.000

local TextButton_23 = Instance.new("TextButton")
TextButton_23.Parent = Frame
TextButton_23.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_23.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_23.BorderSizePixel = 2
TextButton_23.Position = UDim2.new(0.00620793412, 0, 0.0292278975, 0)
TextButton_23.Size = UDim2.new(0, 115, 0, 32)
TextButton_23.Font = Enum.Font.SourceSans
TextButton_23.Text = "Stop Music"
TextButton_23.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_23.TextSize = 20.000

local TextButton_24 = Instance.new("TextButton")
TextButton_24.Parent = Frame
TextButton_24.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_24.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_24.BorderSizePixel = 2
TextButton_24.Position = UDim2.new(0.0101506291, 0, 0.326231301, 0)
TextButton_24.Size = UDim2.new(0, 132, 0, 31)
TextButton_24.Font = Enum.Font.SourceSans
TextButton_24.Text = "Jump Hack"
TextButton_24.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_24.TextSize = 21.000

local TextButton_25 = Instance.new("TextButton")
TextButton_25.Parent = Frame
TextButton_25.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_25.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_25.BorderSizePixel = 2
TextButton_25.Position = UDim2.new(0.0101506291, 0, 0.417797565, 0)
TextButton_25.Size = UDim2.new(0, 132, 0, 31)
TextButton_25.Font = Enum.Font.SourceSans
TextButton_25.Text = "Noclip"
TextButton_25.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_25.TextSize = 21.000

local TextButton_26 = Instance.new("TextButton")
TextButton_26.Parent = Frame
TextButton_26.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_26.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_26.BorderSizePixel = 2
TextButton_26.Position = UDim2.new(0.383365601, 0, 0.500656366, 0)
TextButton_26.Size = UDim2.new(0, 117, 0, 40)
TextButton_26.Font = Enum.Font.SourceSans
TextButton_26.Text = "Fly"
TextButton_26.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_26.TextSize = 25.000

local TextButton_27 = Instance.new("TextButton")
TextButton_27.Parent = Frame
TextButton_27.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_27.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_27.BorderSizePixel = 2
TextButton_27.Position = UDim2.new(0.788002312, 0, 0.611654341, 0)
TextButton_27.Size = UDim2.new(0, 131, 0, 40)
TextButton_27.Font = Enum.Font.SourceSans
TextButton_27.Text = "Apoc Troll"
TextButton_27.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_27.TextSize = 25.000

local TextButton_28 = Instance.new("TextButton")
TextButton_28.Parent = Frame
TextButton_28.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_28.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_28.BorderSizePixel = 2
TextButton_28.Position = UDim2.new(0.592318892, 0, 0.611654341, 0)
TextButton_28.Size = UDim2.new(0, 131, 0, 40)
TextButton_28.Font = Enum.Font.SourceSans
TextButton_28.Text = "Laser Gun"
TextButton_28.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_28.TextSize = 25.000

local TextButton_29 = Instance.new("TextButton")
TextButton_29.Parent = Frame
TextButton_29.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_29.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_29.BorderSizePixel = 2
TextButton_29.Position = UDim2.new(0.392318875, 0, 0.611654341, 0)
TextButton_29.Size = UDim2.new(0, 131, 0, 40)
TextButton_29.Font = Enum.Font.SourceSans
TextButton_29.Text = "Rocket"
TextButton_29.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_29.TextSize = 25.000

local TextButton_30 = Instance.new("TextButton")
TextButton_30.Parent = Frame
TextButton_30.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_30.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_30.BorderSizePixel = 2
TextButton_30.Position = UDim2.new(0.219657004, 0, 0.611654341, 0)
TextButton_30.Size = UDim2.new(0, 113, 0, 40)
TextButton_30.Font = Enum.Font.SourceSans
TextButton_30.Text = "Hint 5"
TextButton_30.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_30.TextSize = 21.000

local TextButton_31 = Instance.new("TextButton")
TextButton_31.Parent = Frame
TextButton_31.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_31.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_31.BorderSizePixel = 2
TextButton_31.Position = UDim2.new(0.83, 0, 0.65, 0)
TextButton_31.Size = UDim2.new(0, 100, 0, 30)
TextButton_31.Font = Enum.Font.SourceSans
TextButton_31.Text = "Play Music 1"
TextButton_31.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_31.TextSize = 14.000

local TextButton_32 = Instance.new("TextButton")
TextButton_32.Parent = Frame
TextButton_32.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_32.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_32.BorderSizePixel = 2
TextButton_32.Position = UDim2.new(0.83, 0, 0.72, 0)
TextButton_32.Size = UDim2.new(0, 100, 0, 30)
TextButton_32.Font = Enum.Font.SourceSans
TextButton_32.Text = "Play Music 2"
TextButton_32.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_32.TextSize = 14.000

local TextButton_33 = Instance.new("TextButton")
TextButton_33.Parent = Frame
TextButton_33.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_33.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_33.BorderSizePixel = 2
TextButton_33.Position = UDim2.new(0.83, 0, 0.79, 0)
TextButton_33.Size = UDim2.new(0, 100, 0, 30)
TextButton_33.Font = Enum.Font.SourceSans
TextButton_33.Text = "HackChat"
TextButton_33.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_33.TextSize = 14.000

local TextButton_34 = Instance.new("TextButton")
TextButton_34.Parent = Frame
TextButton_34.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_34.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_34.BorderSizePixel = 2
TextButton_34.Position = UDim2.new(0.02, 0, 0.9, 0)
TextButton_34.Size = UDim2.new(0, 100, 0, 30)
TextButton_34.Font = Enum.Font.SourceSans
TextButton_34.Text = "Clear All"
TextButton_34.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_34.TextSize = 20.000

local TextButton_35 = Instance.new("TextButton")
TextButton_35.Parent = Frame
TextButton_35.BackgroundColor3 = Color3.fromRGB(47, 47, 48)
TextButton_35.BorderColor3 = Color3.fromRGB(195, 191, 0)
TextButton_35.BorderSizePixel = 2
TextButton_35.Position = UDim2.new(0.17, 0, 0.9, 0)
TextButton_35.Size = UDim2.new(0, 120, 0, 30)
TextButton_35.Font = Enum.Font.SourceSans
TextButton_35.Text = "Set Baseplate"
TextButton_35.TextColor3 = Color3.fromRGB(255, 255, 255)
TextButton_35.TextSize = 18.000

local dragToggle, dragSpeed, dragInput, dragStart, dragPos

local function updateInput(input)
	local Delta = input.Position - dragStart
	local Position = UDim2.new(startPos.X.Scale, startPos.X.Offset + Delta.X, startPos.Y.Scale, startPos.Y.Offset + Delta.Y)
	TweenService:Create(Frame, TweenInfo.new(.25), {Position = Position}):Play()
end

Frame.InputBegan:Connect(function(input)
	if (input.UserInputType == Enum.UserInputType.MouseButton1 or input.UserInputType == Enum.UserInputType.Touch) then
		dragToggle = true
		dragStart = input.Position
		startPos = Frame.Position
		input.Changed:Connect(function()
			if (input.UserInputState == Enum.UserInputState.End) then
				dragToggle = false
			end
		end)
	end
end)

Frame.InputChanged:Connect(function(input)
	if (input.UserInputType == Enum.UserInputType.MouseMovement or input.UserInputType == Enum.UserInputType.Touch) then
		dragInput = input
	end
end)

UserInputService.InputChanged:Connect(function(input)
	if (input == dragInput and dragToggle) then
		updateInput(input)
	end
end)

local constantHint = nil

TextButton.MouseButton1Down:Connect(function()
	local ID = 358313209
	local function spamDecal(v)
		if v:IsA("Part") then 
			for i = 0, 5 do
				local D = Instance.new("Decal") 
				D.Name = "C00lDecal"
				D.Face = i 
				D.Parent = v
				D.Texture = "http://www.roblox.com/asset/?id=" .. ID
			end 
		elseif v:IsA("Model") then
			for a,b in pairs(v:GetChildren()) do 
				spamDecal(b) 
			end 
		end
	end
	
	for i,v in pairs(workspace:GetChildren()) do
		if v:IsA("Part") then 
			for i = 0, 5 do
				local D = Instance.new("Decal")
				D.Name = "C00lDecal"
				D.Face = i 
				D.Parent = v
				D.Texture = "http://www.roblox.com/asset/?id=" .. ID
			end 
		elseif v:IsA("Model") then
			for a,b in pairs(v:GetChildren()) do 
				spamDecal(b) 
			end 
		end 
	end
end)

TextButton_2.MouseButton1Down:Connect(function()
	for _, obj in pairs(Lighting:GetChildren()) do 
		if obj:IsA("Sky") then 
			obj:Destroy() 
		end 
	end
	
	local newSky = Instance.new("Sky")
	newSky.Parent = Lighting
	newSky.SkyboxBk = "http://www.roblox.com/asset/?id=358313209"
	newSky.SkyboxDn = "http://www.roblox.com/asset/?id=358313209"
	newSky.SkyboxFt = "http://www.roblox.com/asset/?id=358313209"
	newSky.SkyboxLf = "http://www.roblox.com/asset/?id=358313209"
	newSky.SkyboxRt = "http://www.roblox.com/asset/?id=358313209"
	newSky.SkyboxUp = "http://www.roblox.com/asset/?id=358313209"
end)

TextButton_3.MouseButton1Click:Connect(function()
	for i,v in pairs(workspace:GetChildren()) do
		if v:IsA("BasePart") then
			local bbg = Instance.new("BillboardGui", v)
			bbg.Name = "stuf"
			bbg.Adornee = v
			bbg.Size = UDim2.new(2.5, 0, 2.5, 0)
			local tlb = Instance.new("TextLabel")
			tlb.Text = "666 666 666 666 666 666"
			tlb.Font = "SourceSansBold"
			tlb.FontSize = "Size48"
			tlb.TextColor3 = Color3.new(1, 0, 0)
			tlb.Size = UDim2.new(1.25, 0, 1.25, 0)
			tlb.Position = UDim2.new(-0.125, -22, -1.1, 0)
			tlb.BackgroundTransparency = 1
			tlb.Parent = bbg
		end
	end
	
	for i,v in pairs(workspace:GetChildren()) do
		if v:IsA("BasePart") then
			v.BrickColor = BrickColor.new("Really black")
			v.TopSurface = "Smooth"
			v.BottomSurface = "Smooth"
			local s = Instance.new("SelectionBox", v)
			s.Adornee = v
			s.Color = BrickColor.new("Really red")
			local a = Instance.new("PointLight", v)
			a.Color = Color3.new(1, 0, 0)
			a.Range = 15
			a.Brightness = 5
			local f = Instance.new("Fire", v)
			f.Size = 19
			f.Heat = 22
		end
	end
end)

TextButton_4.MouseButton1Click:Connect(function()
	if RunService:IsClient() then 
		error("Script must be server-side in order to work; use h/ and not hl/") 
	end
	
	wait(1)
	math.randomseed(tick() % 1 * 1e6)
	
	local sky = coroutine.create(function()
		while wait(0.3) do
			local s = Instance.new("Sky", Lighting)
			s.SkyboxBk = "rbxassetid://201208408"
			s.SkyboxDn = "rbxassetid://201208408"
			s.SkyboxFt = "rbxassetid://201208408"
			s.SkyboxLf = "rbxassetid://201208408"
			s.SkyboxRt = "rbxassetid://201208408"
			s.SkyboxUp = "rbxassetid://201208408"
			s.CelestialBodiesShown = false
		end
	end)
	
	local del = coroutine.create(function()
		while wait(0.3) do
			for i,v in pairs(workspace:GetChildren()) do
				if v:IsA("Model") then
					v:Destroy()
				end
			end
		end
	end)
	
	local noises = {'rbxassetid://230287740', 'rbxassetid://271787597', 'rbxassetid://153752123', 'rbxassetid://271787503'}
	
	local sound = coroutine.create(function()
		local a = Instance.new("Sound", workspace)
		a.SoundId = "rbxassetid://902601313"
		a.Name = "RAINING MEN"
		a.Volume = 58359
		a.Looped = true
		a:Play()
		while wait(0.2) do
			local rainin = workspace:FindFirstChild("RAINING MEN")
			if not rainin then
				a = Instance.new("Sound", workspace)
				a.SoundId = "rbxassetid://902601313"
				a.Name = "RAINING MEN"
				a.Volume = 58359
				a.Looped = true
				a:Play()
			end
		end
	end)
	
	local msg = coroutine.create(function()
		while wait(0.4) do
			local msg = Instance.new("Message", workspace)
			msg.Text = "Get toadroasted you bacon-haired bozos."
			wait(0.4)
			msg:Destroy()
		end
	end)
	
	local rain = coroutine.create(function()
		while wait(10 % 1 * 1e2) do
			local part = Instance.new("Part", workspace)
			part.Name = "Toad"
			
			local mesh = Instance.new("SpecialMesh", part)
			
			local sound = Instance.new("Sound", workspace)
			
			part.CanCollide = false
			part.Size = Vector3.new(440, 530, 380)
			part.Position = Vector3.new(math.random(-3000, 1000), math.random(1, 3000), math.random(-3000, 3000))
		
			sound.SoundId = noises[math.random(1, #noises)]
			sound:Play()
			sound.Ended:Connect(function()
				sound:Destroy()
			end)
			
			mesh.MeshType = "FileMesh"
			mesh.MeshId = "rbxassetid://430210147"
			mesh.TextureId = "rbxassetid://430210159"
		end
	end)
	
	coroutine.resume(sky)
	coroutine.resume(del)
	coroutine.resume(sound)
	coroutine.resume(msg)
	coroutine.resume(rain)
end)

TextButton_5.MouseButton1Click:Connect(function()
	if not constantHint then
		constantHint = Instance.new("Hint", workspace)
	end
	constantHint.Text = "Game destroyed by team c00lkidd 2 1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1"
end)

TextButton_6.MouseButton1Down:Connect(function()
	Player:Kick("you kicked by experience or its moderators message: join team c00lkidd 2 today!")
end)

TextButton_7.MouseButton1Down:Connect(function()
	local sound = Instance.new("Sound", workspace)
	sound.SoundId = "rbxassetid://168983825"
	sound.Volume = 10
	sound.Looped = false
	sound:Play()
	game:GetService("Debris"):AddItem(sound, 10)
end)

TextButton_8.MouseButton1Click:Connect(function()
	Lighting.FogEnd = 1000
	local discoConnection = RunService.Heartbeat:Connect(function() 
		Lighting.FogColor = Color3.fromHSV(tick() % 5 / 5, 1, 1) 
	end)
	delay(30, function() 
		if discoConnection then 
			discoConnection:Disconnect() 
		end 
	end)
end)

TextButton_9.MouseButton1Down:Connect(function()
	for _, obj in pairs(workspace:GetDescendants()) do 
		if obj:IsA("BasePart") then 
			obj.Anchored = false 
		end 
	end
	workspace.Gravity = 10
end)

TextButton_10.MouseButton1Click:Connect(function()
	local imageId = "rbxassetid://358313209"
	local soundId = "rbxassetid://13530438299"
	
	local function showFullScreenImageAndSound(targetPlayer)
		if targetPlayer and targetPlayer:FindFirstChild("PlayerGui") then
			local screenGui = Instance.new("ScreenGui")
			screenGui.Name = "FullScreenImageGui"
			screenGui.ResetOnSpawn = false
			screenGui.Parent = targetPlayer.PlayerGui
			
			local imageLabel = Instance.new("ImageLabel")
			imageLabel.Size = UDim2.new(1, 0, 1, 0)
			imageLabel.Position = UDim2.new(0, 0, 0, 0)
			imageLabel.Image = imageId
			imageLabel.BackgroundTransparency = 1
			imageLabel.Parent = screenGui
			
			local sound = Instance.new("Sound")
			sound.SoundId = soundId
			sound.Volume = 2
			sound.Looped = false
			sound.Parent = targetPlayer.PlayerGui
			sound:Play()
			
			wait(5)
			screenGui:Destroy()
			sound:Destroy()
		end
	end
	
	for _, player in pairs(Players:GetPlayers()) do
		showFullScreenImageAndSound(player)
	end
end)

TextButton_11.MouseButton1Click:Connect(function()
	local particleID = 358313209
	for _, player in pairs(Players:GetPlayers()) do
		if player.Character then
			local humanoidRootPart = player.Character:FindFirstChild("HumanoidRootPart")
			if humanoidRootPart then
				local particleEmitter = Instance.new("ParticleEmitter")
				particleEmitter.Parent = humanoidRootPart
				particleEmitter.Texture = "http://www.roblox.com/asset/?id=" .. particleID
				particleEmitter.Lifetime = NumberRange.new(2, 4)
				particleEmitter.Rate = 50
				particleEmitter.SpreadAngle = Vector2.new(45, 45)
				particleEmitter.Speed = NumberRange.new(5, 15)
			end
		end
	end
end)

TextButton_12.MouseButton1Down:Connect(function()
	for _, player in pairs(Players:GetPlayers()) do
		if player.Character then
			local humanoid = player.Character:FindFirstChildOfClass("Humanoid")
			if humanoid then
				humanoid.Health = 0
			end
		end
	end
end)

TextButton_13.MouseButton1Click:Connect(function()
	for _, player in pairs(Players:GetPlayers()) do 
		if player ~= Player and player.Character then 
			player.Character:Destroy() 
		end 
	end
	
	local highlightPart = Instance.new("Part") 
	highlightPart.Name = "CenterHighlight" 
	highlightPart.Parent = workspace
	highlightPart.Position = Vector3.new(0, 0, 0) 
	highlightPart.Size = Vector3.new(10, 10, 10) 
	highlightPart.Material = Enum.Material.Neon
	highlightPart.BrickColor = BrickColor.new("Bright red") 
	highlightPart.Anchored = true 
	highlightPart.CanCollide = false
	
	local pointLight = Instance.new("PointLight") 
	pointLight.Parent = highlightPart 
	pointLight.Brightness = 5 
	pointLight.Range = 50 
	pointLight.Color = Color3.new(1, 0, 0)
end)

TextButton_14.MouseButton1Down:Connect(function()
	local imageOne = "http://www.roblox.com/asset/?id=169585459"
	local imageTwo = "http://www.roblox.com/asset/?id=169585475"
	local imageThree = "http://www.roblox.com/asset/?id=169585485"
	local imageFour = "http://www.roblox.com/asset/?id=169585502"
	local imageFive = "http://www.roblox.com/asset/?id=169585515"
	local imageSix = "http://www.roblox.com/asset/?id=169585502"
	local imageSeven = "http://www.roblox.com/asset/?id=169585485"
	local imageEight = "http://www.roblox.com/asset/?id=169585475"
	
	for _, obj in pairs(Lighting:GetChildren()) do 
		if obj:IsA("Sky") then 
			obj:Destroy() 
		end 
	end
	
	local Spooky = Instance.new("Sound", workspace)
	Spooky.Name = "Spooky" 
	Spooky.SoundId = "rbxassetid://174270407"
	Spooky.Volume = 15 
	Spooky.Looped = true 
	Spooky:Play()
	
	local Sky = Instance.new("Sky", Lighting)
	Sky.SkyboxBk = imageOne 
	Sky.SkyboxDn = imageOne 
	Sky.SkyboxFt = imageOne
	Sky.SkyboxLf = imageOne 
	Sky.SkyboxRt = imageOne 
	Sky.SkyboxUp = imageOne
	
	coroutine.wrap(function()
		while true do
			Sky.SkyboxBk = imageOne Sky.SkyboxDn = imageOne Sky.SkyboxFt = imageOne Sky.SkyboxLf = imageOne Sky.SkyboxRt = imageOne Sky.SkyboxUp = imageOne wait(0.15)
			Sky.SkyboxBk = imageTwo Sky.SkyboxDn = imageTwo Sky.SkyboxFt = imageTwo Sky.SkyboxLf = imageTwo Sky.SkyboxRt = imageTwo Sky.SkyboxUp = imageTwo wait(0.15)
			Sky.SkyboxBk = imageThree Sky.SkyboxDn = imageThree Sky.SkyboxFt = imageThree Sky.SkyboxLf = imageThree Sky.SkyboxRt = imageThree Sky.SkyboxUp = imageThree wait(0.15)
			Sky.SkyboxBk = imageFour Sky.SkyboxDn = imageFour Sky.SkyboxFt = imageFour Sky.SkyboxLf = imageFour Sky.SkyboxRt = imageFour Sky.SkyboxUp = imageFour wait(0.15)
			Sky.SkyboxBk = imageFive Sky.SkyboxDn = imageFive Sky.SkyboxFt = imageFive Sky.SkyboxLf = imageFive Sky.SkyboxRt = imageFive Sky.SkyboxUp = imageFive wait(0.15)
			Sky.SkyboxBk = imageSix Sky.SkyboxDn = imageSix Sky.SkyboxFt = imageSix Sky.SkyboxLf = imageSix Sky.SkyboxRt = imageSix Sky.SkyboxUp = imageSix wait(0.15)
			Sky.SkyboxBk = imageSeven Sky.SkyboxDn = imageSeven Sky.SkyboxFt = imageSeven Sky.SkyboxLf = imageSeven Sky.SkyboxRt = imageSeven Sky.SkyboxUp = imageSeven wait(0.15)
			Sky.SkyboxBk = imageEight Sky.SkyboxDn = imageEight Sky.SkyboxFt = imageEight Sky.SkyboxLf = imageEight Sky.SkyboxRt = imageEight Sky.SkyboxUp = imageEight wait(0.15)
		end
	end)()
end)

TextButton_15.MouseButton1Down:Connect(function()
	for _, part in pairs(workspace:GetDescendants()) do
		if part:IsA("Part") and math.random(1, 5) == 1 then
			local fire = Instance.new("Fire")
			fire.Parent = part
			fire.Size = math.random(5, 15)
			fire.Heat = math.random(5, 15)
		end
	end
end)

TextButton_16.MouseButton1Down:Connect(function()
	local msg = Instance.new("Message", workspace)
	msg.Text = "join team c00lkidd 2"
	wait(7.2) 
	msg:Destroy()
	
	local s = Instance.new("Sky") 
	s.Name = "SKY"
	s.SkyboxBk = "http://www.roblox.com/asset/?id=358313209"
	s.SkyboxDn = "http://www.roblox.com/asset/?id=358313209"
	s.SkyboxFt = "http://www.roblox.com/asset/?id=358313209"
	s.SkyboxLf = "http://www.roblox.com/asset/?id=358313209"
	s.SkyboxRt = "http://www.roblox.com/asset/?id=358313209"
	s.SkyboxUp = "http://www.roblox.com/asset/?id=358313209"
	s.Parent = Lighting
	
	local Spooky = Instance.new("Sound", workspace)
	Spooky.Name = "Spooky" 
	Spooky.SoundId = "rbxassetid://13530438299"
	Spooky.Volume = 100000000000 
	Spooky.Looped = true 
	Spooky:Play()
	
	local ID = 358313209
	
	local function spamDecal(v)
		if v:IsA("Part") then 
			for i = 0, 5 do
				local D = Instance.new("Decal") 
				D.Name = "MYDECALHUE"
				D.Face = i 
				D.Parent = v
				D.Texture = "http://www.roblox.com/asset/?id=" .. ID
			end 
		elseif v:IsA("Model") then
			for a,b in pairs(v:GetChildren()) do 
				spamDecal(b) 
			end 
		end
	end
	
	local function decalspam(id)
		for i,v in pairs(workspace:GetChildren()) do
			if v:IsA("Part") then 
				for i = 0, 5 do
					local D = Instance.new("Decal") 
					D.Name = "MYDECALHUE"
					D.Face = i 
					D.Parent = v
					D.Texture = "http://www.roblox.com/asset/?id=" .. id
				end 
			elseif v:IsA("Model") then
				for a,b in pairs(v:GetChildren()) do 
					spamDecal(b) 
				end 
			end 
		end
	end
	decalspam(ID)
end)

TextButton_17.MouseButton1Down:Connect(function()
	local water = Instance.new("Part") 
	water.Name = "FloodWater" 
	water.Parent = workspace
	water.Size = Vector3.new(500, 50, 500) 
	water.Position = Vector3.new(0, 25, 0) 
	water.BrickColor = BrickColor.new("Bright blue")
	water.Material = Enum.Material.Water 
	water.Transparency = 0.3 
	water.Anchored = true 
	water.CanCollide = true
end)

TextButton_18.MouseButton1Down:Connect(function()
	local humanoid = Player.Character and Player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then 
		humanoid.WalkSpeed = 50 
	end
end)

TextButton_19.MouseButton1Click:Connect(function()
	for _, obj in pairs(Lighting:GetChildren()) do 
		if obj:IsA("Sky") then 
			obj:Destroy() 
		end 
	end
end)

TextButton_20.MouseButton1Click:Connect(function()
	if not constantHint then
		constantHint = Instance.new("Hint", workspace)
	end
	constantHint.Text = "Join team c00lKidd 2 TODAY!"
end)

TextButton_21.MouseButton1Click:Connect(function()
	if not constantHint then
		constantHint = Instance.new("Hint", workspace)
	end
	constantHint.Text = "game hacked by team c00lkidd 2"
end)

TextButton_22.MouseButton1Click:Connect(function()
	if not constantHint then
		constantHint = Instance.new("Hint", workspace)
	end
	constantHint.Text = "game got rekt by team c00lkidd 2"
end)

TextButton_23.MouseButton1Down:Connect(function()
	for i,v in pairs(workspace:GetDescendants()) do
		if v:IsA("Sound") then
			v:Destroy()
		end
	end
end)

TextButton_24.MouseButton1Down:Connect(function()
	local humanoid = Player.Character and Player.Character:FindFirstChildOfClass("Humanoid")
	if humanoid then 
		humanoid.JumpPower = 100 
	end
end)

TextButton_25.MouseButton1Down:Connect(function()
	if Player.Character then 
		for _, v in pairs(Player.Character:GetDescendants()) do 
			if v:IsA("BasePart") then 
				v.CanCollide = false 
			end 
		end 
	end
end)

TextButton_26.MouseButton1Down:Connect(function()
	if not Player.Character or not Player.Character:FindFirstChild("HumanoidRootPart") then 
		return 
	end
	
	local bodyVelocity = Instance.new("BodyVelocity") 
	bodyVelocity.Parent = Player.Character.HumanoidRootPart
	bodyVelocity.MaxForce = Vector3.new(40000, 40000, 40000) 
	
	local flying = true
	local flyConnection = RunService.Heartbeat:Connect(function()
		if flying and Player.Character and Player.Character.HumanoidRootPart then
			bodyVelocity.Velocity = Vector3.new(0, 0, 0)
			
			if UserInputService:IsKeyDown(Enum.KeyCode.W) then 
				bodyVelocity.Velocity = bodyVelocity.Velocity + Player.Character.HumanoidRootPart.CFrame.LookVector * 50 
			end
			if UserInputService:IsKeyDown(Enum.KeyCode.S) then 
				bodyVelocity.Velocity = bodyVelocity.Velocity - Player.Character.HumanoidRootPart.CFrame.LookVector * 50 
			end
			if UserInputService:IsKeyDown(Enum.KeyCode.A) then 
				bodyVelocity.Velocity = bodyVelocity.Velocity - Player.Character.HumanoidRootPart.CFrame.RightVector * 50 
			end
			if UserInputService:IsKeyDown(Enum.KeyCode.D) then 
				bodyVelocity.Velocity = bodyVelocity.Velocity + Player.Character.HumanoidRootPart.CFrame.RightVector * 50 
			end
			if UserInputService:IsKeyDown(Enum.KeyCode.Space) then 
				bodyVelocity.Velocity = bodyVelocity.Velocity + Vector3.new(0, 50, 0) 
			end
		end
	end)
	
	delay(30, function() 
		flying = false 
		if bodyVelocity then 
			bodyVelocity:Destroy() 
		end 
		if flyConnection then 
			flyConnection:Disconnect() 
		end 
	end)
end)

TextButton_27.MouseButton1Down:Connect(function()
	for _, player in pairs(Players:GetPlayers()) do 
		if player.Character then
			local humanoid = player.Character:FindFirstChildOfClass("Humanoid") 
			local rootPart = player.Character:FindFirstChild("HumanoidRootPart")
			if humanoid then 
				humanoid.PlatformStand = true 
			end 
			if rootPart then 
				rootPart.Anchored = true 
			end
		end 
	end
end)

TextButton_28.MouseButton1Click:Connect(function()
	local tool = Instance.new("Tool")
	tool.Name = "LaserGun"
	tool.RequiresHandle = false
	tool.Parent = Player.Backpack
	
	tool.Activated:Connect(function()
		local ray = Ray.new(tool.Parent.Head.Position, tool.Parent.Head.CFrame.LookVector * 100)
		local part, position = workspace:FindPartOnRay(ray, tool.Parent)
		
		if part then
			local explosion = Instance.new("Explosion")
			explosion.Position = position
			explosion.BlastPressure = 0
			explosion.BlastRadius = 5
			explosion.Parent = workspace
		end
		
		local beam = Instance.new("Part")
		beam.Size = Vector3.new(0.2, 0.2, (tool.Parent.Head.Position - position).Magnitude)
		beam.CFrame = CFrame.new(tool.Parent.Head.Position, position) * CFrame.new(0, 0, -beam.Size.Z/2)
		beam.Material = Enum.Material.Neon
		beam.BrickColor = BrickColor.new("Bright red")
		beam.Anchored = true
		beam.CanCollide = false
		beam.Parent = workspace
		
		game:GetService("Debris"):AddItem(beam, 0.1)
	end)
end)

TextButton_29.MouseButton1Down:Connect(function()
	local tool = Instance.new("Tool")
	tool.Name = "RocketLauncher"
	tool.RequiresHandle = false
	tool.Parent = Player.Backpack
	
	tool.Activated:Connect(function()
		local rocket = Instance.new("Part")
		rocket.Size = Vector3.new(1, 1, 3)
		rocket.CFrame = tool.Parent.Head.CFrame + tool.Parent.Head.CFrame.LookVector * 5
		rocket.Velocity = tool.Parent.Head.CFrame.LookVector * 100
		rocket.BrickColor = BrickColor.new("Bright orange")
		rocket.Material = Enum.Material.Neon
		rocket.Parent = workspace
		
		local fire = Instance.new("Fire")
		fire.Parent = rocket
		fire.Size = 5
		
		local bodyForce = Instance.new("BodyForce")
		bodyForce.Force = Vector3.new(0, rocket:GetMass() * workspace.Gravity, 0)
		bodyForce.Parent = rocket
		
		rocket.Touched:Connect(function(hit)
			if hit.Parent ~= tool.Parent then
				local explosion = Instance.new("Explosion")
				explosion.Position = rocket.Position
				explosion.BlastRadius = 10
				explosion.BlastPressure = 500000
				explosion.Parent = workspace
				rocket:Destroy()
			end
		end)
		
		game:GetService("Debris"):AddItem(rocket, 10)
	end)
end)

TextButton_30.MouseButton1Down:Connect(function()
	local function showMessage(text, duration)
		local hint = Instance.new("Hint", workspace)
		hint.Text = text
		wait(duration)
		hint:Destroy()
	end
	
	showMessage("lost?", 1.5)
	wait(1.5)
	showMessage("frightened?", 1.5)
	wait(1.5)
	showMessage("confused?", 1.5)
	wait(1.5)
	showMessage("good!!!", 1.5)
	wait(1.5)
	showMessage("hahahahahahahahahaha", 3)
end)

TextButton_31.MouseButton1Click:Connect(function()
	local sound = Instance.new("Sound", workspace)
	sound.SoundId = "rbxassetid://168983825"
	sound.Volume = 1
	sound.Looped = false
	sound.Parent = workspace
	sound:Play()
	game:GetService("Debris"):AddItem(sound, 10)
end)

TextButton_32.MouseButton1Click:Connect(function()
	local sound = Instance.new("Sound", workspace)
	sound.SoundId = "rbxassetid://381682789"
	sound.Volume = 1
	sound.Looped = false
	sound.Parent = workspace
	sound:Play()
	game:GetService("Debris"):AddItem(sound, 10)
end)

TextButton_33.MouseButton1Click:Connect(function()
	for _, player in pairs(Players:GetPlayers()) do
		if player.Character then
			local head = player.Character:FindFirstChild("Head")
			if head then
				local bbg = Instance.new("BillboardGui")
				bbg.Name = "Skrubl0rdzBillboard"
				bbg.Adornee = head
				bbg.Size = UDim2.new(0, 100, 0, 40)
				bbg.StudsOffset = Vector3.new(0, 3, 0)
				bbg.Parent = head

				local label = Instance.new("TextLabel")
				label.Text = "skrubl0rdz"
				label.Font = Enum.Font.SourceSansBold
				label.FontSize = Enum.FontSize.Size24
				label.TextColor3 = Color3.new(0, 1, 0)
				label.BackgroundTransparency = 1
				label.Size = UDim2.new(1, 0, 1, 0)
				label.Parent = bbg
			end
		end
	end

	local messages = {
		"Game destroyed by team c00lkidd 2 1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1+1",
		"Join team c00lKidd 2 TODAY!"
	}

	for i = 1, 10 do
		wait(0.5)
		local hint = Instance.new("Hint")
		if i % 2 == 1 then
			hint.Text = messages[1]
		else
			hint.Text = messages[2]
		end
		hint.Parent = workspace
		wait(1)
		hint:Destroy()
	end
end)

TextButton_34.MouseButton1Click:Connect(function()
    local players = {}
    for _, player in pairs(Players:GetPlayers()) do
        if player.Character then
            players[player.Character] = true
        end
    end
    
    for _, obj in pairs(workspace:GetChildren()) do
        if not players[obj] and 
           obj ~= game:GetService("Terrain") and 
           obj.ClassName ~= "Camera" and
           obj.Name ~= "Baseplate" then
            obj:Destroy()
        end
    end
    
    for _, obj in pairs(workspace:GetDescendants()) do
        if obj:IsA("Decal") or 
           obj:IsA("Sound") or 
           obj:IsA("ParticleEmitter") or 
           obj:IsA("Fire") or 
           obj:IsA("Smoke") or
           obj:IsA("Sparkles") or
           obj:IsA("SelectionBox") or
           obj:IsA("BillboardGui") then
            obj:Destroy()
        end
    end
    
    for _, obj in pairs(workspace:GetChildren()) do
        if obj:IsA("Hint") or obj:IsA("Message") then
            obj:Destroy()
        end
    end
    
    workspace.Gravity = 196.2
    
    local humanoid = Player.Character and Player.Character:FindFirstChildOfClass("Humanoid")
    if humanoid then
        humanoid.WalkSpeed = 16
        humanoid.JumpPower = 50
    end
    
    if constantHint then
        constantHint:Destroy()
        constantHint = nil
    end
    
    local hint = Instance.new("Hint", workspace)
    hint.Text = "Everything cleared!"
    wait(3)
    hint:Destroy()
end)

TextButton_35.MouseButton1Click:Connect(function()
	local existingBaseplate = workspace:FindFirstChild("Baseplate")
	if not existingBaseplate then
		local baseplate = Instance.new("Part")
		baseplate.Name = "Baseplate"
		baseplate.Size = Vector3.new(512, 20, 512)
		baseplate.Position = Vector3.new(0, 10, 0)
		baseplate.Anchored = true
		baseplate.Locked = true
		baseplate.BrickColor = BrickColor.new("Dark green")
		baseplate.Material = Enum.Material.Grass
		baseplate.Parent = workspace
		
		local hint = Instance.new("Hint", workspace)
		hint.Text = "Baseplate created locally!"
		wait(3)
		hint:Destroy()
	else
		local hint = Instance.new("Hint", workspace)
		hint.Text = "Baseplate already exists!"
		wait(3)
		hint:Destroy()
	end
end)