-- Полная очистка от эффектов заморозки

local player = game:GetService("Players").LocalPlayer
local RunService = game:GetService("RunService")

local function megaUnfreeze()
    local character = player.Character
    if not character then return end
    
    -- 1. Сбрасываем Humanoid
    local humanoid = character:FindFirstChildOfClass("Humanoid")
    if humanoid then
        humanoid.PlatformStand = false
        humanoid.Sit = false
        humanoid.WalkSpeed = 16
        humanoid.JumpPower = 50
        humanoid.AutoRotate = true
        humanoid:SetStateEnabled(Enum.HumanoidStateType.Physics, true)
    end
    
    -- 2. Размораживаем все части
    for _, part in ipairs(character:GetDescendants()) do
        if part:IsA("BasePart") then
            part.Anchored = false
            part.CanCollide = true
            part.CanQuery = true
            part.CanTouch = true
            
            -- Удаляем ограничители
            if part:FindFirstChildOfClass("Constraint") then
                part:FindFirstChildOfClass("Constraint"):Destroy()
            end
        end
        
        -- Удаляем BodyMovers (ForceField и т.д.)
        if part:IsA("BodyMover") then
            part:Destroy()
        end
        
        -- Удаляем специальные эффекты
        if part:IsA("SelectionBox") or part:IsA("SelectionSphere") or part:IsA("BoxHandleAdornment") then
            part:Destroy()
        end
    end
    
    -- 3. Специально для RootPart
    local rootPart = character:FindFirstChild("HumanoidRootPart")
    if rootPart then
        rootPart.Anchored = false
        rootPart.Velocity = Vector3.new(0,0,0)
        rootPart.RotVelocity = Vector3.new(0,0,0)
        rootPart:SetNetworkOwner(player)
        
        -- Временно отключаем коллизии для выхода из ловушки
        rootPart.CanCollide = false
        wait(0.1)
        rootPart.CanCollide = true
    end
    
    print("⚡ Полная разморозка выполнена!")
end

-- Главный цикл
RunService.Heartbeat:Connect(function()
    local character = player.Character
    if not character then return end
    
    local humanoid = character:FindFirstChildOfClass("Humanoid")
    local rootPart = character:FindFirstChild("HumanoidRootPart")
    
    if humanoid and rootPart then
        -- Проверка на заморозку
        if humanoid.PlatformStand 
        or humanoid.Sit 
        or rootPart.Anchored 
        or humanoid.WalkSpeed < 5 
        or humanoid.JumpPower < 30 then
            megaUnfreeze()
        end
    end
end)

print("🛡️ Защита от заморозки активирована!")